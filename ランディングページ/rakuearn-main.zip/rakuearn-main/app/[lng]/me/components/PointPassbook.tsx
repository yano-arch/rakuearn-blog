"use client";
import React, { useState } from "react";
import { Calendar, ChevronDown } from "lucide-react";
import { SelectorButton } from "./SelectorButton";
import { EarnedHistoryCard } from "./EarnedHistoryCard";
import { getHistoryItems } from "@/constants/constants";
import { ExchangeHistoryCard } from "./ExchangeHistoryCard";
import { getExchangeHistoryItems } from "@/constants/constants";
import { useT } from "@/app/i18n/client";
import { User } from "@supabase/supabase-js";
import { createClient } from "@/utils/supabase/client";
interface Exchange {
  id: string;
  amount: number;
  payment: string;
  created_at: string;
  status: string;
}

interface EarnedHistory {
  point: number;
  earned_at: string;
  surveys: {
    title: string;
    provider: string;
    link: string;
  };
}

export const PointPassbook: React.FC<{ user: User | null }> = ({ user }) => {
  const { t } = useT("auth");
  const [selectedTab, setSelectedTab] = useState("earned");
  const [selectedDate, setSelectedDate] = useState(7);
  const [resultsLength, setResultsLength] = useState(0);
  const [exchanges, setExchanges] = useState<Exchange[]>([]);
  const [earnedHistory, setEarnedHistory] = useState<EarnedHistory[]>([]);
  const supabase = createClient();
  React.useEffect(() => {
    const fetchEarnedHistory = async () => {
      const period = new Date();
      period.setDate(period.getDate() - selectedDate);
      const { data, error } = await supabase
        .from("responses")
        .select("*, surveys (title, provider, link)")
        .eq("user_id", user?.id)
        .gte("created_at", period.toISOString());
      if (error) {
        console.error("Repsonses retrieval failed", error);
      } else {
        setEarnedHistory(data);
      }
    };
    const fetchExchanges = async () => {
      const period = new Date();
      period.setDate(period.getDate() - selectedDate);
      const { data, error } = await supabase
        .from("exchanges")
        .select("*")
        .eq("user_email", user?.email)
        .gte("created_at", period.toISOString());
      if (error) {
        console.error("Exchanges retrieval failed", error);
      } else {
        setExchanges(data);
      }
    };
    fetchEarnedHistory();
    fetchExchanges();
  }, [selectedDate]);

  React.useEffect(() => {
    if (selectedTab === "earned") {
      setResultsLength(earnedHistory.length);
    } else {
      setResultsLength(exchanges.length);
    }
  }, [selectedTab, exchanges]);

  const handleDateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedDate(parseInt(e.target.value));
  };

  return (
    <section className="mb-10" aria-label="Point passbook">
      <h2
        className="mb-5 max-md:mb-4 text-2xl max-md:text-xl font-bold text-black"
        aria-label="Point passbook title"
      >
        {t("pointPassbook.title")}
      </h2>
      <div
        className="flex mb-8 rounded-xl bg-neutral-100 max-sm:flex-col"
        aria-label="Point passbook tabs"
      >
        <SelectorButton
          className="max-sm:rounded-t-lg "
          title={t("pointPassbook.earnedHistory")}
          selected={selectedTab === "earned"}
          onClick={() => setSelectedTab("earned")}
        />
        <SelectorButton
          className="max-sm:rounded-b-lg"
          title={t("pointPassbook.exchangeHistory")}
          selected={selectedTab === "exchange"}
          onClick={() => setSelectedTab("exchange")}
        />
      </div>
      <div
        className="p-9 max-sm:p-5 rounded-xl bg-neutral-100"
        aria-label="Point passbook results"
      >
        <div
          className="flex max-md:gap-5 justify-between items-center mb-5 max-sm:mb-2"
          aria-label="Point passbook results filters"
        >
          <h3
            className="text-lg max-md:text-base font-semibold text-black"
            aria-label="Point passbook results title"
          >
            {t("pointPassbook.results") + " (" + resultsLength + ")"}
          </h3>
          <div
            className="relative"
            aria-label="Point passbook results date selector"
          >
            <Calendar
              className="z-10 mt-[-1px] pointer-events-none absolute left-2 top-1/2 -translate-y-1/2"
              width={20}
              height={20}
            />
            <select
              id="selectedDate"
              value={selectedDate}
              onChange={handleDateChange}
              className="px-9 py-2 relative max-sm:text-xs rounded-lg border border-zinc-300 appearance-none bg-white cursor-pointer w-[180px] max-sm:w-[140px]"
              aria-label="Point passbook results date selector"
            >
              <option value="7">{t("pointPassbook.last7Days")}</option>
              <option value="30">{t("pointPassbook.last30Days")}</option>
              <option value="90">{t("pointPassbook.last90Days")}</option>
            </select>
            <ChevronDown className="absolute max-sm:w-[20px] pointer-events-none right-2 top-1/2 -translate-y-1/2" />
          </div>
        </div>
        <div className="flex flex-col gap-5">
          {selectedTab === "earned" ? (
            <>
              {earnedHistory.map((item, index) => (
                <EarnedHistoryCard key={index} index={index} item={item} />
              ))}
            </>
          ) : (
            exchanges.map((item, index) => (
              <ExchangeHistoryCard
                t={t}
                key={index}
                index={index}
                item={item}
              />
            ))
          )}
        </div>
      </div>
    </section>
  );
};
