import GradientToggle from "./ui/gradient-toggle";

const RadioFormInput = ({ label, name, value, onChange, checked }) => {
    return (
        <div className="flex flex-col  w-user-form-width">
                                <div>
                                <GradientToggle label={"Gender"}/>
                                </div>
                                <div className="p-4 flex flex-col">
                                    <div className="w-full bg-white border-custom-inactive-text p-2 flex gap-3 rounded-lg">
                                        <input type="radio" value={"Male"} className="p-2 bg-white" />
                                        <label className="text-black">Male</label>
                                    </div>
                                    <div className="w-full bg-white border-custom-inactive-text p-2 flex gap-3">
                                        <input type="radio" value={"Female"} className="p-2 bg-white"/>
                                        <label className="text-black">Female</label>
                                    </div>
                                    <div className="w-full bg-white border-custom-inactive-text p-2 flex gap-3 rounded-lg">
                                        <input type="radio" value={"Other"} className="p-2 bg-white"/>
                                        <label className="text-black">Other</label>
        
                                    </div>
                                </div>
                        </div>
    )
};

export default RadioFormInput;