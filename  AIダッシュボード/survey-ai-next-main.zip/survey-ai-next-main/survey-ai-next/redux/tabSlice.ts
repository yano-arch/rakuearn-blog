import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface TabState {
  activeTab: string;
}

const initialState: TabState = {
  activeTab: "dashboard", // Default tab
};

const tabSlice = createSlice({
  name: "tabs",
  initialState,
  reducers: {
    // Action to set the active tab
    setActiveTab: (state, action: PayloadAction<string>) => {
      state.activeTab = action.payload;
    },
    // Action to handle tab change and navigation (optional for side effects)
    handleTabChange: (state, action: PayloadAction<string>) => {
      const value = action.payload;
      switch (value) {
        case "dashboard":
          state.activeTab = "dashboard";
          break;
        case "configuration":
          state.activeTab = "configuration";
          break;
        case "settings":
          state.activeTab = "settings";
          break;
        default:
          console.error("Unknown tab:", value);
      }
    },
  },
});

export const { setActiveTab, handleTabChange } = tabSlice.actions;
export default tabSlice.reducer;
