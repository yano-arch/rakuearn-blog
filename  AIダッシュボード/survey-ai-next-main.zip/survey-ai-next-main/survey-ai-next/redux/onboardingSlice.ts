import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface OnboardingState {
  onboardingStatus: string;
}

const initialState: OnboardingState = {
  onboardingStatus: 'UNCOMPLETED',
};

const onboardingSlice = createSlice({
  name: "onboarding",
  initialState,
  reducers: {
    completeOnboarding(state) {
      state.onboardingStatus = 'COMPLETED';
    },
    skipOnboarding(state) {
      state.onboardingStatus = 'SKIPPED';
    },
    restartOnboarding(state){
      state.onboardingStatus = 'UNCOMPLETED'
    }
  },
});

export const { completeOnboarding, skipOnboarding, restartOnboarding } = onboardingSlice.actions;
export default onboardingSlice.reducer;
