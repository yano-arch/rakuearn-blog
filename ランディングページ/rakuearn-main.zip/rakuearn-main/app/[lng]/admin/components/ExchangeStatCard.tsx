import * as React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Loader2 } from "lucide-react";
interface StatCardProps {
	title: string;
	value: string | number;
	variant?: "default" | "highlight";
	setStartDate: (date: Date) => void;
	setEndDate: (date: Date) => void;
	startDate: Date;
	endDate: Date;
	isLoading: boolean;
}

export const ExchangeStatCard: React.FC<StatCardProps> = ({
	title,
	value,
	startDate,
	endDate,
	setStartDate,
	setEndDate,
	variant = "default",
	isLoading,
}) => {
	const bgColor = variant === "highlight" ? "bg-amber-300" : "bg-white";


	return (
		<article
			className={`flex grow max-sm:justify-between w-[300px] gap-8 max-md:w-full items-start py-6 pr-14 pl-5 text-lg font-semibold text-black ${bgColor} rounded-xl max-md:pr-5 max-md:mt-8`}
			role="region"
			aria-label={title}
		>
			<div className="flex flex-col gap-5">
				<h3>{title}</h3>
				{isLoading ? (
					<div className="flex justify-center items-center">
						<Loader2 className="animate-spin" />
					</div>
				) : (
					<p >{value}</p>
				)}
			</div>
			<div className="flex flex-col gap-5">
				<div className="flex gap-2 justify-between items-center">
					<label className="text-sm">From:</label>
					<DatePicker
						selected={startDate}
						onChange={(date) => setStartDate(date || new Date())}
						className="w-[80px] text-sm outline-1 p-1 rounded-md font-medium cursor-pointer"
					/>
				</div>
				<div className="flex gap-2 justify-between items-center">
					<label className="text-sm">To:</label>
					<DatePicker
						selected={endDate}
						onChange={(date) => setEndDate(date || new Date())}
						className="w-[80px] text-sm outline-1 p-1 rounded-md font-medium cursor-pointer"
					/>
				</div>
			</div>
		</article>
	);
};
