import { db } from "@/lib/db";

export const getUserSurveyStats = async (userId: string, scope: number) => {
       try {

              const sinceDate = new Date();
              sinceDate.setDate(sinceDate.getDate() - scope)

              const results = await db.survey.findMany({
                     where: {
                            userId,
                            completedAt: {gte: sinceDate}
                     },
                     select: {
                            completedAt: true,
                            pointsEarned: true,
                            title: true
                     }
              })

              const totalSurveys = results.length
              const totalPoints = results.reduce((sum, entry) => sum + entry.pointsEarned, 0)

              return {
                     totalSurveys,
                     totalPoints,
                     surveys: results.map(entry => ({
                            date: entry.completedAt,
                            title: entry.title,
                            pointsEarned: entry.pointsEarned
                     }))
              };

       } catch (error) {
              console.log(error)
              return null
       }
}