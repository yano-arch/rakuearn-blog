import * as React from "react";
import { RedemptionCard } from "./RedemptionCard";
import { CategoryTitle } from "@/components/comps/CategoryTitle";
import { getRedemptionSteps } from "@/constants/constants";
import { useT } from "@/app/i18n/client";

export const RedemptionSteps: React.FC = () => {
	const { t } = useT('howItWorks');
	return (
		<section className="mt-32 max-md:mt-10 max-sm:px-2" aria-labelledby="redemption-title">
			<CategoryTitle title={t('redemptionSection.title')} aria-label="Redemption title" />

			<div className="ml-11 max-w-full w-[641px] max-sm:w-full max-sm:ml-0" aria-label="Redemption steps">
				<div className="flex gap-5 max-md:flex-col">
					<div className="max-md:w-full">
						<div className="flex flex-col items-start max-md:items-center mt-5 w-full text-lg font-bold max-md:mt-2 max-md:max-w-full">
							{getRedemptionSteps(t).map((step) => (
								<RedemptionCard
									key={step.number}
									number={step.number}
									title={t(step.title)}
									description={t(step.description)}
									image={step.image}
								/>
							))}
						</div>
					</div>
				</div>
			</div>
		</section>
	);
};
