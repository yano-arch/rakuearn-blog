import UserForm from "../User-Form";


const UserConfig = () => {




    return (
        <div className="w-full h-full">
            {/* header */}
            <div className="flex flex-row justify-between p-8">
            <h1 className="text-custom-darkest-purple font-semibold text-3xl">User Details</h1>
            <button className="bg-custom-dpurple-active text-white rounded-lg py-2 px-8">Edit</button>
            </div>
            {/*  form component*/}
            <UserForm/>
        </div>
    )
};

export default UserConfig;