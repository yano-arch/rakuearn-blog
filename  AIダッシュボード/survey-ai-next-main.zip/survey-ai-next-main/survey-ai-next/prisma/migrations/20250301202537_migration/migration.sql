/*
  Warnings:

  - You are about to drop the `SurveyStats` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "SurveyStats" DROP CONSTRAINT "SurveyStats_userId_fkey";

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "role" "UserRole" NOT NULL DEFAULT 'USER';

-- DropTable
DROP TABLE "SurveyStats";

-- CreateTable
CREATE TABLE "Surveys" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "totalSurveys" INTEGER NOT NULL DEFAULT 0,
    "todaySurveys" INTEGER NOT NULL DEFAULT 0,
    "weekSurveys" INTEGER NOT NULL DEFAULT 0,
    "monthSurveys" INTEGER NOT NULL DEFAULT 0,
    "yearSurveys" INTEGER NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Surveys_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Surveys_userId_key" ON "Surveys"("userId");

-- AddForeignKey
ALTER TABLE "Surveys" ADD CONSTRAINT "Surveys_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
