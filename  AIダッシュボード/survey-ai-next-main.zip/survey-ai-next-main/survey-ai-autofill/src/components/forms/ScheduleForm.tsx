import React from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent } from '@/components/ui/card'

const scheduleSchema = z.object({
  enabled: z.boolean().default(true),
  startTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Invalid time format'),
  endTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Invalid time format'),
  maxSurveysPerDay: z.string().regex(/^\d+$/, 'Must be a number').transform(Number),
  minDelayBetweenSurveys: z.string().regex(/^\d+$/, 'Must be a number').transform(Number)
})

type ScheduleFormData = z.infer<typeof scheduleSchema>

export function ScheduleForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<ScheduleFormData>({
    resolver: zodResolver(scheduleSchema)
  })

  React.useEffect(() => {
    // Load saved schedule
    chrome.storage.local.get(['schedule'], (result) => {
      if (result.schedule) {
        reset({
          ...result.schedule,
          maxSurveysPerDay: result.schedule.maxSurveysPerDay.toString(),
          minDelayBetweenSurveys: result.schedule.minDelayBetweenSurveys.toString()
        })
      }
    })
  }, [reset])

  const onSubmit = async (data: ScheduleFormData) => {
    await chrome.storage.local.set({
      schedule: {
        ...data,
        maxSurveysPerDay: Number(data.maxSurveysPerDay),
        minDelayBetweenSurveys: Number(data.minDelayBetweenSurveys)
      }
    })
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <Label htmlFor="enabled">Enable Scheduling</Label>
              <Switch {...register('enabled')} id="enabled" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input
                  id="startTime"
                  type="time"
                  {...register('startTime')}
                  className={errors.startTime ? 'border-destructive' : ''}
                />
                {errors.startTime && (
                  <p className="text-sm text-destructive">{errors.startTime.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="endTime">End Time</Label>
                <Input
                  id="endTime"
                  type="time"
                  {...register('endTime')}
                  className={errors.endTime ? 'border-destructive' : ''}
                />
                {errors.endTime && (
                  <p className="text-sm text-destructive">{errors.endTime.message}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxSurveysPerDay">Maximum Surveys Per Day</Label>
              <Input
                id="maxSurveysPerDay"
                type="number"
                min="1"
                {...register('maxSurveysPerDay')}
                className={errors.maxSurveysPerDay ? 'border-destructive' : ''}
              />
              {errors.maxSurveysPerDay && (
                <p className="text-sm text-destructive">{errors.maxSurveysPerDay.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="minDelayBetweenSurveys">Minimum Delay Between Surveys (minutes)</Label>
              <Input
                id="minDelayBetweenSurveys"
                type="number"
                min="1"
                {...register('minDelayBetweenSurveys')}
                className={errors.minDelayBetweenSurveys ? 'border-destructive' : ''}
              />
              {errors.minDelayBetweenSurveys && (
                <p className="text-sm text-destructive">{errors.minDelayBetweenSurveys.message}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Button type="submit" className="w-full">
        Save Schedule
      </Button>
    </form>
  )
} 