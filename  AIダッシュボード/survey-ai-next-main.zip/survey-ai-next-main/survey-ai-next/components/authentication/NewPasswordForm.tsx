"use client";

import { NewPasswordSchema } from "@/schemas";
import { useTransition, useState } from "react";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from "@/components/ui/input";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { login } from "@/actions/login";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/FormError";
import { FormSuccess } from "@/components/FormSuccess";
import { useSearchParams } from "next/navigation";
import { reset } from "@/actions/reset";
import { newPassword } from "@/actions/new-password";


const NewPasswordForm = () => {

  const searchParams =  useSearchParams();
  const token = searchParams.get("token");

  const urlError = searchParams.get("error") === "OAuthAccountNotLinked"
    ? "Email already in use with different provider!" : "";

  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | undefined>("");
  const [success, setSuccess] = useState<string | undefined>("");

  const form = useForm<z.infer<typeof NewPasswordSchema>>({
    resolver: zodResolver(NewPasswordSchema as any),
    defaultValues: {
      password: '',
      confirmPassword: '',
    }
  })


  const onSubmit =  ( values: z.infer<typeof NewPasswordSchema>) => {
    setError("");
    setSuccess("");
    
    startTransition(() => {
      newPassword(values, token)
        .then((data) => {
          setError(data?.error)
          setSuccess(data?.success)
        })
    })
  }

  return (
    <>
      <div className="mt-2 p-2">       
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField control={form.control} name="password" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">New Password</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="******"
                        type="password"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                <FormField control={form.control} name="confirmPassword" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Confirm Password</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="******"
                        type="password"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                <FormError message={error || urlError}/>
                <FormSuccess message={success}/>
                <Button type="submit" className="credentials_buttons" disabled={isPending}>
                  Reset Password
                </Button>
            </form>
        </Form>
      </div>
    </>
  );
};

export default NewPasswordForm;