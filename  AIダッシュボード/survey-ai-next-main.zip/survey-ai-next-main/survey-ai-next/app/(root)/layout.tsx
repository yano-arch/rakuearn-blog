'use client';

import Sidebar from "@/components/SideBar";
import { SessionProvider } from "next-auth/react";
import { store } from "@/redux/store";

import type { ReactNode } from "react";
import type { Session } from "next-auth";


interface LayoutProps {
  children: ReactNode;
  session?: Session | null;
}

export default function Layout({ children, session }: LayoutProps) {
  
  
  return (
    <SessionProvider session={session}>
      <div className="flex w-full h-full">
        {/* <Sidebar /> */}
        <main className="">{children}</main>
      </div>
    </SessionProvider>
  );
}
