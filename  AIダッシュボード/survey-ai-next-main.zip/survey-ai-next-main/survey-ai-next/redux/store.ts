import { configureStore } from "@reduxjs/toolkit";
import onboardingReducer from "./onboardingSlice";
import tabReducer from "./tabSlice";

export const store = configureStore({
  reducer: {
    onboarding: onboardingReducer,
    tabs: tabReducer,
  },
});

// Infer the RootState and AppDispatch types from the store itself
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
