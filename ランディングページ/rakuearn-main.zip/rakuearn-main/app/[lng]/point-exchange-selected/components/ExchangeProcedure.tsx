import React from "react";
import { CircleHelp } from "lucide-react";
import { getExchangeProcedure } from "@/constants/constants";
import { TableRow } from "./TableRow";
import { useT } from "@/app/i18n/client";

export const ExchangeProcedure: React.FC = () => {
	const { t } = useT('pointExchange');
  return (
    <section className="mt-16 max-sm:mt-12 mb-30" aria-label="Exchange procedure section">
      <h2 className="flex gap-2 items-center mb-8 max-md:mb-4 text-2xl max-md:text-lg font-bold text-violet-500" aria-label="Exchange procedure title">
        <CircleHelp color="#8771EF" className="w-[24px] max-sm:w-[20px]" />
        {t("exchangeProcedure.title")}
      </h2>
      <div className="bg-white rounded-3xl border border-solid border-zinc-300 border-opacity-90">
        <dl>
          {getExchangeProcedure(t).map((procedure) => (
            <TableRow key={procedure.title} title={procedure.title} content={procedure.description} className={procedure.className} rounded={procedure.rounded} />
          ))}
        </dl>
      </div>
    </section>
  );
};
