import React from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card } from '@/components/ui/card'
import { User, Globe, Clock, Key } from 'lucide-react'
import { ProfileForm } from './components/ProfileForm'
import { SitesForm } from './components/SitesForm'
import { ScheduleForm } from './components/ScheduleForm'
import { APIKeyForm } from './components/APIKeyForm'

export function Options() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Survey AI Autofill Settings
          </h1>
          <p className="text-muted-foreground text-lg">
            Configure your AI assistant to better understand you and automate survey completion.
          </p>
        </div>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="w-full grid grid-cols-4 h-14 items-center bg-white dark:bg-gray-800 rounded-lg p-1 gap-1">
            <TabsTrigger 
              value="profile"
              className="h-12 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-md transition-all flex items-center gap-2"
            >
              <User className="w-4 h-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger 
              value="sites"
              className="h-12 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-md transition-all flex items-center gap-2"
            >
              <Globe className="w-4 h-4" />
              Survey Sites
            </TabsTrigger>
            <TabsTrigger 
              value="schedule"
              className="h-12 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-md transition-all flex items-center gap-2"
            >
              <Clock className="w-4 h-4" />
              Schedule
            </TabsTrigger>
            <TabsTrigger 
              value="api"
              className="h-12 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-blue-600 data-[state=active]:text-white rounded-md transition-all flex items-center gap-2"
            >
              <Key className="w-4 h-4" />
              API Key
            </TabsTrigger>
          </TabsList>
          
          <Card className="mt-6 p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border border-gray-100 dark:border-gray-700 shadow-xl rounded-xl">
            <TabsContent value="profile" className="mt-0">
              <ProfileForm />
            </TabsContent>
            <TabsContent value="sites" className="mt-0">
              <SitesForm />
            </TabsContent>
            <TabsContent value="schedule" className="mt-0">
              <ScheduleForm />
            </TabsContent>
            <TabsContent value="api" className="mt-0">
              <APIKeyForm />
            </TabsContent>
          </Card>
        </Tabs>
      </div>
    </div>
  )
} 