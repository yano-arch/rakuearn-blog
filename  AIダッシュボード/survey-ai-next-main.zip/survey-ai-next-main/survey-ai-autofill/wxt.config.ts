import { defineConfig } from 'wxt';
import { resolve } from 'path';

// See https://wxt.dev/api/config.html
export default defineConfig({
  manifest: {
    name: 'Survey AI Autofill',
    description: 'AI-powered survey completion assistant',
    version: '1.0.0',
    permissions: [
      'storage',
      'activeTab',
      'scripting',
      'tabs'
    ],
    host_permissions: [
      "*://*/*"
    ],
    action: {
      default_popup: 'popup/index.html',
      default_title: 'Survey AI Autofill'
    },
    options_ui: {
      page: 'options/index.html',
      open_in_tab: true
    },
    background: {
      service_worker: 'background/index.ts',
      type: 'module'
    },
    content_scripts: [
      {
        matches: ["*://*/*"],
        js: ["content-scripts/content.js"]
      }
    ]
  },
  vite: () => ({
    build: {
      target: 'esnext',
    },
    resolve: {
      alias: {
        '@': resolve(__dirname, './src')
      }
    }
  }),
  modules: ['@wxt-dev/module-react'],
  srcDir: 'src',
  outDir: '.output',
  entrypointsDir: 'entrypoints'
});
