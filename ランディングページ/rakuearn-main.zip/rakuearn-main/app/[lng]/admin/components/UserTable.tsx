"use client";
import React from "react";
import { getUsers } from "../actions";
import Link from "next/link";
import { useT } from "@/app/i18n/client";
interface User {
  id: string;
  email: string;
  point: number;
  created_at: string;
}

export function UserTable() {
  const { t } = useT('admin');
  const [users, setUsers] = React.useState<User[] | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchUsers = async () => {
      const users = await getUsers();
      if ('error' in users) {
        console.error('Users retrieval failed', users.error);
      } else {
        setUsers(users);
        setIsLoading(false);
      }
    }
    fetchUsers();
  }, []);

  return (
    <div className="ml-5 w-[72%] overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] max-md:ml-0 max-md:w-full mt-30 overflow-x-scroll" aria-label="User table Section">
      <table className="w-full border-collapse" aria-label="User table">
        <thead>
          <tr className="border-b border-black" aria-label="User table header">
            <th className="py-4 px-6 text-left font-semibold" aria-label="User table header column">{t("user")}</th>
            <th className="py-4 px-6 text-right font-semibold" aria-label="User table header column">{t("points")}</th>
            <th className="py-4 px-6 text-right font-semibold" aria-label="User table header column">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan={3} className="text-center py-4">Loading...</td>
            </tr>
          ) : (
            users && users.map((user, index) => (
              <tr
                key={index}
                className={`border-b border-gray-100 hover:bg-gray-50`}
                aria-label="User table row"
              >
                <td className={`px-6 text-left ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="User table data">
                  {user.email}
                </td>
                <td className={`py-2 px-6 text-right ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="User table data">
                  {user.point}
                </td>
                <td className={`py-2 px-6 text-right ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="User table data">
                  <Link
                    href={`/admin/`}
                    className="font-medium"
                    aria-label="View user"
                  >
                    {t("view")}
                  </Link>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}