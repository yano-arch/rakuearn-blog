"use client";
import React, { useState } from "react";
import Link from "next/link";
import GoogleLogo from "../svg/GoogleLogo";
import InstagramLogo from "../svg/InstagramLogo";
import Logo from "@/assets/images/logo.webp";
import { usePathname, useParams, useRouter } from "next/navigation";
import { useT } from "@/app/i18n/client";
import { ChevronDown } from "lucide-react";
import { Noto_Sans_JP } from "next/font/google";
interface MenuItems {
  [key: string]: { label: string; href: string; external?: boolean }[];
}

interface FooterProps {
  className?: string;
}

const notoSansJp = Noto_Sans_JP({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-noto-sans-jp",
});

const Footer: React.FC<FooterProps> = ({ className }) => {
  const pathname = usePathname();
  const lng = useParams().lng;
  const router = useRouter();
  const [language, setLanguage] = useState<string>(lng as string);
  const { t } = useT("common");
  const menuItems: MenuItems = {
    Menu: [
      // { label: t('home'), href: `/${lng}` },
      { label: t("howItWorks"), href: `/${lng}/how-it-works` },
      { label: t("surveyList"), href: `/${lng}/survey-list` },
      { label: t("pointExchange"), href: `/${lng}/point-exchange` },
      {
        label: t("rakuEarnAI"),
        href: "https://app.rakuearn.com/",
        external: true,
      },
    ],
    Resources: [
      { label: t("contact"), href: `mailto:team@rakuearn.com` },
      { label: t("account"), href: `/${lng}/me` },
    ],
  };

  const policies: string[] = [t("terms"), t("privatePlicy"), t("refundPolicy")];

  return (
    <footer
      className={`py-10 w-full flex ${
        lng === "ja" ? "noto-sans-jp" : ""
      } flex-col items-center justify-between max-sm:py-8 ${className} ${
        pathname === `/${lng}` || pathname === `/${lng}/how-it-works`
          ? "bg-white"
          : "bg-[#F6F5F9]"
      }`}
      aria-label="Footer"
    >
      <div
        className="px-14 max-md:px-4 max-sm:px-2 w-full max-w-[1440px]"
        aria-label="Footer content"
      >
        <div
          className="flex px-8 max-sm:px-4 max-md:gap-4 max-md:flex-col justify-between"
          aria-label="Footer content section"
        >
          <div className="flex max-sm:items-start flex-col gap-5 items-start mb-8">
            <div className="flex flex-col gap-5 items-start mb-8">
              <img
                src={Logo.src}
                alt="Logo"
                className="w-[172px] max-md:ml-[-20]"
                aria-label="Logo"
              />
              <div className="flex gap-3 ml-6 max-md:ml-0">
                <a href="#twitter" aria-label="Twitter">
                  <div
                    dangerouslySetInnerHTML={{
                      __html:
                        '<svg id="1:352" width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.5083 1.50684H17.179L11.3444 8.17543L18.2083 17.2499H12.8339L8.62444 11.7463L3.80787 17.2499H1.13559L7.3763 10.1171L0.791664 1.50684H6.30254L10.1075 6.53735L14.5083 1.50684ZM13.571 15.6514H15.0508L5.49844 3.0214H3.9104L13.571 15.6514Z" fill="#212121"></path></svg>',
                    }}
                  />
                </a>
                <a href="#instagram" aria-label="Instagram">
                  <InstagramLogo aria-label="Instagram logo" />
                </a>
              </div>
            </div>
            <div
              className={`ml-6 max-md:ml-0 flex gap-2 max-sm:mt-0 mt-12 items-center p-3 rounded-full ${
                pathname === `/${lng}` || pathname === `/${lng}/how-it-works`
                  ? "bg-[#F6F5F9]"
                  : "bg-white"
              }`}
              aria-label="Install extension section"
            >
              <GoogleLogo aria-label="Google logo" />
              <p className="text-base max-sm:text-xs font-bold">
                {t("installExtension")}
              </p>
            </div>
          </div>
          {/* Desktop */}
          <div className="flex max-md:hidden max-md:flex-col max-md:items-center max-sm:items-start justify-between w-1/3 max-[1100px]:w-2/3 mb-8 max-sm:gap-8">
            <div
              className="flex gap-4 items-start cursor-pointer"
              aria-label="Language selection section"
            >
              {/* <div className="relative">
                <select
                  className={`px-4 max-md:mb-4 relative rounded-lg appearance-none bg-[#F6F5F9] outline-none cursor-pointer w-[150px] ${pathname === `/${lng}` || pathname === `/${lng}/how-it-works` ? 'bg-white' : 'bg-[#F6F5F9]'}`}
                  onChange={(e) => {
                    setLanguage(e.target.value);
                    router.push(`/${e.target.value}`);
                  }}
                  value={language}
                >
                  <option value="en">{t('english')}</option>
                  <option value="ja">{t('japanese')}</option>
                </select>
                <ChevronDown className="absolute pointer-events-none right-8 top-1/2 -translate-y-1/2" />
              </div> */}
            </div>
            {Object.entries(menuItems).map(([category, items]) => (
              <nav
                key={category}
                className="flex flex-col gap-4 max-md:mb-4"
                aria-label={category}
              >
                <h3 className="mb-2.5 text-[16px] font-bold">{t(category)}</h3>
                {items.map((item, index) =>
                  item.external ? (
                    <a
                      key={index}
                      href={item.href}
                      target="_blank" // Open in a new tab
                      rel="noopener noreferrer" // For security reasons
                      className="text-[16px] font-medium text-black"
                    >
                      {item.label}
                    </a>
                  ) : (
                    <Link
                      key={index}
                      href={item.href}
                      className="text-[16px] font-medium text-black"
                    >
                      {item.label}
                    </Link>
                  )
                )}
              </nav>
            ))}
          </div>

          {/* Mobile */}
          <div className="hidden max-md:flex max-md:items-stretch justify-between mb-8 max-sm:gap-8">
            <nav
              key="Menu"
              className="flex-1 flex flex-col gap-4 max-md:mb-4"
              aria-label="Menu"
            >
              <h3 className="mb-2.5 text-[16px] max-sm:text-xs font-bold">
                {t("Menu")}
              </h3>
              {menuItems.Menu.map((item, index) =>
                item.external ? (
                  <a
                    key={index}
                    href={item.href}
                    target="_blank" // Open in a new tab
                    rel="noopener noreferrer" // For security reasons
                    className="text-[16px] font-medium text-black"
                  >
                    {item.label}
                  </a>
                ) : (
                  <Link
                    key={index}
                    href={item.href}
                    className="text-[16px] font-medium text-black"
                  >
                    {item.label}
                  </Link>
                )
              )}
            </nav>
            <div className="flex-1 flex flex-col justify-between">
              <nav
                key="Resources"
                className="flex flex-col gap-4 max-md:mb-4"
                aria-label="Resources"
              >
                <h3 className="mb-2.5 text-[16px] max-sm:text-xs  font-bold">
                  {t("Resources")}
                </h3>
                {menuItems.Resources.map((item, index) => (
                  <Link
                    key={index}
                    href={item.href}
                    className="text-[16px] max-sm:text-xs  font-medium text-black"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
              {/* <div className="flex gap-4 items-start cursor-pointer" aria-label="Language selection section">
                <div className="relative">
                  <select
                    className={` max-md:mb-4 max-sm:text-xs relative rounded-lg appearance-none bg-[#F6F5F9] outline-none cursor-pointer w-[150px] ${pathname === `/${lng}` || pathname === `/${lng}/how-it-works` ? 'bg-white' : 'bg-[#F6F5F9]'}`}
                    onChange={(e) => {
                      setLanguage(e.target.value);
                      router.push(`/${e.target.value}`);
                    }}
                    value={language}
                  >
                    <option value="en">{t('english')}</option>
                    <option value="ja">{t('japanese')}</option>
                  </select>
                  <ChevronDown className="absolute max-sm:w-[16px] pointer-events-none right-12 max-sm:right-20 top-[13px] -translate-y-1/2" />
                </div>
              </div> */}
            </div>
          </div>
        </div>

        <div className="flex px-8 max-sm:px-4 ml-6 max-md:ml-0 justify-start max-sm:flex-col-reverse max-sm:gap-3 gap-40 pt-5 border-solid border-t-[0.5px] border-t-zinc-300">
          <p className="text-sm max-sm:text-xs">
            Copyright © 2024 Raku Earn Inc.
          </p>
          <nav
            className="flex gap-8 max-sm:flex-col max-sm:gap-2 max-sm:mt-4"
            aria-label="Legal"
          >
            {policies.map((policy, index) => (
              <a
                key={index}
                href={`#${policy.toLowerCase().replace(/\s+/g, "-")}`}
                className="text-[14px] max-sm:text-xs font-medium text-black"
              >
                {policy}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
