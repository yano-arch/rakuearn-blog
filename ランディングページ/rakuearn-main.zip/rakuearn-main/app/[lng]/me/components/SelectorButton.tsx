import React from 'react';

interface SelectorButtonProps {
	title: string;
	selected: boolean;
	className?: string;
	onClick: () => void;
}

export const SelectorButton: React.FC<SelectorButtonProps> = ({ title, selected, onClick, className }) => {
	return (
		<div className="w-1/2 max-md:w-full relative" aria-label="Selector button">
			<button className={`w-full cursor-pointer rounded-lg py-5 max-md:py-3 max-md:px-16 px-40 text-lg max-sm:text-sm font-bold text-center relative ${selected ? 'bg-[#8A70FF] text-white' : 'text-black'} ${className}`} onClick={onClick} aria-label="Selector button">
				{title}
			</button>
			{selected && (
				<div
					className="max-sm:hidden absolute left-1/2 -translate-x-1/2 bottom-0 translate-y-[4px] w-4 h-4 bg-[#8A70FF] rotate-45"
					aria-hidden="true"
					aria-label="Selector button active"
				/>
			)}
		</div>
	);
};

