import React from 'react'
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Globe, Plus, Save } from "lucide-react"

const sitesSchema = z.object({
  sites: z.array(z.object({
    url: z.string().url({ message: "Please enter a valid URL." }),
    enabled: z.boolean().default(true),
    name: z.string().min(2, { message: "Site name must be at least 2 characters." }),
  })),
})

export function SitesForm() {
  const form = useForm<z.infer<typeof sitesSchema>>({
    resolver: zodResolver(sitesSchema),
    defaultValues: {
      sites: [
        { url: "", enabled: true, name: "" }
      ],
    },
  })

  React.useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['surveySites'], (result) => {
        if (result.surveySites) {
          form.reset({ sites: result.surveySites })
        }
      })
    }
  }, [form])

  function onSubmit(values: z.infer<typeof sitesSchema>) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({ surveySites: values.sites }, () => {
        console.log('Survey sites saved:', values.sites)
      })
    }
  }

  const addSite = () => {
    const currentSites = form.getValues('sites')
    form.setValue('sites', [...currentSites, { url: "", enabled: true, name: "" }])
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-4">
          {form.watch('sites').map((_, index) => (
            <div key={index} className="p-4 rounded-lg border-2 border-gray-200 space-y-4">
              <FormField
                control={form.control}
                name={`sites.${index}.name`}
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="text-base flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Site Name
                    </FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Survey Site Name" 
                        {...field}
                        className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`sites.${index}.url`}
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="text-base">URL Pattern</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://example.com/surveys/*" 
                        {...field}
                        className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                      />
                    </FormControl>
                    <FormDescription>
                      Use * as a wildcard for dynamic parts of the URL
                    </FormDescription>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`sites.${index}.enabled`}
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between space-x-2">
                    <FormLabel className="text-base">Enable Autofill</FormLabel>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          ))}
        </div>

        <div className="flex gap-4">
          <Button 
            type="button" 
            onClick={addSite}
            variant="outline"
            className="flex-1 h-12 text-base font-medium rounded-full shadow hover:shadow-md transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Site
          </Button>

          <Button 
            type="submit" 
            className="flex-1 h-12 text-base font-medium bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Sites
          </Button>
        </div>
      </form>
    </Form>
  )
} 