"use client";

import * as React from "react";
import Image from "next/image";
import Header from "@/components/layout/Header";
import { useT } from "@/app/i18n/client";
import { StepsSection } from "./components/StepsSection";
import { AboutPoints } from "./components/AboutPoints";
import Footer from "@/components/layout/Footer";
import CTASection from "@/components/main/CTASection";
import PStack from "@/assets/images/Pstack.svg";
import Man from "@/assets/images/man.svg"
import { getHowToUseSteps } from "@/constants/constants";
import { RedemptionSteps } from "./components/RedemptionSteps";
import { Layout } from "@/components/layout/Layout";
import LogoB from "@/assets/images/logo.webp";

const HowItWorks: React.FC = () => {
	const { t } = useT('howItWorks');
	return (
		<Layout>
			<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="How it works page">
				<Header />
				<div className="px-8 max-md:px-2" aria-label="How it works content">
					<section className="flex flex-col justify-center mx-2 items-center px-16 py-12 max-md:py-8 mt-8 bg-neutral-100 max-md:rounded-[20px] rounded-[40px] max-md:px-5 max-sm:mt-0 max-md:max-w-full">
						<div className="flex max-w-full items-center justify-around w-full">
							<Image src={PStack} alt="Pstack" className="mt-20 max-md:hidden" />
							<div className="flex items-center justify-center max-md:flex-col">
								<Image
									src={LogoB}
									alt="How it works illustration"
									className="object-contain grow w-[400px] max-md:hidden"
								/>
								<div className="ml-5 max-md:ml-0 max-md:text-center max-md:w-full">
									<h1 className="text-4xl max-md:text-2xl font-bold text-black pt-0">
										{t('title')}
									</h1>
								</div>
							</div>
							<Image src={Man} className="max-md:hidden max-md:h-[80px]" alt="Man" width={200} height={80} />
						</div>
					</section>
					<StepsSection title={t('howToUseRakuEarn.title')} steps={getHowToUseSteps(t)} />
					<RedemptionSteps />
					<AboutPoints />
				</div>
			</div>
			<div className="max-md:px-0 px-12 w-full max-w-[1440px] max-md:max-w-[991px]">
				<CTASection className="mt-14" />
			</div>
			<Footer />
		</Layout>
	);
};

export default HowItWorks;
