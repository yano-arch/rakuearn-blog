import { Resend } from "resend";


const resend = new Resend(process.env.RESEND_API_KEY)

export const sendVerificationEmail = async (email: string, token: string) => {
    
    const confirmLink = `http://localhost:3000/auth/verification?token=${token}`;

    await resend.emails.send({
        from: "onboarding@resend.dev",
        to: email,
        subject: "Email Confirmation",
        html: `<p>Click <a href=${confirmLink}>here</a> to confirm email.</p>`
    });
};


export const sendPasswordResetEmail = async (email: string, token: string) => {
    
    const passwordResetLink = `http://localhost:3000/auth/new-password?token=${token}`

    await resend.emails.send({
        from: "onboarding@resend.dev",
        to: email,
        subject: "Password Reset",
        html: `<p>Click <a href=${passwordResetLink}>here</a> to reset your password.</p>`
    })
}