'use server'

import { createClient } from '@/utils/supabase/server'

interface SurveyFormData {
  title: string;
  surveyProvider: string;
  estimatedTime: number;
  pointsAmount: number;
  link: string;
  promotionId: string;
  fileUrl: string;
}

export async function addSurvey(formData: SurveyFormData) {
  const supabase = await createClient()

  // type-casting here for convenience
  // in practice, you should validate your inputs
  const data = {
    title: formData.title,
    provider: formData.surveyProvider,
    estimated_time: formData.estimatedTime,
    points: formData.pointsAmount,
    link: formData.link,
    acs_promotion_id: formData.promotionId,
    file_path: formData.fileUrl,
    popularity: 0,
  }

  const { error, data: survey } = await supabase.from("surveys").insert(data)

  if (error) {
    console.error('Survey insertion failed', error);
    return { error: error.message }
  }
  return { success: "Survey added successfully", survey: survey }
}

export async function uploadSurveyFile(file: File) {
  const supabase = await createClient()
  const filePath = `surveys/files/${Date.now()}-${file.name}`;

  const { data, error } = await supabase.storage
    .from('survey-files') // your storage bucket name
    .upload(filePath, file);

  if (error) {
    console.error('File upload failed', error);
    return null;
  }

  return filePath; // store this in surveys table
};

export async function getSurveys() {
  const supabase = await createClient()
  const { data: surveys, error } = await supabase.from('surveys').select().order('created_at', { ascending: false })
  if (error) {
    console.error('Survey retrieval failed', error);
    return { error: error.message }
  }
  return surveys
}

export async function getExchanges() {
  const supabase = await createClient()
  const { data: exchanges, error } = await supabase.from('exchanges').select()
  if (error) {
    console.error('Exchanges retrieval failed', error);
    return { error: error.message }
  }
  return exchanges
}

export async function updateExchangeStatus(id: number, status: string) {
  const supabase = await createClient()
  const { data: exchange, error } = await supabase.from('exchanges').update({ status }).eq('id', id)
  if (error) {
    console.error('Exchange status update failed', error);
    return { error: error.message }
  }
  return { success: "Exchange status updated successfully", exchange: exchange }
}

export async function getUsers() {
  const supabase = await createClient()
  const { data: profiles, error } = await supabase.from('profiles').select()
  if (error) {
    console.error('Users retrieval failed', error);
    return { error: error.message }
  }
  return profiles
}

export async function getPoints(userEmail: string) {
  const supabase = await createClient()
  const { data: points, error } = await supabase.from('profiles').select('point').eq('email', userEmail)
  if (error) {
    console.error('Points retrieval failed', error);
    return { error: error.message }
  }
  return points[0].point
}

export async function updatePoints(userEmail: string, point: number) {
  const supabase = await createClient()
  const currentPoint = await getPoints(userEmail)
  const { data: profile, error } = await supabase.from('profiles').update({ point: currentPoint - point }).eq('email', userEmail)
  if (error) {
    console.error('Points update failed', error);
    return { error: error.message }
  }
  return { success: "Points updated successfully", profile: profile }
}

export async function getTotalUsers() {
  const supabase = await createClient()
  const { data: totalUsers, error } = await supabase.from('profiles').select('*', { count: 'exact' })
  if (error) {
    console.error('Total users retrieval failed', error);
    return { error: error.message }
  }
  return totalUsers
}

export async function getTotalPoints() {
  const supabase = await createClient()
  const { data: totalPoints, error } = await supabase.from('profiles').select('point', { count: 'exact' })
  if (error) {
    console.error('Total points retrieval failed', error);
    return { error: error.message }
  }
  return totalPoints
}

export async function getPendingExchanges() {
  const supabase = await createClient()
  const { data: pendingExchanges, error } = await supabase.from('exchanges').select('*', { count: 'exact' }).eq('status', 'pending')
  if (error) {
    console.error('Pending exchanges retrieval failed', error);
    return { error: error.message }
  }
  return pendingExchanges
}

export async function getExchangeCompleted(startDate: string, endDate: string) {
  const supabase = await createClient()
  const { data: exchangeCompleted, error } = await supabase.from('exchanges').select('*', { count: 'exact' }).eq('status', 'complete').gte('created_at', startDate).lte('created_at', endDate)
  if (error) {
    console.error('Exchange completed retrieval failed', error);
    return { error: error.message }
  }
  return exchangeCompleted
}

export async function updatePopularity(surveyId: string) {
  const supabase = await createClient()
  const currentPopularity = await getPopularity(surveyId)
  console.log("currentPopularity", currentPopularity, surveyId)
  const { data: survey, error } = await supabase.from('surveys').update({ popularity: currentPopularity + 1 }).eq('id', surveyId)
  if (error) {
    console.error('Popularity update failed', error);
    return { error: error.message }
  }
  return { success: "Popularity updated successfully", survey: survey }
}

export async function addClickLog(surveyId: string, userId: string) {
  const supabase = await createClient()
  const { error } = await supabase.from('click_logs').insert({
    user_id: userId,
    survey_id: surveyId,
    clicked_at: new Date()
  })
  if (error) {
    console.error('Clicklog add failed', error);
    return { error: error.message }
  }
  return { success: "Clicklog added successfully", surveyId: surveyId, userId: userId }
}

export async function getPopularity(surveyId: string) {
  const supabase = await createClient()
  const { data: survey, error } = await supabase.from('surveys').select('popularity').eq('id', surveyId)
  if (error) {
    console.error('Popularity retrieval failed', error);
    return { error: error.message }
  }
  return survey[0].popularity
}


export async function updateSurvey(surveyId: string, survey: any) {
  const supabase = await createClient()
  const { data: updatedSurvey, error } = await supabase.from('surveys').update(survey).eq('id', surveyId)
  if (error) {
    console.error('Survey update failed', error);
    return { error: error.message }
  }
  return { success: "Survey updated successfully", survey: updatedSurvey }
}

export async function deleteSurvey(surveyId: string) {
  const supabase = await createClient()
  const { data: survey, error } = await supabase.from('surveys').delete().eq('id', surveyId)
  if (error) {
    console.error('Survey deletion failed', error);
    return { error: error.message }
  }
  return { success: "Survey deleted successfully", survey: survey }
}

