'use client';
import React from 'react'
import DynamicContentDisplay from '../Content-Display';
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import SideNavBar from '../SideNavBar';

const OverviewDashboard = () => {
  const activeTab = useSelector((state: RootState) => state.tabs.activeTab);
  return (
    <div className='flex justify-start w-full min-h-full'>
    <SideNavBar/>
    <DynamicContentDisplay activeTab={activeTab}/>
    </div>
  )
}

export default OverviewDashboard;