import Step1Img from "@/assets/images/Group 1000004591.svg";
import Step2Img from "@/assets/images/Group 1000004588.svg";
import Step3Img from "@/assets/images/Group 1000004587.svg";
import Step4Img from "@/assets/images/Group 1000004592.svg";
import Step5Img from "@/assets/images/Group 1000004593.svg";
import Step6Img from "@/assets/images/Group 1000004611.svg";
import Redemption1 from "@/assets/images/redemption1.svg";
import Redemption2 from "@/assets/images/redemption2.svg";
import Redemption3 from "@/assets/images/redemption3.svg";
import AmazonLogo from "@/assets/images/amazon.webp";
import AppleLogo from "@/assets/images/apple.webp";
import GooglePlayLogo from "@/assets/images/google_play.webp";
import PayPayLogo from "@/assets/images/paypay.webp";
import BankTransferLogo from "@/assets/images/bank_transfer.webp";
import { StaticImageData } from "next/image";

export const getFAQs = (t: (key: string) => string) => [
	{
		title: t('faqSection.whatIsRakuEarn.title'),
		description: t('faqSection.whatIsRakuEarn.description'),
		order: 0
	},
	{
		title: t('faqSection.howDoesThisActuallyWork.title'),
		description: t('faqSection.howDoesThisActuallyWork.description'),
		order: 1
	},
	{
		title: t('faqSection.howDoIGetStarted.title'),
		description: t('faqSection.howDoIGetStarted.description'),
		order: 2
	},
	{
		title: t('faqSection.isRakuEarnFreeToUse.title'),
		description: t('faqSection.isRakuEarnFreeToUse.description'),
		order: 3
	},
	{
		title: t('faqSection.doINeedToFillOutSurveysMyself.title'),
		description: t('faqSection.doINeedToFillOutSurveysMyself.description'),
		order: 4
	},
	{
		title: t('faqSection.howCanIRedeemMyPoints.title'),
		description: t('faqSection.howCanIRedeemMyPoints.description'),
		order: 5
	},
	{
		title: t('faqSection.canIUseTheAIOnOtherSites.title'),
		description: t('faqSection.canIUseTheAIOnOtherSites.description'),
		order: 6
	},
	{
		title: t('faqSection.theAIDidntWorkWhatShouldIDo.title'),
		description: t('faqSection.theAIDidntWorkWhatShouldIDo.description'),
		order: 7
	},
]

export const getHowToUseSteps = (t: (key: string) => string) => [
	{
		number: 1,
		title: t("howToUseRakuEarn.step1.title"),
		description: t("howToUseRakuEarn.step1.description"),
		image: Step1Img
	},
	{
		number: 2,
		title: t("howToUseRakuEarn.step2.title"),
		description: t("howToUseRakuEarn.step2.description"),
		image: Step2Img
	},
	{
		number: 3,
		title: t("howToUseRakuEarn.step3.title"),
		description: t("howToUseRakuEarn.step3.description"),
		image: Step3Img
	},
	{
		number: 4,
		title: t("howToUseRakuEarn.step4.title"),
		description: t("howToUseRakuEarn.step4.description"),
		image: Step4Img
	},
	{
		number: 5,
		title: t("howToUseRakuEarn.step5.title"),
		description: t("howToUseRakuEarn.step5.description"),
		image: Step5Img
	},
	{
		number: 6,
		title: t("howToUseRakuEarn.step6.title"),
		description: t("howToUseRakuEarn.step6.description"),
		image: Step6Img
	},
];

export const getRedemptionSteps = (t: (key: string) => string) => [
	{
		number: 1,
		title: t("redemptionSection.step1.title"),
		description: t("redemptionSection.step1.description"),
		image: Redemption1,
	},
	{
		number: 2,
		title: t("redemptionSection.step2.title"),
		description: t("redemptionSection.step2.description"),
		image: Redemption2,
	},
	{
		number: 3,
		title: t("redemptionSection.step3.title"),
		description: t("redemptionSection.step3.description"),
		image: Redemption3,
	},
];

interface RedemptionOption {
	icon: StaticImageData;
	title: string;
}

export const getRedemptionOptions = (t: (key: string) => string): RedemptionOption[] => [
	{ icon: BankTransferLogo, title: t("redemptionSection.bankTransfer") },
	{ icon: AmazonLogo, title: "Amazon" },
	{ icon: AppleLogo, title: t("redemptionSection.appleStore") },
	{ icon: GooglePlayLogo, title: t("redemptionSection.googlePlay") },
	{ icon: PayPayLogo, title: t("redemptionSection.payPay") },
];

interface PaymentCard {	
	icon: StaticImageData;
	title: string;
	id: string;
}

type PaymentCards = {
	bankTransfer: PaymentCard;
	amazon: PaymentCard;
	apple: PaymentCard;
	googlePlay: PaymentCard;
	payPay: PaymentCard;
}

export const getPaymentCardImg = (t: (key: string) => string): PaymentCards => {
	return {
		bankTransfer: { icon: BankTransferLogo, title: t("paymentCard.bank"), id: "bankTransfer" },
		amazon: { icon: AmazonLogo, title: t("paymentCard.amazon"), id: "amazon" },
		apple: { icon: AppleLogo, title: t("paymentCard.apple"), id: "apple" },
		googlePlay: { icon: GooglePlayLogo, title: t("paymentCard.google"), id: "googlePlay" },
		payPay: { icon: PayPayLogo, title: t("paymentCard.paypay"), id: "payPay" },
	};
};

export const getExchangeDetails = (t: (key: string) => string) => [
	{
		title: t("exchangeDetails.exchangeRate"),
		content: t("exchangeDetails.exchangeRateContent"),
		rounded: "rounded-tl-3xl",
		className: "border-b border-solid border-b-zinc-300",
	},
	{
		title: t("exchangeDetails.exchangeDelivery"),
		content: t("exchangeDetails.exchangeDeliveryTime"),
		rounded: "",
		className: "border-b border-solid border-b-zinc-300",
	},
	{
		title: t("exchangeDetails.exchangeFee"),
		content: t("exchangeDetails.exchangeFeeAmount"),
		rounded: "rounded-bl-3xl",
		className: "",
	},
];

export const getExchangeProcedure = (t: (key: string) => string) => [
	{
		title: t("exchangeProcedure.step1.title"),
		description: t("exchangeProcedure.step1.description"),
		rounded: "rounded-tl-3xl",
		className: "border-b border-solid border-b-zinc-300",
	},
	{
		title: t("exchangeProcedure.step2.title"),
		description: t("exchangeProcedure.step2.description"),
		rounded: "",
		className: "border-b border-solid border-b-zinc-300",
	},
	{
		title: t("exchangeProcedure.step3.title"),
		description: t("exchangeProcedure.step3.description"),
		rounded: "",
		className: "border-b border-solid border-b-zinc-300",
	},
	{
		title: t("exchangeProcedure.step4.title"),
		description: t("exchangeProcedure.step4.description"),
		rounded: "rounded-bl-3xl",
		className: "",
	},
];

export const getHistoryItems = (t: (key: string) => string) => [
	{
		title:
			t("historyItems.title"),
		points: 1000,
		date: "4/9/2024",
	},
	{
		title:
			t("historyItems.title"),
		points: 1000,
		date: "4/9/2024",
	},
	{
		title:
			t("historyItems.title"),
		points: 1000,
		date: "4/9/2024",
	},
	{
		title:
			t("historyItems.title"),
		points: 1000,
		date: "4/9/2024",
	},
];

export interface ExchangeHistoryItem {
	image: StaticImageData;
	title: string;
	amount: string;
	status: "pending" | "complete" | "declined";
	date: string;
}
export const getExchangeHistoryItems = (t: (key: string) => string): ExchangeHistoryItem[] => [
	{
		image: AmazonLogo,
		title: t("exchangeHistoryItems.amazon"),
		amount: "1,000 ",
		status: "pending",
		date: "4/9/2024",
	},
	{
		image: GooglePlayLogo,
		title: t("exchangeHistoryItems.googlePlay"),
		amount: "300 ",
		status: "complete",
		date: "4/9/2024",
	},
	{
		image: GooglePlayLogo,
		title: t("exchangeHistoryItems.googlePlay"),
		amount: "300 ",
		status: "declined",
		date: "4/9/2024",
	},
];

export const getHeaderLinks = (t: (key: string) => string, lng: any) => [
	{ title: t("howItWorks"), href: `/${lng}/how-it-works` },
	{ title: t("surveyList"), href: `/${lng}/survey-list` },
	{ title: t("pointExchange"), href: `/${lng}/point-exchange` },
	// {title: "My Account", href: "/me"}
]

export const getPrefectures = (t: (key: string) => string) => [
	t("prefectures.hokkaido"),
	t("prefectures.aomori"),
	t("prefectures.iwate"),
	t("prefectures.miyagi"),
	t("prefectures.akita"),
	t("prefectures.yamagata"),
	t("prefectures.fukushima"),
	t("prefectures.ibaraki"),
	t("prefectures.tochigi"),
	t("prefectures.gunma"),
	t("prefectures.saitama"),
	t("prefectures.chiba"),
	t("prefectures.tokyo"),
	t("prefectures.kanagawa"),
	t("prefectures.niigata"),
	t("prefectures.toyama"),
	t("prefectures.ishikawa"),
	t("prefectures.fukui"),
	t("prefectures.yamanashi"),
	t("prefectures.nagano"),
	t("prefectures.gifu"),
	t("prefectures.shizuoka"),
	t("prefectures.aichi"),
	t("prefectures.mie"),
	t("prefectures.shiga"),
	t("prefectures.kyoto"),
	t("prefectures.osaka"),
	t("prefectures.hyogo"),
	t("prefectures.nara"),
	t("prefectures.wakayama"),
	t("prefectures.tottori"),
	t("prefectures.shimane"),
	t("prefectures.okayama"),
	t("prefectures.hiroshima"),
	t("prefectures.yamaguchi"),
	t("prefectures.tokushima"),
	t("prefectures.kagawa"),
	t("prefectures.ehime"),
	t("prefectures.kochi"),
	t("prefectures.fukuoka"),
	t("prefectures.saga"),
	t("prefectures.nagasaki"),
	t("prefectures.kumamoto"),
	t("prefectures.oita"),
	t("prefectures.miyazaki"),
	t("prefectures.kagoshima"),
	t("prefectures.okinawa"),
]

export const SurveyLink = "https://www16.webcas.net/form/pub/ceres/kurashi?media=moppy&xuid=xuid5x9633339b07x978";
export const SurveyFile = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/survey-files/`