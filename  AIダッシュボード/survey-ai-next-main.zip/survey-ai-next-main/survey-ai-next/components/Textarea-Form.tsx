import GradientToggle from "./ui/gradient-toggle";


const TextAreaForm = ({ label, name, value, onChange, placeholder }) => {    
    return (
        <div className="flex flex-col  w-user-form-width">
                            <div>
                                <GradientToggle label={"Additional Information"}/>
                            </div>
                            <div className="p-4 flex flex-col gap-2 h-52">
                                <label htmlFor="address" className="text-black" hidden></label>
                                <textarea id="address" name="address" className="p-2 rounded-lg bg-white resize-none h-52 text-black" placeholder={placeholder.additionalInfo}></textarea>
                            </div>  
        
        
                        </div>
        
    );
};

export default TextAreaForm;