import React from "react";
import { useT } from "@/app/i18n/client";
import Link from "next/link";
export const LoginRequiredModal: React.FC<{ setLoginRequiredModal: (modal: boolean) => void, modalRef: React.RefObject<HTMLDivElement | null>, lng: string }> = ({ setLoginRequiredModal, modalRef, lng }) => {
	const { t } = useT('pointExchange');
	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" ref={modalRef}>
			<div className="bg-white flex flex-col gap-2 items-center p-8 rounded-lg z-50" onClick={(e) => e.stopPropagation()}>
				<h2 className="text-2xl font-bold mb-4">{t("loginRequiredModal.title")}</h2>
				<div className="flex flex-col w-[500px]">
					<p className="mb-4 text-center">{t("loginRequiredModal.description1")} <br />{t("loginRequiredModal.description2")}</p>
				</div>
				<div className="flex gap-2">
					<Link href={`/${lng}/login`} className="bg-[#8771EF] w-[150px] text-center rounded-[100px] text-white px-4 py-2" onClick={() => setLoginRequiredModal(false)}>{t("loginRequiredModal.loginButton")}</Link>
					<Link href={`/${lng}/register`} className="bg-[#8771EF] w-[150px] text-center rounded-[100px] text-white px-4 py-2" onClick={() => setLoginRequiredModal(false)}>{t("loginRequiredModal.createAccountButton")}</Link>
				</div>
			</div>
		</div>
	);
};
