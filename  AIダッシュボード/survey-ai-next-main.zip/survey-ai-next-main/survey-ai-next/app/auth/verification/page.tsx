import VerificationForm from '@/components/authentication/VerificationForm';

const page = () => {
  return (
    <VerificationForm />
  )
}

export default page;