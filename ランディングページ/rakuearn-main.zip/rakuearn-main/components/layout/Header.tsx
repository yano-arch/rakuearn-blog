"use client";
import React, { useState, useEffect } from "react";
import { useT } from "@/app/i18n/client";
import Button from "./Button";
import Link from "next/link";
import { ChevronRight, UserRound, X, Menu } from "lucide-react";
import { getHeaderLinks } from "@/constants/constants";
import { useRouter, useParams } from "next/navigation";
import { getPoints } from "@/app/[lng]/admin/actions";
import Logo from "@/assets/images/logo.webp";
import Image from "next/image";
import { logout, getUser } from "@/app/[lng]/login/action";
const MobileLink = ({
  href,
  title,
  onClick,
}: {
  href: string;
  title: string;
  onClick: () => void;
}) => {
  return (
    <Link
      href={href}
      className="text-xl text-center font-bold text-black"
      onClick={onClick}
    >
      {title}
    </Link>
  );
};

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLogedin, setIsLogedin] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [points, setPoints] = useState(0);
  const { t } = useT("common");

  useEffect(() => {
    const fetchUser = async () => {
      const { user, error } = await getUser();
      if (error) {
        console.error("User retrieval failed", error);
      } else {
        console.log("User retrieved successfully", user);
        setIsLogedin(user !== null);
        console.log("user", user.user?.email);
        setUserEmail(user.user?.email || "");
      }
    };
    fetchUser();
  }, []);

  useEffect(() => {
    if (userEmail) {
      console.log("userEmail", userEmail);
      const fetchPoints = async () => {
        const _points = await getPoints(userEmail);
        if (_points) {
          console.log("Points retrieved successfully", _points);
          setPoints(_points);
        }
      };
      fetchPoints();
    }
  }, [userEmail]);

  const router = useRouter();
  const lng = useParams().lng;

  return (
    <header
      className="flex items-center justify-between py-8 max-sm:pb-2"
      aria-label="Header"
    >
      <div className="flex items-center gap-10 max-[906px]:hidden">
        <Link href={`/${lng}`} className="text-2xl font-bold">
          <Image
            src={Logo}
            alt="Logo"
            className="w-[172px]"
            aria-label="Logo"
          />
        </Link>
      </div>
      <div className="flex items-center gap-10">
        <nav
          className="flex gap-10 max-[906px]:hidden"
          aria-label="Main navigation"
        >
          <Link
            href={`/${lng}/how-it-works`}
            className="text-base font-bold text-black"
            aria-label="How it Works"
          >
            {t("howItWorks")}
          </Link>
          <Link
            href={`/${lng}/survey-list`}
            className="text-base font-bold text-black"
            aria-label="Survey List"
          >
            {t("surveyList")}
          </Link>
          <Link
            href={`/${lng}/point-exchange`}
            className="text-base font-bold text-black"
            aria-label="Point Exchange"
          >
            {t("pointExchange")}
          </Link>
        </nav>
        <div className="flex gap-2.5 max-[906px]:hidden">
          <Button
            variant="secondary"
            aria-label="AI Dashboard"
            onClick={() => window.open("https://app.rakuearn.com/", "_blank")}
          >
            {t("aiDashboard")}
          </Button>
          {isLogedin ? (
            <div
              className="relative"
              onMouseEnter={() => setIsOpen(true)}
              onMouseLeave={() => setIsOpen(false)}
            >
              <div className="flex cursor-pointer items-center justify-center p-3 rounded-full bg-neutral-100 hover:bg-neutral-200 gap-2">
                <UserRound color="black" width={30} height={30} />
              </div>

              {isOpen && (
                <>
                  <div className="absolute w-full h-2 -bottom-2"></div>

                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-100 py-2 z-50">
                    <div className="px-2">
                      <div className="flex items-center px-4 py-2 justify-between bg-[#F6F5F9] rounded-md">
                        <svg
                          width="18"
                          height="18"
                          viewBox="0 0 18 18"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <rect width="18" height="18" rx="9" fill="#FFC031" />
                          <path
                            d="M6.5748 13.25V5.06818H9.95459C10.5672 5.06818 11.0958 5.18803 11.5406 5.42773C11.9881 5.66477 12.333 5.99636 12.5753 6.4225C12.8177 6.84597 12.9389 7.33869 12.9389 7.90066C12.9389 8.46529 12.815 8.95934 12.5673 9.38281C12.3223 9.80362 11.9721 10.1299 11.5166 10.3616C11.0612 10.5933 10.5206 10.7092 9.89466 10.7092H7.80926V9.1511H9.52712C9.82542 9.1511 10.0744 9.09917 10.2742 8.99529C10.4766 8.89142 10.6297 8.74627 10.7336 8.55984C10.8375 8.37074 10.8894 8.15101 10.8894 7.90066C10.8894 7.64764 10.8375 7.42924 10.7336 7.24547C10.6297 7.05904 10.4766 6.91522 10.2742 6.81401C10.0718 6.7128 9.82275 6.6622 9.52712 6.6622H8.55233V13.25H6.5748Z"
                            fill="white"
                          />
                        </svg>
                        <p className="text-[#8771EF] font-bold">
                          {new Intl.NumberFormat("en-US").format(points)} P
                        </p>
                      </div>
                    </div>
                    <Link
                      href={`/${lng}/me`}
                      className="flex items-center justify-between px-4 py-2 text-sm text-gray-700 hover:bg-neutral-50"
                    >
                      <p>{t("myAccount")}</p>
                      <ChevronRight />
                    </Link>
                    <button
                      onClick={() => {
                        logout();
                        setIsLogedin(false);
                        router.push(`/${lng}`);
                      }}
                      className="flex items-center justify-between w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-neutral-50"
                    >
                      <p>{t("logout")}</p>
                      <ChevronRight />
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <Link
              href={`/${lng}/login`}
              className="bg-[#8771EF] text-white max-sm:text-lg cursor-pointer text-base font-bold rounded-[100px] px-8 py-4 flex items-center justify-center"
              aria-label="Login"
            >
              {t("login")}
            </Link>
          )}
        </div>
      </div>
      {/* Hamburger Navigation bar */}
      <div className="hidden relative max-[906px]:flex w-full px-2 items-center justify-center">
        <button
          className="hidden absolute top-1 left-3 max-[906px]:block mr-[20px]"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          <div className="space-y-2">
            <Menu size={40} color="black" />
          </div>
        </button>
        <div className="flex items-center gap-10">
          <Link href={`/${lng}`} className="text-2xl font-bold">
            <Image
              src={Logo}
              alt="Logo"
              className="w-[172px]"
              aria-label="Logo"
            />
          </Link>
        </div>
      </div>
      {/* Hamburger Menu Button */}

      {/* Mobile Menu */}
      <div
        className={`fixed top-0 left-0 h-full w-full bg-white z-50 transform transition-transform duration-400 pb-10 pt-3 ease-in-out  ${
          isMenuOpen ? "translate-x-0" : "-translate-x-full"
        } max-[906px]:block hidden`}
        aria-label="Mobile menu"
      >
        <div className="p-4 h-full">
          <div className="hidden relative mb-8 max-[906px]:flex w-full px-2 items-center justify-center">
            <button
              className="hidden absolute top-1 left-0 max-[906px]:block mr-[20px]"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              <div className="space-y-2">
                <X size={40} color="black" />
              </div>
            </button>
            <div className="flex items-center gap-10">
              <Link href={`/${lng}`} className="text-2xl font-bold">
                <Image
                  src={Logo}
                  alt="Logo"
                  className="w-[172px]"
                  aria-label="Logo"
                />
              </Link>
            </div>
          </div>
          <div className="flex h-[calc(100%-58px)] flex-col gap-4 items-center justify-between">
            <nav className="flex flex-col gap-6" aria-label="Mobile navigation">
              {getHeaderLinks(t, lng).map((link, index) => (
                <MobileLink
                  key={index}
                  title={link.title}
                  href={link.href}
                  onClick={() => setIsMenuOpen(false)}
                />
              ))}
            </nav>
            <div className="flex flex-col gap-6 mt-8">
              {isLogedin ? (
                <>
                  <MobileLink
                    title={t("myAccount")}
                    href={`/${lng}/me`}
                    onClick={() => setIsMenuOpen(false)}
                  />
                  <MobileLink
                    title={t("logout")}
                    href={`/${lng}`}
                    onClick={() => {
                      logout();
                      setIsLogedin(false);
                    }}
                  />
                  <div className="">
                    <div className="flex items-center px-4 py-4 justify-between bg-[#F6F5F9] rounded-[100px] w-[250px]">
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 18 18"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <rect width="18" height="18" rx="9" fill="#FFC031" />
                        <path
                          d="M6.5748 13.25V5.06818H9.95459C10.5672 5.06818 11.0958 5.18803 11.5406 5.42773C11.9881 5.66477 12.333 5.99636 12.5753 6.4225C12.8177 6.84597 12.9389 7.33869 12.9389 7.90066C12.9389 8.46529 12.815 8.95934 12.5673 9.38281C12.3223 9.80362 11.9721 10.1299 11.5166 10.3616C11.0612 10.5933 10.5206 10.7092 9.89466 10.7092H7.80926V9.1511H9.52712C9.82542 9.1511 10.0744 9.09917 10.2742 8.99529C10.4766 8.89142 10.6297 8.74627 10.7336 8.55984C10.8375 8.37074 10.8894 8.15101 10.8894 7.90066C10.8894 7.64764 10.8375 7.42924 10.7336 7.24547C10.6297 7.05904 10.4766 6.91522 10.2742 6.81401C10.0718 6.7128 9.82275 6.6622 9.52712 6.6622H8.55233V13.25H6.5748Z"
                          fill="white"
                        />
                      </svg>
                      <p className="text-[#8771EF] text-xl font-bold">
                        {new Intl.NumberFormat("en-US").format(points)} P
                      </p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <Link
                    href={`/${lng}/login`}
                    className="bg-[#8771EF] text-white w-[250px] max-sm:text-lg cursor-pointer text-base font-bold rounded-[100px] px-8 py-4 flex items-center justify-center"
                    aria-label="Login"
                  >
                    {t("login")}
                  </Link>
                  <Link
                    href={`/${lng}/register`}
                    className="border border-[#8771EF] text-[#8771EF] w-[250px] max-sm:text-lg cursor-pointer text-base font-bold rounded-[100px] px-8 py-4 flex items-center justify-center"
                    aria-label="Login"
                  >
                    {t("mobileRegister")}
                  </Link>
                </>
              )}
              <a
                href="https://app.rakuearn.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-neutral-100 text-black w-[250px] max-sm:text-lg cursor-pointer text-base font-bold rounded-[100px] px-8 py-4 flex items-center justify-center"
                aria-label="AI Dashboard"
              >
                {t("aiDashboard")}
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
