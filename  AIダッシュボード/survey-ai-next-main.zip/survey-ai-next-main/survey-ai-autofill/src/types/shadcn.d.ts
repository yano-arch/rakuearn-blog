declare module '@/components/ui/button' {
  import { ButtonHTMLAttributes } from 'react'
  
  export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link'
    size?: 'default' | 'sm' | 'lg' | 'icon'
  }
  
  export const Button: React.FC<ButtonProps>
}

declare module '@/components/ui/card' {
  import { HTMLAttributes } from 'react'
  
  export const Card: React.FC<HTMLAttributes<HTMLDivElement>>
  export const CardHeader: React.FC<HTMLAttributes<HTMLDivElement>>
  export const CardTitle: React.FC<HTMLAttributes<HTMLHeadingElement>>
  export const CardDescription: React.FC<HTMLAttributes<HTMLParagraphElement>>
  export const CardContent: React.FC<HTMLAttributes<HTMLDivElement>>
  export const CardFooter: React.FC<HTMLAttributes<HTMLDivElement>>
}

declare module '@/components/ui/input' {
  import { InputHTMLAttributes } from 'react'
  
  export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {}
  
  export const Input: React.FC<InputProps>
}

declare module '@/components/ui/label' {
  import { LabelHTMLAttributes } from 'react'
  
  export interface LabelProps extends LabelHTMLAttributes<HTMLLabelElement> {}
  
  export const Label: React.FC<LabelProps>
}

declare module '@/components/ui/switch' {
  import { InputHTMLAttributes } from 'react'
  
  export interface SwitchProps extends InputHTMLAttributes<HTMLInputElement> {}
  
  export const Switch: React.FC<SwitchProps>
}

declare module '@/components/ui/tabs' {
  import { HTMLAttributes } from 'react'
  
  export interface TabsProps extends HTMLAttributes<HTMLDivElement> {
    defaultValue?: string
    value?: string
    onValueChange?: (value: string) => void
  }
  
  export const Tabs: React.FC<TabsProps>
  export const TabsList: React.FC<HTMLAttributes<HTMLDivElement>>
  export const TabsTrigger: React.FC<HTMLAttributes<HTMLButtonElement> & { value: string }>
  export const TabsContent: React.FC<HTMLAttributes<HTMLDivElement> & { value: string }>
} 