"use client";

import { ResetSchema } from "@/schemas";
import { useTransition, useState } from "react";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from "@/components/ui/input";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/FormError";
import { FormSuccess } from "@/components/FormSuccess";
import { useSearchParams } from "next/navigation";
import { reset } from "@/actions/reset";


const ResetForm = () => {

  const searchParams =  useSearchParams();
  const urlError = searchParams.get("error") === "OAuthAccountNotLinked"
    ? "Email already in use with different provider!" : "";

  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | undefined>("");
  const [success, setSuccess] = useState<string | undefined>("");

  const form = useForm<z.infer<typeof ResetSchema>>({
    resolver: zodResolver(ResetSchema as any),
    defaultValues: {
      email: '',
    }
  })


  const onSubmit =  ( values: z.infer<typeof ResetSchema>) => {
    setError("");
    setSuccess("");
    
    startTransition(() => {
      reset(values)
        .then((data) => {
          setError(data?.error)
          setSuccess(data?.success)
        })
    })
  }

  return (
    <>
      <div className="mt-2 p-2">       
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField control={form.control} name="email" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Email</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="alex@example.com"
                        type="email"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                <FormError message={error || urlError}/>
                <FormSuccess message={success}/>
                <Button type="submit" className="credentials_buttons" disabled={isPending}>
                  Send reset email
                </Button>
            </form>
        </Form>
      </div>
    </>
  );
};

export default ResetForm;