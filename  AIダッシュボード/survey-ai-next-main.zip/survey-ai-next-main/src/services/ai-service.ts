import { UserProfile } from '../types/profile'

interface SurveyQuestion {
  type: 'radio' | 'checkbox' | 'text' | 'textarea' | 'select'
  question: string
  options?: string[]
  required: boolean
}

interface SurveyAnalysis {
  questions: SurveyQuestion[]
  context: string
  topic?: string
}

export class AIService {
  private userProfile: UserProfile | null = null
  private apiKey: string | null = null

  async initialize() {
    const storage = await chrome.storage.local.get(['userProfile', 'apiKey'])
    this.userProfile = storage.userProfile
    this.apiKey = storage.apiKey
  }

  async analyzeSurvey(form: HTMLFormElement): Promise<SurveyAnalysis> {
    const questions: SurveyQuestion[] = []
    
    // Extract all question elements
    const questionElements = form.querySelectorAll('.question, .survey-item, .form-group')
    questionElements.forEach(element => {
      const questionText = this.extractQuestionText(element)
      const type = this.determineQuestionType(element)
      const options = this.extractOptions(element)
      const required = element.querySelector('[required]') !== null

      questions.push({
        type,
        question: questionText,
        options,
        required
      })
    })

    // Extract survey context
    const context = this.extractSurveyContext(form)

    return {
      questions,
      context,
      topic: this.determineSurveyTopic(questions, context)
    }
  }

  async generateResponses(analysis: SurveyAnalysis): Promise<Record<string, string | string[]>> {
    if (!this.apiKey || !this.userProfile) {
      throw new Error('AI service not properly initialized')
    }

    const prompt = this.constructPrompt(analysis)
    
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are an AI assistant helping to fill out surveys. You should provide responses that are:
              1. Consistent with the user's profile and preferences
              2. Thoughtful and detailed for open-ended questions
              3. Natural and human-like
              4. Honest and ethical
              The user's profile: ${JSON.stringify(this.userProfile)}`
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.7
        })
      })

      const data = await response.json()
      return this.parseAIResponse(data.choices[0].message.content, analysis)
    } catch (error) {
      console.error('Error generating responses:', error)
      throw error
    }
  }

  private extractQuestionText(element: Element): string {
    const labelElement = element.querySelector('label, .question-text, .form-label')
    return labelElement?.textContent?.trim() || ''
  }

  private determineQuestionType(element: Element): SurveyQuestion['type'] {
    if (element.querySelector('input[type="radio"]')) return 'radio'
    if (element.querySelector('input[type="checkbox"]')) return 'checkbox'
    if (element.querySelector('select')) return 'select'
    if (element.querySelector('textarea')) return 'textarea'
    return 'text'
  }

  private extractOptions(element: Element): string[] | undefined {
    const options: string[] = []
    
    // Radio/Checkbox options
    element.querySelectorAll('input[type="radio"], input[type="checkbox"]').forEach(input => {
      const label = input.parentElement?.textContent?.trim()
      if (label) options.push(label)
    })

    // Select options
    element.querySelectorAll('select option').forEach(option => {
      const text = option.textContent?.trim()
      if (text && text !== 'Select...') options.push(text)
    })

    return options.length > 0 ? options : undefined
  }

  private extractSurveyContext(form: HTMLFormElement): string {
    // Try to find survey title or description
    const possibleContextElements = [
      document.querySelector('h1'),
      document.querySelector('.survey-title'),
      document.querySelector('.survey-description'),
      form.querySelector('h1'),
      form.querySelector('h2'),
      form.querySelector('.description')
    ]

    const contextTexts = possibleContextElements
      .filter(el => el !== null)
      .map(el => el?.textContent?.trim())
      .filter(text => text !== undefined) as string[]

    return contextTexts.join(' - ') || 'General Survey'
  }

  private determineSurveyTopic(questions: SurveyQuestion[], context: string): string {
    // Implement topic detection logic based on questions and context
    // This could be enhanced with more sophisticated NLP
    const allText = [context, ...questions.map(q => q.question)].join(' ').toLowerCase()
    
    const topicKeywords = {
      'customer satisfaction': ['satisfaction', 'experience', 'service', 'product'],
      'market research': ['market', 'product', 'brand', 'purchase'],
      'demographics': ['age', 'gender', 'income', 'education'],
      'feedback': ['feedback', 'improve', 'suggestion', 'recommend'],
      'healthcare': ['health', 'medical', 'wellness', 'symptoms'],
      'education': ['school', 'learning', 'course', 'education'],
      'employment': ['job', 'work', 'employer', 'workplace']
    }

    for (const [topic, keywords] of Object.entries(topicKeywords)) {
      if (keywords.some(keyword => allText.includes(keyword))) {
        return topic
      }
    }

    return 'general'
  }

  private constructPrompt(analysis: SurveyAnalysis): string {
    return `Please help me fill out this survey about "${analysis.topic}".
    Context: ${analysis.context}
    
    Questions to answer:
    ${analysis.questions.map(q => {
      const optionsText = q.options ? `\nOptions: ${q.options.join(', ')}` : ''
      return `- ${q.question} (Type: ${q.type})${optionsText}`
    }).join('\n')}
    
    Please provide natural, thoughtful responses that are consistent with my profile.
    For multiple choice questions, just specify the chosen option(s).
    For text responses, provide complete, well-thought-out answers.`
  }

  private parseAIResponse(response: string, analysis: SurveyAnalysis): Record<string, string | string[]> {
    // Implement response parsing logic
    // This is a simplified version - would need to be enhanced based on actual AI response format
    const responses: Record<string, string | string[]> = {}
    
    analysis.questions.forEach(question => {
      // Extract response for each question from AI's response
      // This would need to be implemented based on how we structure the AI's response
      responses[question.question] = this.extractResponseForQuestion(response, question)
    })

    return responses
  }

  private extractResponseForQuestion(response: string, question: SurveyQuestion): string | string[] {
    // Implement logic to extract specific response for a question from the AI's complete response
    // This is a placeholder - actual implementation would depend on response format
    return 'Response placeholder'
  }
} 