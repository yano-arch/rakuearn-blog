'use client';
import { Home, Settings, UserRound } from 'lucide-react';
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState, store } from "@/redux/store";
import { handleTabChange } from "@/redux/tabSlice";
import { useRouter } from "next/navigation";
import { usePathname } from "next/navigation";
import Image from "next/image";
import logo from '@/public/logo1.png';
import InstallExtension from './Install-Extension';
import { signOut } from 'next-auth/react';
const SideNavBar = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const activeTab = useSelector((state: RootState) => state.tabs.activeTab);

  const handleTabClick = (value: string) => {
    // Dispatch the action to handle tab change and update the activeTab in Redux
    dispatch(handleTabChange(value));

    // Navigation logic (same as before)
    switch (value) {
      case "dashboard":
        router.push("/overview");
        break;
      case "configuration":
        router.push("/configuration");
        break;
      case "settings":
        router.push("/settings");
        break;
      default:
        console.error("Unknown tab:", value);
    }
  };

  return (
    <div className="bg-white min-h-screen w-nav border-r relative border-gray-300 border-opacity-85">
      <div className='sticky h-96 min-h-screen overflow-hidden float-left top-0 left-0 pt-2 pb-2'>
      <div className="flex justify-center p-2">
      <Image src={logo} width={2500} height={843} layout="intrisic" alt="logo" className="object-contain mt-6"/>
      </div>
      <nav className="flex flex-col space-y-3 p-2 mt-5">
        {["dashboard", "configuration", "settings"].map((tab) => {
          const icon = tab === "dashboard" ? <Home /> : tab === "configuration" ? <UserRound /> : <Settings />;
          return (
          <button
            key={tab}
            className={`flex p-3.5 rounded-xl ${
              activeTab === tab
                ? "bg-custom-lpurple-active text-custom-dpurple-active text-sm font-semibold tracking-wide flex align-middle place-items-center"
                : "text-custom-inactive-text text-opacity-90 font-semibold text-sm tracking-wide flex align-middle place-items-center hover:bg-custom-lpurple-active text-custom-dpurple-active"
            }`}
            onClick={() => handleTabClick(tab)}
          >
            <span className="mr-4">{icon}</span>
            {tab === "dashboard" ? "Home" : tab === "configuration" ? "User Details" : "Settings"}
          </button>
          );
        })}
      </nav>
      <InstallExtension/>
    </div>
    </div>
  );
};

export default SideNavBar;
