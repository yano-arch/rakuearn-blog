import React, { useState } from "react";
import { useT } from "@/app/i18n/client";
import { requestResetPassword } from "../action";
import { toast, ToastContainer } from "react-toastify";

export const InputEmailModal: React.FC<{ setInputEmailModal: (modal: boolean) => void,  }> = ({ setInputEmailModal }) => {
	const { t } = useT('auth');
	const [email, setEmail] = useState('');
	const [isLoading, setIsLoading] = useState(false);
	const handleSubmit = async (email: string) => {
		if (!email) {
			toast.error("Email is required", {
				position: "top-right",
				autoClose: 3000,
				hideProgressBar: false,
				closeOnClick: true,
				pauseOnHover: true,
			});
			return;
		}
		setIsLoading(true);
		const { data, error } = await requestResetPassword(email);
		if (error) {
			toast.error("Failed to reset password", {
				position: "top-right",
				autoClose: 3000,
				hideProgressBar: false,
				closeOnClick: true,
				pauseOnHover: true,
			});
		} else {
			toast.success("Password reset email sent", {
				position: "top-right",
				autoClose: 3000,
				hideProgressBar: false,
				closeOnClick: true,
				pauseOnHover: true,
			});
		}
		setIsLoading(false);
	};


	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
			<ToastContainer />
			<div
				className="bg-white flex flex-col gap-2 items-center p-8 rounded-lg z-50"
				onClick={(e) => e.stopPropagation()}
			>
				<h2 className="text-2xl font-bold mb-4">{t("inputEmailModal.title")}</h2>
				<div className="flex flex-col items-center w-[500px]">
					<input
						type="email"
						placeholder="Email"
						value={email}
						onChange={(e) => setEmail(e.target.value)}
						className="w-[80%] border border-gray-300 rounded-lg p-2"
					/>
					<div className="flex gap-2 justify-center mt-5">
						<button
							type="submit"
							className="bg-[#8771EF] w-[150px] text-center rounded-[100px] text-white px-4 py-2"
							onClick={() => handleSubmit(email)}
							disabled={isLoading}
						>
							{t("inputEmailModal.send")}
						</button>
						<button type="button"
							className="bg-[#8771EF] w-[150px] text-center rounded-[100px] text-white px-4 py-2"
							onClick={() => setInputEmailModal(false)}
						>
							{t("inputEmailModal.cancel")}
						</button>
					</div>
				</div>
			</div>
		</div>
	);
};
