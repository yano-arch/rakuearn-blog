import React from "react";
import Button from "../layout/Button";
import { useT } from "@/app/i18n/client";
import { useRouter, useParams } from "next/navigation";
interface CTASectionProps {
  className?: string;
}

const CTASection: React.FC<CTASectionProps> = ({ className }) => {
  const { t } = useT('home');
  const router = useRouter();
  const lng = useParams().lng;
  return (
    <section className={`px-16 py-16 max-sm:px-8 max-sm:py-12 mx-2 max-md:mx-0 mb-6 text-center max-md:rounded-none rounded-[40px] bg-gradient-to-r from-[#C093FF] via-[#FFA9EC] to-[#FFC65B] bg-[length:100%_400%] animate-[gradient_8s_ease-in-out_infinite] ${className}`} aria-label="CTA section">
      <h2 className="mb-5 text-5xl font-bold text-white max-sm:text-2xl" aria-label="CTA title">
        {t('ctaSection.title')}
      </h2>
      <p className="mb-8 text-lg max-sm:text-xs font-semibold text-white" aria-label="CTA description">
        {t('ctaSection.description')}
      </p>
      <Button
        variant="white"
        className="mx-auto my-0 w-[173px] cursor-pointer max-sm:text-sm"
        ariaLabel="Get started with Raku Earn"
        onClick={() => router.push(`/${lng}/survey-list`)}
      >
        {t('ctaSection.getStarted')}
      </Button>
    </section>
  );
};

export default CTASection;
