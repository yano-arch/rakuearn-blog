import React from 'react'
import { useForm, useFieldArray } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent } from '@/components/ui/card'
import { Plus, Trash2, Globe } from 'lucide-react'

const sitesSchema = z.object({
  sites: z.array(z.object({
    url: z.string().url({ message: "Please enter a valid URL." }),
    enabled: z.boolean().default(true),
    name: z.string().min(2, { message: "Site name must be at least 2 characters." })
  }))
})

type SitesFormData = z.infer<typeof sitesSchema>

export function SitesForm() {
  const form = useForm<SitesFormData>({
    resolver: zodResolver(sitesSchema),
    defaultValues: {
      sites: [
        { url: "", enabled: true, name: "" }
      ]
    }
  })

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "sites"
  })

  React.useEffect(() => {
    // Load saved sites from extension storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['surveySites'], (result) => {
        if (result.surveySites) {
          form.reset({ sites: result.surveySites })
        }
      })
    }
  }, [form])

  const onSubmit = async (data: SitesFormData) => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      await chrome.storage.local.set({
        surveySites: data.sites
      })
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-4">
        {fields.map((field, index) => (
          <Card key={field.id} className="border border-zinc-200 dark:border-zinc-800">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-base flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    Survey Site {index + 1}
                  </Label>
                  <Switch
                    checked={form.watch(`sites.${index}.enabled`)}
                    onCheckedChange={(checked) => form.setValue(`sites.${index}.enabled`, checked)}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Site Name</Label>
                  <Input
                    {...form.register(`sites.${index}.name`)}
                    className="h-12 bg-white dark:bg-zinc-900"
                    placeholder="Prolific"
                  />
                </div>

                <div className="space-y-2">
                  <Label>URL Pattern</Label>
                  <div className="flex gap-2">
                    <Input
                      {...form.register(`sites.${index}.url`)}
                      className="h-12 bg-white dark:bg-zinc-900"
                      placeholder="https://app.prolific.co/submissions/complete?cc=*"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => remove(index)}
                      className="h-12 w-12 border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400">
                    Use * as a wildcard for dynamic parts of the URL
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex gap-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => append({ url: "", enabled: true, name: "" })}
          className="flex-1 h-12 border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Site
        </Button>

        <Button
          type="submit"
          className="flex-1 h-12 bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-900"
        >
          Save Sites
        </Button>
      </div>
    </form>
  )
} 