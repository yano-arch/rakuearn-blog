import { AIService } from '../services/ai-service'

const aiService = new AIService()

// Function to detect survey forms
async function detectSurvey() {
  const forms = document.querySelectorAll('form')
  const surveyForms = Array.from(forms).filter(form => {
    const inputs = form.querySelectorAll('input[type="radio"], input[type="checkbox"], textarea, select')
    return inputs.length > 5 // Basic heuristic for survey detection
  })

  if (surveyForms.length > 0) {
    await aiService.initialize()
    
    // Notify background script
    chrome.runtime.sendMessage({
      type: 'SURVEY_DETECTED',
      data: {
        url: window.location.href,
        formCount: surveyForms.length
      }
    })

    // Process each survey form
    for (const form of surveyForms) {
      try {
        const analysis = await aiService.analyzeSurvey(form)
        const responses = await aiService.generateResponses(analysis)
        await fillSurvey(form, responses)
      } catch (error) {
        console.error('Error processing survey:', error)
      }
    }
  }
}

// Function to fill survey with AI-generated responses
async function fillSurvey(form: HTMLFormElement, responses: Record<string, string | string[]>) {
  // Get extension status
  const { isEnabled } = await chrome.storage.local.get(['isEnabled'])
  if (!isEnabled) return

  // Process each question in the form
  const questionElements = form.querySelectorAll('.question, .survey-item, .form-group')
  questionElements.forEach(element => {
    const questionText = element.querySelector('label, .question-text, .form-label')?.textContent?.trim()
    if (!questionText || !responses[questionText]) return

    const response = responses[questionText]

    // Handle different input types
    element.querySelectorAll('input, textarea, select').forEach(input => {
      switch (input.type) {
        case 'radio':
        case 'checkbox':
          if (Array.isArray(response) && response.includes(input.value) ||
              response === input.value) {
            (input as HTMLInputElement).checked = true
          }
          break
        
        case 'text':
        case 'textarea':
          if (typeof response === 'string') {
            (input as HTMLInputElement | HTMLTextAreaElement).value = response
          }
          break
        
        case 'select-one':
          if (typeof response === 'string') {
            (input as HTMLSelectElement).value = response
          }
          break
      }

      // Trigger change event to activate any form validation
      input.dispatchEvent(new Event('change', { bubbles: true }))
    })
  })

  // Add a small delay for natural feeling
  await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500))
}

// Initialize survey detection
window.addEventListener('load', detectSurvey)

// Re-run detection on dynamic content changes
const observer = new MutationObserver(() => {
  detectSurvey()
})

observer.observe(document.body, {
  childList: true,
  subtree: true
}) 