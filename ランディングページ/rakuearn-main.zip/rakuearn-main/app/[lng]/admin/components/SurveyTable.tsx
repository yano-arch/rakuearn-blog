"use client";
import React from "react";
import Link from "next/link";
import { useT } from "@/app/i18n/client";
import { getSurveys } from "../actions";
interface Survey {
	title: string;
	points: number;
	provider: string;
	estimated_time: number;
	link: string;
	acs_promotion_id: string;
	file_path: string;
	created_at: string;
	id: string
}

export function SurveyTable({ setIsSurveyDetailOpen, setSelectedSurvey }: { setIsSurveyDetailOpen: (isOpen: boolean) => void, setSelectedSurvey: (survey: Survey) => void }) {
	const { t } = useT('admin');
	const [surveys, setSurveys] = React.useState<Survey[]>([]);
	const [isLoading, setIsLoading] = React.useState(true);

	React.useEffect(() => {
		const fetchSurveys = async () => {
			const surveys = await getSurveys();
			if ('error' in surveys) {
				console.error('Surveys retrieval failed', surveys.error);
			} else {
				setSurveys(surveys);
				setIsLoading(false);
			}
		};
		fetchSurveys();
	}, []);


	return (
		<div className="ml-5 w-[72%] max-md:ml-0 max-md:w-full mt-30 overflow-x-scroll" aria-label="Survey table section">
			<table className="w-full border-collapse" aria-label="Survey table">
				<thead>
					<tr className="border-b border-black" aria-label="Survey table header">
						<th className="py-4 px-6 text-left font-semibold" aria-label="Survey table header column">{t("title")}</th>
						<th className="py-4 px-6 text-right font-semibold" aria-label="Survey table header column">{t("points")}</th>
						<th className="py-4 px-6 text-center font-semibold" aria-label="Survey table header column">{t("posted")}</th>
						<th className="py-4 px-6 text-right font-semibold" aria-label="Survey table header column">{t("actions")}</th>
					</tr>
				</thead>
				<tbody>
					{isLoading ? (
						<tr>
							<td colSpan={4} className="pt-4 text-center">Loading...</td>
						</tr>
					) : (
						surveys.map((survey, index) => (
							<tr
								key={index}
								className={`border-b border-gray-100 cursor-pointer hover:bg-gray-50`}
								onClick={() => {
									setIsSurveyDetailOpen(true);
									setSelectedSurvey(survey);
								}}
							>
								<td className={`px-6 text-left ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Survey table data">
									{survey.title}
								</td>
								<td className={`py-2 px-6 text-right ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Survey table data">
									{survey.points.toLocaleString()} P
								</td>
								<td className={`py-2 px-6 text-center ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Survey table data">
									{new Date(survey.created_at).toLocaleDateString()}
								</td>
								<td className={`py-2 px-6 text-right ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Survey table data">
									<Link
										href={`/admin/`}
										className="font-medium"
									>
										{t("view")}
									</Link>
								</td>
							</tr>
						))
					)}
				</tbody>
			</table>
		</div>
	);
}