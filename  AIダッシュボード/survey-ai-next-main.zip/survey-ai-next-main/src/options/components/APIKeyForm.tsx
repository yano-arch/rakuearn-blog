import React from 'react'
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Key, Save } from "lucide-react"

const apiKeySchema = z.object({
  apiKey: z.string().min(20, { message: "Please enter a valid OpenAI API key." })
})

export function APIKeyForm() {
  const form = useForm<z.infer<typeof apiKeySchema>>({
    resolver: zodResolver(apiKeySchema),
    defaultValues: {
      apiKey: "",
    },
  })

  React.useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['apiKey'], (result) => {
        if (result.apiKey) {
          form.reset({ apiKey: result.apiKey })
        }
      })
    }
  }, [form])

  function onSubmit(values: z.infer<typeof apiKeySchema>) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({ apiKey: values.apiKey }, () => {
        console.log('API key saved')
      })
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="apiKey"
          render={({ field }) => (
            <FormItem className="space-y-2">
              <FormLabel className="text-base flex items-center gap-2">
                <Key className="w-4 h-4" />
                OpenAI API Key
              </FormLabel>
              <FormControl>
                <Input 
                  type="password"
                  placeholder="sk-..." 
                  {...field}
                  className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                />
              </FormControl>
              <FormDescription>
                Your OpenAI API key is required for AI-powered survey responses. Get one at{' '}
                <a 
                  href="https://platform.openai.com/api-keys" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-purple-600 hover:text-purple-700 underline"
                >
                  platform.openai.com
                </a>
              </FormDescription>
            </FormItem>
          )}
        />

        <Button 
          type="submit" 
          className="w-full h-12 text-base font-medium bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          Save API Key
        </Button>
      </form>
    </Form>
  )
} 