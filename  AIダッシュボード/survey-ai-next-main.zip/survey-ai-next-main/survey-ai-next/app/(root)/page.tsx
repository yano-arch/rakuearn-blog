import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div className="justify-center align-middle h-full w-full flex-col flex" >
        <div className="justify-center flex ">
          <Image alt="logo" width={700} height={700} src='/logo1.png'/>
        </div>
        <div className="text-black self-center m-3 font-mono">Fill Smarter, Not Harder - Powered with AI</div>
        <div className="flex flex-row  m-3 justify-center align-middle">
            <Link href={"/auth/login"} className="landing_buttons ">Login</Link>
            <Link href={"/auth/register"} className="landing_buttons ">Register</Link>
        </div>
    </div>
  );
}
