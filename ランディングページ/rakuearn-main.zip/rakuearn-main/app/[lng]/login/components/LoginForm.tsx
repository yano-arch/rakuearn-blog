"use client";

import React, { useState } from "react";
import { useParams } from "next/navigation";
import { createClient } from "@/utils/supabase/client";
import { InputEmailModal } from "./InputEmailModal";
import { type User } from "@supabase/supabase-js";
import { AuthButton } from "./AuthButton";
import { toast, ToastContainer } from "react-toastify";
import { useRouter } from "next/navigation";
import { useT } from "@/app/i18n/client";
import { login, getUser } from "../action";
import Link from "next/link";
export const LoginForm: React.FC = () => {
	const lng = useParams().lng;
	const [loading, setLoading] = useState(true)
	const router = useRouter();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [inputEmailModal, setInputEmailModal] = useState(false);
	const { t } = useT('auth');

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();
		
		// Handle login logic here
		if (validate()) {
			const result = await login({ email, password }, lng as string);
			if (result.error) {
				console.log(result);
				toast.error(result.error);
			} else {
				localStorage.setItem("user", JSON.stringify(result.user));
				if (result.user?.user?.user_metadata?.role === "admin") {
					router.push(`/${lng}/admin`);
				} else {
					router.push(`/${lng}/me`);
				}
			}
		}
	};

	const validate = () => {
		if (email === "" || password === "") {
			toast.error("Email and password are required");
			return false;
		}
		return true;
	}

	return (
		<div className="flex-1 bg-white px-10 py-6 rounded-3xl max-sm:p-5" aria-label="Login form">
			<ToastContainer />
			{inputEmailModal && <InputEmailModal setInputEmailModal={setInputEmailModal} />}
			<form onSubmit={handleSubmit}>
				<h2 className="mb-2 text-2xl max-sm:text-lg font-semibold" aria-label="Login title">{t("login.login")}</h2>
				<div className="mb-8 max-sm:mb-4 h-px bg-zinc-300 bg-opacity-90" />
				<div className="flex flex-col items-center w-full" aria-label="Login form content">
					<div className="self-center w-[90%]" aria-label="Login form content">
						<div className="mb-6" aria-label="Email input">
							<label
								htmlFor="email"
								className="mb-2.5 text-base font-medium block"
							>
								{t("login.email")}
							</label>
							<input
								id="email"
								type="email"
								value={email}
								onChange={(e) => setEmail(e.target.value)}
								className="px-4 py-0 w-full h-10 rounded-md border border-solid border-zinc-300 border-opacity-90"
								required
							/>
						</div>
						<div className="mb-6" aria-label="Password input">
							<label
								htmlFor="password"
								className="mb-2.5 text-base font-medium block"
							>
								{t("login.password")}
							</label>
							<input
								id="password"
								type="password"
								value={password}
								onChange={(e) => setPassword(e.target.value)}
								className="px-4 py-0 w-full h-10 rounded-md border border-solid border-zinc-300 border-opacity-90"
								required
							/>
						</div>
						<button
							type="button"
							className="mb-6 text-base font-medium cursor-pointer text-neutral-400"
							aria-label="Forgot password"
							onClick={() => setInputEmailModal(true)}
						>
							{t("login.forgotPassword")}
						</button>
						<AuthButton type="submit" fullWidth ariaLabel="Login button">
							{t("login.login")}
						</AuthButton>
					</div>
				</div>
			</form>
		</div>
	);
};
