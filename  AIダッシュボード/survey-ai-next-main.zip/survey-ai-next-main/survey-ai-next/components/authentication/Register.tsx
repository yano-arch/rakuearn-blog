"use client"

import { useState, useTransition } from "react";
import { RegisterSchema } from "@/schemas";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { register } from "@/actions/register";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { FormError } from "@/components/FormError";
import { FormSuccess } from "@/components/FormSuccess";
import { Button } from "@/components/ui/button";
import { signIn } from "next-auth/react";
import { FcGoogle } from "react-icons/fc";


const SignUp = () => {

  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | undefined>("");
  const [success, setSuccess] = useState<string | undefined>("");
  

    const onSubmit =  ( values: z.infer<typeof RegisterSchema>) => {
        setError("");
        setSuccess("");
        
        startTransition(() => {
          register(values)
            .then((data) => {
              setError(data?.error)
              setSuccess(data?.success)
            })
        })
      }
    const form = useForm<z.infer<typeof RegisterSchema>>({
      resolver: zodResolver(RegisterSchema as any),
      defaultValues: {
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
      }
    })

    

  return (
    <>
      <div className="mt-2 p-2">
      <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                <FormField control={form.control} name="name" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Name</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="Alex Lilth"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage  className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                <FormField control={form.control} name="email" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Email</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="alex@example.com"
                        type="email"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage  className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                  <FormField control={form.control} name="password" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Password</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="******"
                        type="password"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage  className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                <FormField control={form.control} name="confirmPassword" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Confirm Password</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="******"
                        type="password"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                </div>
                <FormError message={error}/>
                <FormSuccess message={success}/>
                <Button type="submit" className="credentials_buttons" disabled={isPending}>
                    Register
                </Button>
            </form>
        </Form>
        <button onClick={() => signIn('google')} className="mt-2 ouath_buttons ">
            <FcGoogle className="w-5 h-5 ml-2" />
        </button>
      </div>
    </>
  );
};

export default SignUp;
