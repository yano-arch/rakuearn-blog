require('dotenv').config()
import { NextRequest, NextResponse } from "next/server";

export default function POST (req: NextRequest, res: NextResponse) {

    // okay somehow i will need to grab the inputs and values from the 
    // html. so... 

    // in extension, there should be something making a post request to this api (localhost:3000/api/ai)
    // with all of the elements... so gonna open up that code.
    
}