// components/ui/chart.tsx
"use client";

import { ReactNode } from "react";
import { TooltipProps } from "recharts";
import { cn } from "@/lib/utils";

// Define the chart configuration type
export type ChartConfig = {
  [key: string]: {
    label: string;
    color: string;
  };
};

// Chart Container - Wraps the chart with provided config
export function ChartContainer({
  children,
  config,
}: {
  children: ReactNode;
  config: ChartConfig;
}) {
  return <div className="w-full h-[300px] bg-slate-100">{children}</div>;
}

// Chart Tooltip - Wrapper for tooltip content
export function ChartTooltip({
  active,
  payload,
  content,
}: TooltipProps<number, string> & { content: ReactNode }) {
  if (!active || !payload || payload.length === 0) return null;
  return <div className="relative">{content}</div>;
}

// Chart Tooltip Content - Styled tooltip display
export function ChartTooltipContent({
  payload,
  hideLabel = false,
}: {
  payload?: TooltipProps<number, string>["payload"];
  hideLabel?: boolean;
}) {
  if (!payload || payload.length === 0) return null;
  
  const data = payload[0];

  return (
    <div className="bg-white p-2 shadow-md rounded-lg border border-gray-200">
      {!hideLabel && <p className="text-xs text-gray-500">{data?.name}</p>}
      <p className="text-sm font-semibold text-gray-900">
        {data?.value} visitors
      </p>
    </div>
  );
}
