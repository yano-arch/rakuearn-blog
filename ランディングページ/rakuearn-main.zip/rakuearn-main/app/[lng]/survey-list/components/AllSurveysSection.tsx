"use client";
import React, { useState, useEffect } from "react";
import { SurveyCard } from "./SurveyCard";
import { ChevronDown, LayoutGrid } from "lucide-react";
import { useT } from "@/app/i18n/client";
import { SurveyFile } from "@/constants/constants";
export const AllSurveysSection: React.FC<{ allSurveys: any[] | {error: string} | null }> = ({ allSurveys }) => {
	const { t } = useT('surveyList');
	const [sortBy, setSortBy] = useState("date_added");
	const [sortedSurveys, setSortedSurveys] = useState<any[] | {error: string} | null>(null);

	useEffect(() => {
		setSortedSurveys(allSurveys);
	}, [allSurveys]);

	useEffect(() => {
		handleSortChange(sortBy);
	}, [sortBy]);

	const handleSortChange = (sortBy: string) => {
		if (allSurveys && 'error' in allSurveys) {
			return;
		}
		const sortedSurveys = [...(allSurveys || [])].sort((a, b) => {
			if (sortBy === "date_added") {
				return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
			}
			if (sortBy === "reward") {
				return b.points - a.points;
			}
			if (sortBy === "estimated_time") {
				return b.estimated_time - a.estimated_time;
			}
			if (sortBy === "popularity") {
				return b.popularity - a.popularity;
			}
			return 0;
		});
		setSortedSurveys(sortedSurveys);
	};

	return (
		<section className="mt-40 max-md:mt-14 max-md:pb-10" aria-label="All surveys section">
			<div className="flex gap-2 items-center mb-8 max-sm:mb-4" aria-label="All surveys section title">
			<LayoutGrid color="#8771EF" />
				<h2 className="text-2xl max-sm:text-xl font-bold text-violet-500">{t('allSurveysSection.title')}</h2>
				<div className="flex gap-2 items-center ml-auto">
					<label
						htmlFor="sort-select"
						className="text-base max-sm:text-sm font-medium text-black max-sm:hidden"
					>
						{t('allSurveysSection.sortBy')}
					</label>
					<div className="relative">
						<select
							id="sort-select"
							value={sortBy}
							aria-label="Sort by select"
							onChange={(e) => setSortBy(e.target.value)}
							className="px-4 max-sm:text-xs py-2 relative rounded-lg border border-zinc-300 appearance-none bg-white cursor-pointer max-sm:w-[120px] w-[160px]"
						>
							<option value="date_added">{t('allSurveysSection.dateAdded')}</option>
							<option value="reward">{t('allSurveysSection.rewardAmount')}</option>
							<option value="estimated_time">{t('allSurveysSection.estimatedTime')}</option>
							<option value="popularity">{t('allSurveysSection.popularity')}</option>
						</select>
						<ChevronDown className="absolute pointer-events-none right-2 max-sm:right-1 top-1/2 -translate-y-1/2" />
					</div>
				</div>
			</div>
			<div className="grid gap-5 mb-10 grid-cols-[repeat(5,1fr)] max-[1200px]:grid-cols-[repeat(4,1fr)] max-md:grid-cols-[repeat(3,1fr)] max-sm:grid-cols-[repeat(2,1fr)]" aria-label="All surveys cards">
				{sortedSurveys && 'error' in sortedSurveys ? (
					<div className="text-center text-red-500">
						{sortedSurveys.error}
					</div>
				) : (
					sortedSurveys?.map((survey) => (
						<SurveyCard
							key={survey.id}
							id={survey.id}
							title={survey.title}
							points={survey.points}
							dateAdded={survey.created_at}
							imageUrl={SurveyFile + survey.file_path}
						/>
					))
				)}
			</div>
			<div className="flex justify-center mx-0 my-10" aria-label="Show more button">
				<button className="flex gap-2 items-center cursor-pointer px-8 py-5 text-base font-bold bg-neutral-100 rounded-[100px]" aria-label="Show more button">
					<span>{t('allSurveysSection.showMore')}</span>
					<ChevronDown />
				</button>
			</div>
		</section>
	);
};


