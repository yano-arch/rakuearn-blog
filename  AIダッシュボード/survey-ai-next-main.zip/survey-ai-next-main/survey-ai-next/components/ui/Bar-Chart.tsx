"use client";

import { Bar, BarChart, CartesianGrid, XAxis, Tooltip, ResponsiveContainer } from "recharts";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/chart-card";

const chartData = [
  { day: "M", points: 186 },
  { day: "T", points: 305 },
  { day: "W", points: 237 },
  { day: "T", points: 73 },
  { day: "F", points: 209 },
  { day: "S", points: 214 },
  { day: "S", points: 230 },
];

// Custom Tooltip Component
const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-custom-darkest-purple text-white p-2 rounded-md shadow-md">
        <p className="text-xs font-semibold">{payload[0].payload.day}</p>
        <p className="text-sm font-bold">{payload[0].value} Points</p>
      </div>
    );
  }
  return null;
};

export function BarChartGraph() {
  return (
    <div className="w-full h-full">
      <Card>
        <CardHeader>
          <CardTitle>Bar Chart</CardTitle>
        </CardHeader>
        <CardContent className="w-full h-[350px]">
          {/* Make chart responsive */}
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="day" className="font-bold text-custom-darkest-purple" />
              {/* ^ this isn't changing the font color for some reason */}
              {/* Custom tooltip with hover color */}
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="points"
                fill="hsl(var(--custom-chart-purple))"
                radius={[4, 4, 0, 0]} // Rounded top edges
                barSize={20}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}

