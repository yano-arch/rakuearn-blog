import { AIService } from '../services/ai-service'

const aiService = new AIService()

// Initialize extension state
chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({
    isEnabled: false,
    userProfile: null,
    apiKey: null,
    surveySites: [],
    schedule: {
      enabled: true,
      startTime: "09:00",
      endTime: "17:00",
      maxSurveysPerDay: 10,
      minDelayBetweenSurveys: 5
    }
  })
  
  console.log('Survey AI Autofill extension installed')
})

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SURVEY_DETECTED') {
    handleSurveyDetection(message.data, sender.tab?.id)
    sendResponse({ success: true })
  }
  return true
})

// Handle survey detection
async function handleSurveyDetection(data: { url: string, formCount: number }, tabId?: number) {
  const storage = await chrome.storage.local.get([
    'isEnabled',
    'surveySites',
    'schedule'
  ])

  if (!storage.isEnabled) {
    console.log('Extension is disabled')
    return
  }

  // Check if the URL matches any configured survey sites
  const isAllowedSite = storage.surveySites.some((site: { url: string, enabled: boolean }) => {
    if (!site.enabled) return false
    const pattern = site.url.replace(/\*/g, '.*')
    return new RegExp(pattern).test(data.url)
  })

  if (!isAllowedSite) {
    console.log('Not a configured survey site:', data.url)
    return
  }

  // Check if within scheduled hours
  const now = new Date()
  const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
  
  if (storage.schedule.enabled &&
      (currentTime < storage.schedule.startTime || currentTime > storage.schedule.endTime)) {
    console.log('Outside of scheduled hours')
    return
  }

  // Update extension icon to show active state
  if (tabId) {
    chrome.action.setBadgeText({
      text: '🤖',
      tabId
    })
  }

  console.log('Processing survey:', data)
}

// Monitor survey completion stats
let dailySurveyCount = 0
let lastSurveyTime: Date | null = null

// Reset daily counter at midnight
setInterval(async () => {
  const now = new Date()
  if (now.getHours() === 0 && now.getMinutes() === 0) {
    dailySurveyCount = 0
    await chrome.storage.local.set({ dailySurveyCount: 0 })
  }
}, 60000) // Check every minute 