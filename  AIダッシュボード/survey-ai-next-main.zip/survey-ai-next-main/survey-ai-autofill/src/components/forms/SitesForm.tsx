import React from 'react'
import { useForm, useFieldArray } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent } from '@/components/ui/card'
import { Plus, Trash2 } from 'lucide-react'

const siteSchema = z.object({
  sites: z.array(z.object({
    url: z.string().min(1, 'URL is required'),
    enabled: z.boolean().default(true)
  }))
})

type SitesFormData = z.infer<typeof siteSchema>

export function SitesForm() {
  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<SitesFormData>({
    resolver: zodResolver(siteSchema),
    defaultValues: {
      sites: []
    }
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'sites'
  })

  React.useEffect(() => {
    // Load saved sites
    chrome.storage.local.get(['surveySites'], (result) => {
      if (result.surveySites) {
        reset({ sites: result.surveySites })
      }
    })
  }, [reset])

  const onSubmit = async (data: SitesFormData) => {
    await chrome.storage.local.set({
      surveySites: data.sites
    })
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {fields.map((field, index) => (
              <div key={field.id} className="flex items-start space-x-4">
                <div className="flex-1 space-y-2">
                  <Label>Site URL Pattern</Label>
                  <Input
                    {...register(`sites.${index}.url`)}
                    placeholder="e.g. https://*.surveysite.com/*"
                    className={errors.sites?.[index]?.url ? 'border-destructive' : ''}
                  />
                  {errors.sites?.[index]?.url && (
                    <p className="text-sm text-destructive">{errors.sites[index]?.url?.message}</p>
                  )}
                </div>
                <div className="space-y-2 pt-7">
                  <Switch
                    {...register(`sites.${index}.enabled`)}
                  />
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="mt-7"
                  onClick={() => remove(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex space-x-4">
        <Button
          type="button"
          variant="outline"
          className="flex-1"
          onClick={() => append({ url: '', enabled: true })}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Site
        </Button>
        <Button type="submit" className="flex-1">
          Save Sites
        </Button>
      </div>
    </form>
  )
} 