"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { RequiredLabel } from "./RequiredLabel";
import { signup } from "@/app/[lng]/login/action";
import { RadioButton } from "@/app/[lng]/account-setting/components/RadioButton";
import { DateSelector } from "@/app/[lng]/account-setting/components/DateSelector";
import { UserProfile } from "@/app/[lng]/account-setting/components/AccountForm";
import { getPrefectures } from "@/constants/constants";
import { ChevronDown, Loader2 } from "lucide-react";
import { useT } from "@/app/i18n/client";
import { useParams } from "next/navigation";
import { toast, ToastContainer } from "react-toastify";
export function RegistrationForm() {
  const { t } = useT('auth');
  const lng = useParams().lng;
  const router = useRouter();

  const [userProfile, setUserProfile] = useState<UserProfile>({
    nickname: "",
    email: "",
    pwd: "",
    dob: new Date(),
    confirmPwd: "",
    gender: "male",
    prefectures: "Hokkaido",
    role: "user",
    id: ""
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [confirmPwd, setConfirmPwd] = useState<string>("");
  const [agreeToTheTermsOfUseAndPrivacyPolicy, setAgreeToTheTermsOfUseAndPrivacyPolicy] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); // Prevent the default form submission behavior
    if (validate()) {
      setIsLoading(true);
      const result = await signup(userProfile, lng as string);
      console.log(result);
      if (result.error) {
        toast.error("Failed register", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
        })
      } else {
        toast.success("Successfully registered. We sent you an email to verify your account. Please check your email.", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
        });
        // router.push(`/${lng}/me`);
      }
      setIsLoading(false);
    }
  };

  const validate = () => {
    if (userProfile.nickname === "") {
      toast.error("Nickname is required");
      return false;
    }
    if (userProfile.email === "") {
      toast.error("Email is required");
      return false;
    }
    if (userProfile.pwd === "" || userProfile.pwd.length < 8) {
      toast.error("Password is required and must be at least 8 characters long");
      return false;
    }
    if (userProfile.pwd !== confirmPwd) {
      toast.error("Password and confirm password do not match");
      return false;
    }
    if (userProfile.dob === new Date()) {
      toast.error("Date of birth is required");
      return false;
    }
    if (userProfile.gender === "") {
      toast.error("Gender is required");
      return false;
    }
    if (userProfile.prefectures === "") {
      toast.error("Prefectures is required");
      return false;
    }
    if (!agreeToTheTermsOfUseAndPrivacyPolicy) {
      toast.error("You must agree to the terms of use and privacy policy");
      return false;
    }
    return true;
  }


  return (
    <form aria-label="Registration form" onSubmit={handleSubmit}>
      <h2 className="mb-2 text-2xl max-sm:text-lg font-semibold text-black" aria-label="Registration form title">
        {t("register.basicInformation")}
      </h2>
      <ToastContainer />
      <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Registration form nickname">
        <RequiredLabel text={t("register.nickname")} />
        <input
          type="text"
          id="nickname"
          aria-label="Enter your nickname"
          placeholder={t("register.nickname")}
          required
          className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
          value={userProfile.nickname}
          onChange={(e) => setUserProfile({ ...userProfile, nickname: e.target.value })}
        />
      </div>

      <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Registration form email address">
        <RequiredLabel text={t("register.emailAddress")} />
        <input
          type="email"
          id="email"
          aria-label="Enter your email address"
          placeholder={t("register.emailAddress")}
          required
          className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
          value={userProfile.email}
          onChange={(e) => setUserProfile({ ...userProfile, email: e.target.value })}
        />
      </div>

      <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-start gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Registration form password">
        <RequiredLabel text={t("register.password")} />
        <div className="flex flex-col gap-2.5 max-sm:gap-0">
          <input
            type="password"
            id="password"
            aria-label="Enter your password"
            placeholder={t("register.password")}
            required
            className="px-4 py-0 mb-5 max-sm:mb-2 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
            value={userProfile.pwd}
            onChange={(e) => setUserProfile({ ...userProfile, pwd: e.target.value })}
          />
          <input
            type="password"
            id="confirm-password"
            aria-label="Confirm your password"
            placeholder={t("register.confirmPassword")}
            required
            className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
            value={confirmPwd}
            onChange={(e) => setConfirmPwd(e.target.value)}
          />
        </div>
      </div>

      <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Registration form date of birth">
        <RequiredLabel text={t("register.dateOfBirth")} />
        <div className="flex gap-2.5 max-sm:flex-col">
          <DateSelector value={userProfile.dob} onChange={(date) => setUserProfile({ ...userProfile, dob: date })} />
        </div>
      </div>

      <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Registration form gender">
        <RequiredLabel text={t("register.gender")} />
        <div className="flex gap-12 max-sm:flex-col max-sm:gap-5">
          <RadioButton
            label={t("register.male")}
            checked={userProfile.gender === "male"}
            name="gender"
            onChange={() => setUserProfile({ ...userProfile, gender: "male" })}
          />
          <RadioButton
            label={t("register.female")}
            checked={userProfile.gender === "female"}
            name="gender"
            onChange={() => setUserProfile({ ...userProfile, gender: "female" })}
          />
          <RadioButton
            label={t("register.others")}
            checked={userProfile.gender === "others"}
            name="gender"
            onChange={() => setUserProfile({ ...userProfile, gender: "others" })}
          />
        </div>
      </div>

      <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Registration form prefectures">
        <RequiredLabel text={t("register.prefectures")} />
        <div className="relative">
          <select className="px-4 py-2 relative rounded-lg border border-zinc-300 appearance-none bg-white cursor-pointer w-[150px] max-sm:w-full" defaultValue={userProfile.prefectures} onChange={(e) => setUserProfile({ ...userProfile, prefectures: e.target.value })}>
            {getPrefectures(t).map((prefecture) => (
              <option key={prefecture} value={prefecture}>{prefecture}</option>
            ))}
          </select>
          <ChevronDown className="absolute pointer-events-none right-2 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <section className="mt-16" aria-label="Registration form agreements on terms of use">
        <div className="flex gap-5 items-center mb-7" aria-label="Registration form agreements on terms of use title">
          <h2 className="text-2xl max-sm:text-xl font-semibold text-black" aria-label="Registration form agreements on terms of use title">
            {t("register.agreementsOnTermsOfUse")}
          </h2>
          <div className="px-2.5 py-0.5 text-xs font-bold text-white bg-red-600 rounded-md" aria-label="Registration form agreements on terms of use required">
            {t("register.required")}
          </div>
        </div>
        <div className="flex flex-col gap-5 mb-5">
          <a href="#" className="text-base text-blue-600 no-underline">
            {t("register.termsOfUse")}
          </a>
          <a href="#" className="text-base text-blue-600 no-underline">
            {t("register.privatePolicy")}
          </a>
        </div>
        <div className="flex gap-5 items-center mt-7" aria-label="Registration form agree to the terms of use and privacy policy">
          <input
            type="checkbox"
            id="agree"
            className="w-5 h-5 rounded-sm border border-solid border-zinc-300 border-opacity-90"
            onChange={() => setAgreeToTheTermsOfUseAndPrivacyPolicy(!agreeToTheTermsOfUseAndPrivacyPolicy)}
          />
          <label htmlFor="agree">
            {t("register.agreeToTheTermsOfUseAndPrivacyPolicy")}
          </label>
        </div>
      </section>

      <div className="flex justify-center">
        <button
          type="submit"
          disabled={isLoading}
          className="mx-0 my-16 text-base flex items-center justify-center font-bold text-white bg-violet-500 border-[none] h-[50px] rounded-[100px] w-[393px] max-sm:w-full"
          aria-label="Registration form register button"
        >
          {isLoading ? <Loader2 className="w-8 h-8 self-center animate-spin" /> : t("register.register")}
        </button>
      </div>
    </form>
  );
}
