"use client";
import React from "react";
import Header from "@/components/layout/Header";
import { AccountSummary } from "./components/AccountSummary";
import { PointPassbook } from "./components/PointPassbook";
import { OtherSettings } from "./components/OtherSetting";
import Footer from "@/components/layout/Footer";
import { Layout } from "@/components/layout/Layout";
import { User } from "@supabase/supabase-js";
import { getUser } from "../login/action";

export default function Page() {
	const [user, setUser] = React.useState<User | null>(null);
	const [isLoading, setIsLoading] = React.useState(true);
	React.useEffect(() => {
		const fetchUser = async () => {
			const { user, error } = await getUser();
			if (error) {
				console.error('User retrieval failed', error);
			} else {
				setUser(user.user);
				setIsLoading(false);
			}
		};
		fetchUser();
	}, []);
	return (
		<Layout>
			{isLoading ? (
				<div className="flex justify-center items-center h-screen">
					<div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-violet-500"></div>
				</div>
			) : (
				<>
					<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Me page">
						<Header />
						<main className="pl-20 max-md:pl-2 pr-10 max-md:pr-2 py-10 max-md:py-0 max-sm:px-4" aria-label="Me main">
							<AccountSummary user={user} />
							<PointPassbook user={user} />
							<OtherSettings />
						</main>
					</div>
					<Footer />
				</>
			)}
		</Layout>
	);
};

