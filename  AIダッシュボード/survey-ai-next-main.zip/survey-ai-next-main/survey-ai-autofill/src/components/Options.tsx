import React from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card } from '@/components/ui/card'
import { Bot } from 'lucide-react'
import { ProfileForm } from './forms/ProfileForm'
import { SitesForm } from './forms/SitesForm'
import { ScheduleForm } from './forms/ScheduleForm'

export function Options() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 p-4 sm:p-8">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Survey AI Autofill Settings
          </h1>
          <p className="text-muted-foreground text-lg">
            Configure your AI assistant preferences
          </p>
        </div>

        <Card className="p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border border-gray-100 dark:border-gray-700 shadow-xl rounded-xl">
          <Tabs defaultValue="profile">
            <TabsList className="grid w-full grid-cols-3 h-14 items-center bg-white dark:bg-gray-800 rounded-lg p-1 gap-1">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="sites">Survey Sites</TabsTrigger>
              <TabsTrigger value="schedule">Schedule</TabsTrigger>
            </TabsList>
            <div className="mt-6">
              <TabsContent value="profile">
                <ProfileForm />
              </TabsContent>
              <TabsContent value="sites">
                <SitesForm />
              </TabsContent>
              <TabsContent value="schedule">
                <ScheduleForm />
              </TabsContent>
            </div>
          </Tabs>
        </Card>
      </div>
    </div>
  )
} 