export interface UserProfile {
  name: string
  age: string
  occupation: string
  education: string
  location: string
  interests: string
  preferences?: {
    responseStyle?: 'detailed' | 'concise'
    topicsOfInterest?: string[]
    avoidTopics?: string[]
  }
  settings?: {
    maxSurveysPerDay: number
    minDelayBetweenSurveys: number
    workingHours: {
      start: string
      end: string
    }
  }
} 