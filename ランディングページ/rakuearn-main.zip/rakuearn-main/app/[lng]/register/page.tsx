"use client";
import * as React from "react";
import Header from "@/components/layout/Header";
import { RegistrationForm } from "./components/RegistrationForm";
import Footer from "@/components/layout/Footer";
import { Layout } from "@/components/layout/Layout";
import { useT } from "@/app/i18n/client";

const RegistrationPage = () => {
	const { t } = useT('auth');
	return (
		<Layout>
			<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Registration page">
				<Header />
				<main className="mt-20 max-md:mt-10 px-20 py-0 max-md:px-10 max-sm:mt-0 max-md:py-0 max-sm:px-4 max-sm:py-0" aria-label="Registration main">
					<h1 className="mb-5 text-3xl max-sm:text-xl font-bold text-black" aria-label="Registration title">{t("register.title")}</h1>
					<p className="mb-14 text-base max-sm:text-sm font-medium text-black" aria-label="Registration description">
						{t("register.description")}
					</p>
					<RegistrationForm />
				</main>
			</div>
			<Footer />
		</Layout>
	);
}

export default RegistrationPage;