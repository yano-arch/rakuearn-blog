import { createClient } from "@/utils/supabase/server";
import { NextRequest, NextResponse } from "next/server";
import { use } from "react";

const API_URL = "https://rakuearn.jp/api/v1/m/action_log_raw/search";
const ACCESS_KEY = process.env.ACS_ACCESS_KEY;
const SECRET_KEY = process.env.ACS_SECRET_KEY;

// This API endpoint fetches action logs for a specified date range
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const startDate = searchParams.get("start"); //  e.g., "2023-10-01"
  const endDate = searchParams.get("end"); // e.g., "2023-10-31"
  if (!startDate || !endDate) {
    return NextResponse.json(
      { message: "Start and end date parameters are required." },
      { status: 400 }
    );
  }

  const startJST = new Date(startDate + "T00:00:00+09:00");
  const endJST = new Date(endDate + "T23:59:59+09:00");

  const startTimestamp = Math.floor(startJST.getTime() / 1000);
  const endTimestamp = Math.floor(endJST.getTime() / 1000);

  try {
    const response = await fetch(
      `${API_URL}?state=1&action_type=normal&apply_unix=between&apply_unix_A=${startTimestamp}&apply_unix_B=${endTimestamp}`,
      {
        method: "GET",
        headers: {
          "X-Auth-Token": `${ACCESS_KEY}:${SECRET_KEY}`,
        },
        redirect: "follow",
      }
    );
    const result = await response.json();
    // console.log(result);

    if (result.records?.length > 0) {
      const supabase = await createClient();
      for (const record of result.records) {
        const { pbid, net_reward } = record;
        if (pbid) {
          // defined increment_point fuction in supabase
          // to increment user points based on pbid and net_reward
          const { error } = await supabase.rpc("increment_point", {
            user_id: pbid,
            x: parseInt(net_reward),
          });

          if (error) {
            console.error("Error updating points:", pbid, net_reward, error);
          }

          const { data: survey } = await supabase
            .from("surveys")
            .select("id")
            .eq("acs_promotion_id", record.promotion)
            .single();

          if (survey?.id) {
            const responseData = {
              user_id: pbid,
              survey_id: survey?.id,
              point: parseInt(net_reward),
              earned_at: new Date(record.apply_unix * 1000),
              acs_raw_data: record,
            };
            const { error: insertError } = await supabase
              .from("responses")
              .insert(responseData);
          }
        }
      }
    }

    return NextResponse.json(
      {
        message: "Action logs processed successfully",
        count: result.records?.length || 0,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("Error fetching abTest:", err);
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500 }
    );
  }
}
