import { NextResponse } from 'next/server'
import acceptLanguage from 'accept-language'
import { createClient } from '@/utils/supabase/server'
import { updateSession } from '@/utils/supabase/middleware'
import { fallbackLng, languages, cookieName, headerName } from './app/i18n/settings'

acceptLanguage.languages(languages)

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|assets|favicon.ico|sw.js|site.webmanifest).*)',
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ]
}

export async function middleware(req) {
  // Update user's auth session first
  const response = await updateSession(req)
  const supabase = await createClient()
  const { data: user, error } = await supabase.auth.getUser();

  const pathname = req.nextUrl.pathname;

  // Check if user is not authenticated and trying to access protected pages
  if ((pathname.includes('/admin') || pathname.includes('/me')) && !user.user) {
    console.log('Redirecting to login');
    return NextResponse.redirect(new URL('/login', req.url));  // Redirect to login page
  }

  if (user.user) {
    if (pathname.includes('/login')) {
      console.log('Redirecting to me');
      return NextResponse.redirect(new URL('/me', req.url));  // Redirect to login page
    }


    if ((pathname.includes('/admin') && user.user.user_metadata.role !== 'admin')) {
      console.log('Redirecting to me');
      return NextResponse.redirect(new URL('/me', req.url));  // Redirect to login page
    }
  }



  // Ignore paths with "icon" or "chrome"
  if (req.nextUrl.pathname.indexOf('icon') > -1 || req.nextUrl.pathname.indexOf('chrome') > -1) return response

  let lng = "ja"
  // // Try to get language from cookie
  // if (req.cookies.has(cookieName)) lng = acceptLanguage.get(req.cookies.get(cookieName).value)
  // // If no cookie, check the Accept-Language header
  // if (!lng) lng = acceptLanguage.get(req.headers.get('Accept-Language'))
  // // Default to fallback language if still undefined
  // if (!lng) lng = fallbackLng

  // Check if the language is already in the path
  const lngInPath = languages.find(loc => req.nextUrl.pathname.startsWith(`/${loc}`))
  const headers = new Headers(req.headers)
  headers.set(headerName, lngInPath || lng)

  // If the language is not in the path, redirect to include it
  if (
    !lngInPath &&
    !req.nextUrl.pathname.startsWith('/_next') &&
    !req.nextUrl.pathname.startsWith('/api') &&
    !req.nextUrl.pathname.endsWith('.html')
  ) {
    return NextResponse.redirect(new URL(`/${lng}${req.nextUrl.pathname}${req.nextUrl.search}`, req.url))
  }

  // If a referer exists, try to detect the language from there and set the cookie accordingly
  if (req.headers.has('referer')) {
    const refererUrl = new URL(req.headers.get('referer'))
    const lngInReferer = languages.find((l) => refererUrl.pathname.startsWith(`/${l}`))
    if (lngInReferer) response.cookies.set(cookieName, lngInReferer)
    return response
  }

  return response
}

