import React from "react";
import { AuthButton } from "./AuthButton";
import { useRouter } from "next/navigation";
import { useT } from "@/app/i18n/client";

export const RegistrationForm: React.FC = () => {
    const router = useRouter();
    const { t } = useT('auth');
    return (
        <div className="flex-1 bg-white px-10 py-6 rounded-3xl max-sm:p-5" aria-label="Registration form">
            <div>
                <h2 className="mb-4 text-2xl max-sm:text-lg font-semibold" aria-label="Registration title">{t("registration.title")}</h2>
                <div className="mb-8 h-px bg-zinc-300 bg-opacity-90" />
                <p className="mb-8 text-base font-medium leading-snug text-center" aria-label="Registration description">
                    {t("registration.description1")}
                    <br />
                    {t("registration.description2")}
                </p>
                <AuthButton fullWidth ariaLabel="Create a new account" onClick={() => router.push("/register")}>{t("registration.createAccount")}</AuthButton>
            </div>
        </div>
    );
};
