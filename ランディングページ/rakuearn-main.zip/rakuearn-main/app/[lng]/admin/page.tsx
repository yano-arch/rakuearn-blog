'use client'
import React from "react";
import { Sidebar } from "./components/Sidebar";
import { DashboardContent } from "./components/DashboardContent";
import { UserTable } from "./components/UserTable";
import { ExchangesTable } from "./components/ExChangesTable";
import { SurveyForm } from "./components/SurveyForm";
import { SurveyTable } from "./components/SurveyTable";
import { SurveyDetail } from "./components/SurveyDetail";
import { useT } from "@/app/i18n/client";

interface Survey {
	title: string;
	points: number;
	provider: string;
	estimated_time: number;
	link: string;
	acs_promotion_id: string;
	file_path: string;
	created_at: string;
	id: string
}

interface User {
	id: string;
	email: string;
	point: number;
	created_at: string;
}



const AdminPage = () => {

	const {t} = useT('admin');
	const navItems = [t("navItems.home"), t("navItems.user"), t("navItems.exchanges"), t("navItems.postSurvey"), t("navItems.surveyList")];
	const [activeItem, setActiveItem] = React.useState(navItems[0]);
	const [isSurveyDetailOpen, setIsSurveyDetailOpen] = React.useState(false);
	const [selectedSurvey, setSelectedSurvey] = React.useState<Survey | null>(null);

	return (
		<div
			className="max-w-[1440px] h-[100vh] mx-auto overflow-hidden pr-20 bg-neutral-100 max-md:pr-5"
			aria-label="Admin page"
		>
			<div className="flex w-full gap-5 max-md:flex-col h-full">
				<Sidebar navItems={navItems} activeItem={activeItem} setActiveItem={setActiveItem} setIsSurveyDetailOpen={setIsSurveyDetailOpen} />
				{activeItem === t("navItems.home") && !isSurveyDetailOpen && <DashboardContent />}
				{activeItem === t("navItems.user") && !isSurveyDetailOpen && <UserTable />}
				{activeItem === t("navItems.exchanges") && !isSurveyDetailOpen && <ExchangesTable />}
				{activeItem === t("navItems.postSurvey") && !isSurveyDetailOpen && <SurveyForm />}
				{activeItem === t("navItems.surveyList") && !isSurveyDetailOpen && <SurveyTable setIsSurveyDetailOpen={setIsSurveyDetailOpen} setSelectedSurvey={setSelectedSurvey} />}
				{isSurveyDetailOpen && (
					<SurveyDetail survey={selectedSurvey as Survey} setIsSurveyDetailOpen={setIsSurveyDetailOpen} />
				)}
			</div>
		</div>
	);
}

export default AdminPage;
