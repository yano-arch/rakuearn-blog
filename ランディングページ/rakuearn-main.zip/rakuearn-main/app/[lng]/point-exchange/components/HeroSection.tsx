import React from "react";
import Image from "next/image";
import Penny from "@/assets/images/5.svg";
import Yen from "@/assets/images/yen.svg";
import { useT } from "@/app/i18n/client";

export const HeroSection = () => {
  const { t } = useT('pointExchange');
  return (
    <section className="mt-16 bg-neutral-100 max-md:rounded-[20px] rounded-[40px] max-sm:mt-0 max-md:max-w-full" aria-label="Hero section">
      <div className="relative text-center flex items-center justify-center h-[150px] max-md:h-[100px] w-full" aria-label="Hero section content">
        <Image src={Penny} className="absolute block top-0 left-[-20] max-md:hidden" alt="Penny" height={150} />
        <div className="flex items-center justify-center">
          <h1 className="self-stretch text-center my-auto text-4xl max-md:text-2xl font-bold text-black" aria-label="Hero section title">
            {t('heroSection.title')}
          </h1>
        </div>
        <div className="absolute block top-0 right-[-52] h-full max-md:hidden">
          <Image
            src={Yen}
            alt="Point Exchange illustration"
            height={150}
            className="z-10 grow mr-0"
          />
        </div>
      </div>
    </section>
  );
};
