'use client';
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/redux/store";
import { completeOnboarding, skipOnboarding} from "@/redux/onboardingSlice";
import Dashboard from "./overview/Completed";
import DashboardDisplay from "./dashboard/dashboard";
import UserConfig from "./configuration/user-config";
interface ContentDisplayProps {
    activeTab: string;
  }
  
  const DynamicContentDisplay: React.FC<ContentDisplayProps> = ({ activeTab }) => {
    let content;
  
    // Dynamically set the content based on activeTab
    switch (activeTab) {
      case "dashboard": content = (
        <div className="p-4 w-full bg-custom-lilac-bg overflow-y-hidden">
          <DashboardDisplay/>
        </div>
    );
        break;
      case "configuration":
        content = (
          <div className="p-4 w-full bg-custom-lilac-bg">
        <UserConfig/>
        </div>
        );
        break;
      case "settings":
        content = (<div className="w-full bg-custom-lilac-bg"><p className="text-gray">Settings Display</p></div>);
        break;
      default:
        content = <div>Unknown Tab</div>;
    }
  
      return content;
  };
  
  export default DynamicContentDisplay;