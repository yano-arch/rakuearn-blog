'use client';
import React from 'react'
import { useState } from 'react';

import GradientToggle from "./ui/gradient-toggle";

const TextFormInput = (gradientLabel: string, labels: string[], name: string[], type: any, placeholders: string[], values: string[], htmlForId: ) => {
    return (
         <div className="flex flex-col w-user-form-width">
                            {/* main label & toggle div */}
                            <div>
                                <GradientToggle label={gradientLabel}/>
                            </div>

                            <div className="p-4 flex flex-col gap-2">
                            <label htmlFor="lname" className="text-black">Last Name</label>
                            <input type="text" id="lname" name="lname" className="p-2 rounded-lg"/>
                            <label htmlFor="fname" className="text-black" >First Name</label>
                            <input type="text" id="fname" name="fname" className="p-2 rounded-lg"/>
                            </div>
        
                        </div>
    )
};

export default TextFormInput;