import chrome from '@/public/chrome.png'
import Image from 'next/image';
const InstallExtension = () => {


    return (
        <div className=" bg-custom-lpurple-active absolute bottom-10 rounded-3xl flex m-3 p-1"> 
            <div className="">
                <div className="flex flex-col items-center p-2 pb-2 gap-2 -mt-1">
                    <small className="text-center text-xs font-semibold tracking-wide text-custom-darkest-purple mt-4">Install the Chrome Extension</small>
                    <h4 className="text-l tracking-wide font-bold text-custom-darkest-purple">Get Started!</h4>
                    <button className="bg-white text-custom-darkest-purple font-semibold text-lg tracking-wide flex flex-row place-items-center justify-center items-center gap-2 rounded-full px-3 py-2">
                        <Image src={chrome} alt="chrome" width={40} height={40} />
                        <span className="text-xs text-custom-darkest-purple">Install Extension</span>
                        </button>
                </div>      
        </div>
        </div>

    )
};

export default InstallExtension;