# Survey AI Autofill Chrome Extension

An AI-powered Chrome extension that automatically fills out surveys based on your profile and preferences. The extension uses GPT-4 to generate contextually appropriate responses while maintaining consistency with your configured profile.

## Tech Stack

### Extension
- **Framework**: [WXT (Web Extension Tools)](https://wxt.dev/) for Chrome extension development
- **UI**: React + Tailwind CSS + shadcn/ui components
- **Form Handling**: React Hook Form + Zod validation
- **State Management**: Chrome Storage API
- **AI Integration**: OpenAI GPT-4 API

### Configuration Interface
- **Framework**: Next.js 14
- **Styling**: Tailwind CSS with custom theme
- **UI Components**: shadcn/ui (Radix UI + Tailwind)
- **Icons**: Lucide React

## Features

- 🤖 AI-powered survey completion
- 🎨 Modern, responsive UI with dark mode support
- ⚙️ Comprehensive settings interface
- 👤 Customizable user profile
- 🌐 Configurable survey site patterns
- ⏰ Scheduling with daily limits
- 🔑 Secure API key management
- 📊 Daily progress tracking

## Project Structure
```
survey-ai-next/
├── app/                    # Next.js app for configuration interface
│   ├── components/         # Shared UI components
│   ├── extension/         # Extension configuration page
│   └── page.tsx           # Root redirect
├── src/                   # Extension source code
│   ├── components/        # Extension UI components
│   ├── entrypoints/      # Extension entry points
│   │   ├── popup/        # Extension popup
│   │   ├── options/      # Options page
│   │   ├── background/   # Service worker
│   │   └── content/      # Content scripts
│   ├── services/         # AI service and utilities
│   ├── styles/          # Global styles
│   └── types/           # TypeScript definitions
└── public/              # Static assets
```

## Setup & Development

1. **Prerequisites**
   ```bash
   node >= 18.0.0
   npm >= 8.0.0
   ```

2. **Installation**
   ```bash
   # Clone the repository
   git clone <repository-url>
   cd survey-ai-next

   # Install dependencies
   npm install
   ```

3. **Development**
   ```bash
   # Start Next.js development server
   npm run dev

   # In a separate terminal, start extension development
   cd survey-ai-autofill
   npm run dev
   ```

4. **Building**
   ```bash
   # Build the extension
   cd survey-ai-autofill
   npm run build
   ```

## Loading the Extension

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" in the top right
3. Click "Load unpacked"
4. Navigate to `survey-ai-autofill/.output/chrome-mv3`
   - On macOS, press `⌘ + Shift + .` to show hidden files
   - Or use `⌘ + Shift + G` and paste the full path

## Configuration

1. Click the extension icon in Chrome
2. Click the settings icon to open the full configuration page
3. Configure your:
   - Profile information
   - OpenAI API key
   - Target survey sites
   - Schedule and limits

## Development Notes

- The extension uses Chrome's Storage API for persistence
- Content scripts detect survey forms using DOM analysis
- The AI service maintains context across survey responses
- Background worker manages scheduling and limits
- Popup provides quick access to enable/disable and stats

## Testing

1. **Extension Testing**
   ```bash
   # Build the extension
   npm run build

   # Load in Chrome as unpacked extension
   # Test on supported survey sites
   ```

2. **Configuration Interface**
   ```bash
   # Start Next.js server
   npm run dev

   # Access at http://localhost:3000/extension
   ```

## Security

- API keys are stored securely in Chrome's local storage
- No data is transmitted except to OpenAI's API
- All survey processing happens locally
- Site patterns use explicit allowlisting

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request
