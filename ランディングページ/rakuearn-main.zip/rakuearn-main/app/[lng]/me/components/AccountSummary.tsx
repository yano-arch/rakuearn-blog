"use client";
import React from "react";
import { useT } from "@/app/i18n/client";
import { getPoints } from "@/app/[lng]/admin/actions";
import { getUser } from "../../login/action";
import { User } from "@supabase/supabase-js";
import Link from "next/link";
import { useParams } from "next/navigation";

export const AccountSummary: React.FC<{ user: User | null }> = ({ user }) => {
	const { t } = useT('auth');
	const lng = useParams().lng;
	const [points, setPoints] = React.useState<number>(0);
	React.useEffect(() => {
		const fetchPoints = async () => {
			const points = await getPoints(user?.email || "");
			setPoints(points);
		};
		fetchPoints();
	}, []);
	return (
		<section className="mb-10" aria-label="Account summary">
			<h1 className="mb-6 max-sm:mb-3 text-3xl max-sm:text-xl font-bold text-black" aria-label="Account summary title">{t("accountSummary.title")}</h1>
			<div className="p-8 mb-8 max-sm:mb-4 max-md:mb-6 text-center bg-neutral-100 rounded-[40px] max-md:rounded-[20px] max-sm:p-5" aria-label="Account summary points">
				<p className="mb-0.5 text-base max-sm:text-sm font-bold text-black" aria-label="Account summary points text">
					{t("accountSummary.points")}
				</p>
				<span className="text-6xl max-sm:text-3xl font-extrabold bg-gradient-to-r from-[#c093ff] via-[#ffa9ec] to-[#FDB073] bg-clip-text text-transparent" aria-label="Account summary points amount">
					{new Intl.NumberFormat('en-US').format(points)} P
				</span>
			</div>
			<Link
				href={`/${lng}/point-exchange`}
				className="mx-auto mt-0 mb-10 text-base text-center flex justify-center items-center max-sm:text-sm font-bold text-violet-500 bg-violet-100 h-[61px] rounded-[40px] max-sm:h-[45px] w-[231px]"
				aria-label="Exchange points"
			>
				{t("accountSummary.exchangePoints")}
			</Link>
		</section>
	);
};
