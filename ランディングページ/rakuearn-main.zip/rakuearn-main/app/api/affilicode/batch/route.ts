import { createClient } from "@/utils/supabase/server";
import { NextRequest, NextResponse } from "next/server";

const API_URL = "https://rakuearn.jp/api/v1/m/action_log_raw/search";
const ACCESS_KEY = process.env.ACS_ACCESS_KEY;
const SECRET_KEY = process.env.ACS_SECRET_KEY;

// This API endpoint fetches action logs for the last hour
export async function GET(req: NextRequest) {
  if (
    req.headers.get("Authorization") !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const now = new Date();
  const lastHour = new Date(now.getTime() - 60 * 60 * 1000);

  const startOfLastHour = new Date(
    Date.UTC(
      lastHour.getUTCFullYear(),
      lastHour.getUTCMonth(),
      lastHour.getUTCDate(),
      lastHour.getUTCHours(),
      0,
      0
    )
  );

  const endOfLastHour = new Date(
    startOfLastHour.getTime() + 60 * 60 * 1000 - 1
  );

  const startTimestamp = Math.floor(startOfLastHour.getTime() / 1000);
  const endTimestamp = Math.floor(endOfLastHour.getTime() / 1000);

  try {
    const response = await fetch(
      `${API_URL}?apply_unix=between&state=1&action_type=normal&apply_unix_A=${startTimestamp}&apply_unix_B=${endTimestamp}`,
      {
        method: "GET",
        headers: {
          "X-Auth-Token": `${ACCESS_KEY}:${SECRET_KEY}`,
        },
        redirect: "follow",
      }
    );
    const result = await response.json();
    // console.log(result);

    if (result.records?.length > 0) {
      const supabase = await createClient();
      for (const record of result.records) {
        const { pbid, net_reward } = record;
        if (pbid) {
          // defined increment_point fuction in supabase
          // to increment user points based on pbid and net_reward
          const { error } = await supabase.rpc("increment_point", {
            user_id: pbid,
            x: parseInt(net_reward),
          });

          if (error) {
            console.error("Error updating points:", pbid, net_reward, error);
          }
        }
      }
    }

    return NextResponse.json(
      {
        message: "Action logs processed successfully",
        count: result.records?.length || 0,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("Error fetching abTest:", err);
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500 }
    );
  }
}
