"use client";

import { LoginSchema } from "@/schemas";
import { useTransition, useState } from "react";
import { signIn } from "next-auth/react";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from "@/components/ui/input";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { login } from "@/actions/login";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/FormError";
import { FormSuccess } from "@/components/FormSuccess";
import { useSearchParams } from "next/navigation";
import { FcGoogle } from "react-icons/fc"
import Link from "next/link";

const Login = () => {

  const searchParams =  useSearchParams();
  const urlError = searchParams.get("error") === "OAuthAccountNotLinked"
    ? "Email already in use with different provider!" : "";

  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | undefined>("");
  const [success, setSuccess] = useState<string | undefined>("");

  const form = useForm<z.infer<typeof LoginSchema>>({
    resolver: zodResolver(LoginSchema as any),
    defaultValues: {
      email: '',
      password: '',
    }
  })


  const onSubmit =  ( values: z.infer<typeof LoginSchema>) => {
    console.log('Submitted')
    setError("");
    setSuccess("");
    
    startTransition(() => {
      login(values)
        .then((data) => {
          setError(data?.error)
          setSuccess(data?.success)
        })
    })
  }

  return (
    <>
      <div className="mt-2 p-2">       
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField control={form.control} name="email" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Email</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="alex@example.com"
                        type="email"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <FormMessage className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                  <FormField control={form.control} name="password" render={({field}) => (
                  <FormItem>
                      <FormLabel className="text-black font-mono">Password</FormLabel>
                      <FormControl>
                        <Input 
                        {...field}
                        placeholder="******"
                        type="password"
                        disabled={isPending}
                        className="text-black font-mono"
                        />
                      </FormControl>
                      <Button size="sm" variant="link" asChild className="flex justify-end font-normal px-0">
                        <Link href="/auth/reset" className="text-gray-500 text-end">
                          Forgot password?
                        </Link>
                      </Button>
                      <FormMessage className="text-red-500 font-mono"/>
                  </FormItem>
                  )}/>
                <FormError message={error || urlError}/>
                <FormSuccess message={success}/>
                <Button type="submit" className="credentials_buttons" disabled={isPending}>
                  Login
                </Button>
            </form>
        </Form>
        <button onClick={() => signIn('google')} className="mt-2 ouath_buttons ">
          <FcGoogle className="w-5 h-5 ml-2" />
        </button>
      </div>
    </>
  );
};

export default Login;