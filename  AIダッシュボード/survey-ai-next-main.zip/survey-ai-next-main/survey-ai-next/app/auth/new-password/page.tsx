import NewPasswordForm from "@/components/authentication/NewPasswordForm"


const page = () => {
  return (
    <NewPasswordForm />
  )
}

export default page