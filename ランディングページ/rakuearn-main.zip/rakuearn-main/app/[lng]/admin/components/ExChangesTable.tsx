"use client";
import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { Check, X, Minus } from "lucide-react";
import { getExchanges, updateExchangeStatus, updatePoints } from "../actions";
import { useT } from "@/app/i18n/client";

interface ExchangeDetail {
	id: number;
	user_email: string;
	amount: number;
	payment: string;
	created_at: string;
	status: string;
}

export function ExchangesTable() {
	const { t } = useT('admin');
	const [exchanges, setExchanges] = useState<ExchangeDetail[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	// Example data - replace with your actual data source
	const statusColor = {
		pending: "text-yellow-500",
		complete: "text-green-500",
		declined: "text-red-500",
	}

	const paymentMethod = {
		bankTransfer: "Bank Transfer",
		amazon: "Amazon",
		payPay: "PayPay",
		googlePlay: "Google Play",
		apple: "Apple",
	}

	useEffect(() => {
		const fetchExchanges = async () => {
			const exchanges = await getExchanges();
			if ('error' in exchanges) {
				console.error('Exchanges retrieval failed', exchanges.error);
			} else {
				setExchanges(exchanges);
				setIsLoading(false);
			}
		}
		fetchExchanges();
	}, []);

	return (
		<div className="ml-5 w-[72%] overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] max-md:ml-0 max-md:w-full mt-30 overflow-x-scroll" aria-label="Exchanges table Section">
			<ToastContainer />
			<table className="w-full border-collapse" aria-label="Exchanges table">
				<thead>
					<tr className="border-b border-black" aria-label="Exchanges table header">
						<th className="py-4 px-6 text-left font-semibold" aria-label="Exchanges table header column">{t("user")}</th>
						<th className="py-4 px-6 text-right font-semibold" aria-label="Exchanges table header column">{t("amount")}</th>
						<th className="py-4 px-6 text-right font-semibold" aria-label="Exchanges table header column">{t("method")}</th>
						<th className="py-4 px-6 text-left font-semibold" aria-label="Exchanges table header column">{t("submitted")}</th>
						<th className="py-4 px-6 text-left font-semibold" aria-label="Exchanges table header column">{t("status")}</th>
						<th className="py-4 px-6 text-right font-semibold" aria-label="Exchanges table header column">{t("actions")}</th>
					</tr>
				</thead>
				<tbody>
					{isLoading ? (
						<tr>
							<td colSpan={6} className="text-center py-4">Loading...</td>
						</tr>
					) : (
						exchanges.map((exchange, index) => (
							<tr
								key={index}
								className={`border-b border-gray-100 hover:bg-gray-50`}
						>
							<td className={`px-6 text-left ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Exchanges table data">
								{exchange.user_email}
							</td>
							<td className={`py-2 px-6 text-right ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Exchanges table data">
								{exchange.amount} yen
							</td>
							<td className={`py-2 px-6 text-right ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Exchanges table data">
								{paymentMethod[exchange.payment as keyof typeof paymentMethod]}
							</td>
							<td className={`py-2 px-6 text-left ${index === 0 ? "pt-4 pb-2" : "py-2 "}`} aria-label="Exchanges table data">
								{new Date(exchange.created_at).toISOString().split('T')[0] + ' ' +
									new Date(exchange.created_at).toLocaleTimeString('en-US', {
										hour: '2-digit',
										minute: '2-digit',
										hour12: false
									})}
							</td>
							<td className={`py-2 px-6 text-left ${index === 0 ? "pt-4 pb-2" : "py-2 "} ${statusColor[exchange.status as keyof typeof statusColor]}`} aria-label="Exchanges table data">
								{exchange.status}
							</td>
							<td
								className={`py-6 px-6 ${exchange.status === "pending"
										? "flex items-center justify-center gap-4" // Increased gap for better spacing
										: "flex items-center justify-center"
									} ${index === 0 ? "pt-4 pb-2" : "py-2 "}`}
								aria-label="Exchanges table data"
							>
								{exchange.status === "pending" ? (
									<>
										<Check
											className="cursor-pointer"
											onClick={() => {
												updateExchangeStatus(exchange.id, "complete");
												updatePoints(exchange.user_email, +exchange.amount);
												setExchanges(
													exchanges.map((e) =>
														e.id === exchange.id ? { ...e, status: "complete" } : e
													)
												);
												toast.success("Exchange status updated to complete");
											}}
										/>
										<X
											className="cursor-pointer"
											onClick={() => {
												updateExchangeStatus(exchange.id, "declined");
												setExchanges(
													exchanges.map((e) =>
														e.id === exchange.id ? { ...e, status: "declined" } : e
													)
												);
												toast.error("Exchange status updated to declined");
											}}
										/>
									</>
								) : (
									<>
										<Minus />
									</>
								)}
							</td>
							</tr>
						))
					)}
				</tbody>
			</table>
		</div >
	);
}