// interface SurveyQuestion {
//   question: string;
//   options: string[];
//   type: string;
//   required: boolean;
// }
// cleaner implementation for later maybe? that's neat, thanks TS.

export class AIService {
  private apiKey: string | null = null;
  private isInitialized = false;
  private readonly MODEL = "gpt-4o-mini";
  
  private readonly API_ENDPOINT = "https://api.openai.com/v1/chat/completions";

  async initialize() {
    if (this.isInitialized) return;

    const result = await chrome.storage.local.get(['apiKey']);
    this.apiKey = result.apiKey;
    // this.apiKey = "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"
    // testing ^^^
    if (!this.apiKey) {
      throw new Error('API key not configured');
    }

    this.isInitialized = true;
  }

  async analyzeSurvey(cleanedHTML: string) {

    try {
      const { userProfile, isEnabled } = await chrome.storage.local.get(['userProfile', 'isEnabled']);
      // if (!isEnabled) return;
      if (!userProfile) {
        throw new Error('User profile not configured');
      }

    const response = await fetch(this.API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: this.MODEL,
        messages: [
          {
            role: 'system',
            content: `You are an AI assistant helping to fill out surveys. Generate natural, thoughtful responses based on the user's profile: ${JSON.stringify(userProfile)}.`
          },
          {
            role: 'user',
            content: `
            **Your task is to return a JSON response with this shape**:
            [
              {
                ”element": [“XPATH_TO_ELEMENT",],
                "content": "TEXT_TO_INPUT"
                },
                ] based on the following instructions and the given HTML document.
                ***STRICT RULE***
                -When a question is found, you must find the respective answers and fill out the object {
                  ”element": ["XPATH_TO_ELEMENT",],
                  "content": "TEXT_TO_INPUT"
                  } before you are permitted to move onto the next question. Objects must be returned in the same order that the questions appear in the form.
                  
                  **Read the HTML document once and FIND THE QUESTIONS AND ANSWERS FIRST before doing anything, and then read the document again to fill in the objects to ensure all questions and answers have been found and all answers are accurately recorded based on the given requirements.**
                  HTML DOC: ${cleanedHTML}
                  
                  # Instructions 
Search the document for survey questions, likely located inside a <form>. The answers can be any of the following elements: 
- <input type=“text”>
- <input type=“checkbox”>
- <input type=“radio”>
- <textarea>

**Input Text and Text Area Questions : <input type="text"> or <textarea> instructions**
If the question has a text input option <input type=“text”> or <textarea>, please assign the “element” key a value of the xpath of the input or textarea, and please fill the “content” key with a **human-like** response. 
(Example: {
”element": ["XPATH_TO_FILL_ELEMENT1”],
"content": “TEXT_TO_INPUT“
}
**Multiple choice questions: <input type="checkbox"> instructions**
If the question has multiple checkbox inputs (<input type=“checkbox”>), please assign the “element” key a value of an array of the singular OR multiple checked xpath(s), and leave “content” as an empty string. 
**IMPORTANT!** If a question specifies a required number of selections (e.g., 'Choose at least 3 options' or 'Select up to 5 choices'), ensure that at least the minimum required number of options are selected. Return the XPaths of all selected elements in the "element" array. If a maximum number is given, do not exceed it.
(Example: {
  ”element": ["XPATH_TO_CHECKED_ELEMENT1”, "XPATH_TO_CHECKED_ELEMENT2”, "XPATH_TO_CHECKED_ELEMENT3”, "XPATH_TO_CHECKED_ELEMENT4”, "XPATH_TO_CHECKED_ELEMENT5,”],
  "content": ""
  },
  )
  
  **Single-choice questions: <input type="radio"> instructions**
If the question has multiple options for a radio input (<input type=“radio”>), please assign the “element” key a value of ONE of the checked xpath, and leave “content” as an empty string. 
(Example: {
”element": ["XPATH_TO_CHECKED_ELEMENT1”],
"content": ""
},
)

Please provide responses that are:
1. Consistent with my profile
2. Natural and human-like
3. Thoughtful and detailed for open-ended questions
4. Honest and ethical.

### **Critical Rules**
** Required Fields: If a question contains a "*" or the word **"required"**, it **must** be answered.  
** Checkbox Minimum/Maximum Requirement!** If a question specifies a required number of selections (e.g., 'Choose at least 3 options' or 'Select up to 5 choices'), ensure that at least the minimum required number of options are selected. Return the XPaths of all selected elements in the "element" array. If a maximum number is given, do not exceed it.  
** If the question asks or tells you to pick or choose a certain number amount of options, select at least the specified amount, and return all selected xpaths of the element(s).
**Ignore Hidden Inputs**: Do not fill or select elements that are hidden or labeled as honeypots.  
**Maintain XPath Consistency**: The XPath format must remain the same across all responses each time and is extremely important.  
**If an <input type="hidden"> is found, IGNORE and do not process. Skip it and do not include it.

---
Here is the HTML. ${cleanedHTML}
`
    }
  ],
  temperature: 0.7,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`API Error: ${error.message || 'Unknown error'}`);
    }

    const data = await response.json();
    // console.log(data.choices[0].message.content);
    // return data;
    // need to write a parseAIResponse method. ^^^^ then return this vvvvv
    return this.parseAIResponse(data.choices[0].message.content);
  } catch (error: any) {
    console.error('Error generating responses:', error);
    throw error;
  }
}

async parseAIResponse(jsonResponse: string): Promise<any[] | null> {
  try {
    let cleanedJson = jsonResponse.split('json').join('').split('```').join('');
    // if there's a cleaner way to do this, i'd love to. but for now, this will do ^
    // sometimes it will not return ```json....``` as the response intro. will need to 
    // write a func that finds '[' and removes anything before it, finds ']' and removes anything after it.
    // will do on cleanup ^

    const parsedResponse = JSON.parse(cleanedJson);
    return parsedResponse;
} catch (error) {
    console.error("Invalid JSON:", error);
    return null;
}

}

}
