declare namespace chrome {
  export namespace runtime {
    export function openOptionsPage(): void;
  }

  export namespace storage {
    export interface StorageArea {
      get(keys: string | string[] | object | null, callback: (items: { [key: string]: any }) => void): void;
      set(items: object, callback?: () => void): void;
    }

    export const local: StorageArea;
  }
} 