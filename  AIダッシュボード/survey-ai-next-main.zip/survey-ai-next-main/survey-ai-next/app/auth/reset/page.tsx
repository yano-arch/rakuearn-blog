import ResetForm from "@/components/authentication/ResetForm"

const page = () => {
  return (
    <ResetForm />
  )
}

export default page