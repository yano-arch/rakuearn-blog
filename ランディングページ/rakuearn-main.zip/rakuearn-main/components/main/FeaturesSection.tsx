import React from "react";
import Image from "next/image";
import Button from "../layout/Button";
import FeatureImage from "@/assets/images/Union.png"
import FeatureImageSVG from "@/assets/images/Union.svg"
import FeaturePink from "./FeaturePink";
import FeatureBluePink from "./FeatureBluePink";
import FeatureYellow from "./FeatureYellow";
import { useT } from "@/app/i18n/client";
import { useParams } from "next/navigation";
import { useRouter } from "next/navigation";

const FeaturesSection: React.FC = () => {
  const { t } = useT('home');
  const lng = useParams()?.lng;
  const router = useRouter();
  const features: { description: string, svg: React.JSX.Element }[] = [
    {
      description: t('featuresSection.automatedSurveyCompletion'),
      svg: <FeaturePink />
    },
    {
      description: t('featuresSection.turnOnAIAndStartEarning'),
      svg: <FeatureBluePink />
    },
    {
      description: t('featuresSection.saveTimeAndEffort'),
      svg: <FeatureYellow />
    },
  ];

  return (
    <section className="flex gap-48 max-sm:gap-10 justify-center max-md:mt-0 py-30 max-[1100px]:flex-col max-md:py-8 max-sm:py-4 max-md:px-4 " aria-label="Features section">
      <div className="relative flex items-center justify-center" aria-label="Features image">
        <Image src={FeatureImage} alt="Feature Image" className="hidden max-sm:block" width={275} />
        <Image src={FeatureImageSVG} alt="Feature Image" className="max-sm:hidden" width={375} height={295} />
      </div>
      <div className="max-sm:px-2" aria-label="Features content">
        <h2 className="mb-8 max-sm:mb-4 text-4xl max-sm:text-2xl font-bold" aria-label="Features title">{t('featuresSection.title')}</h2>
        <p className="mb-8 max-sm:mb-4 text-lg max-sm:text-sm font-semibold max-w-[540px]" aria-label="Features description">
          {lng === 'ja' ? (
            <>
              {t('featuresSection.description1')}
              <br />
              {t('featuresSection.description2')}
            </>
          ) : (
            t('featuresSection.description')
          )}
        </p>
        <div className="flex flex-col gap-5" aria-label="Features list">
          {features.map((feature, index) => (
            <div key={index} className="flex gap-5 items-center" aria-label="Features item">
              {feature.svg}
              <p className="text-lg max-sm:text-sm font-semibold" aria-label="Features item description">{feature.description}</p>
            </div>
          ))}
        </div>
        <Button variant="secondary" className="mt-8 max-sm:text-sm max-sm:w-[200px]" ariaLabel="Features button" onClick={() => router.push(`${lng}/how-it-works`)}>
          {t('featuresSection.button')}
        </Button>
      </div>
    </section>
  );
};

export default FeaturesSection;
