"use client";
import React, { useEffect, useState } from "react";
import Header from "@/components/layout/Header";
import { SurveyDetails } from "../components/SurveyDetails";
import { getSurveys } from "@/app/[lng]/admin/actions";
import { SuggestedSurveys } from "../components/SuggestedSurveys";
import Footer from "@/components/layout/Footer";
import { Layout } from "@/components/layout/Layout";
import { BackButton } from "../../point-exchange-selected/components/BackButton";
import { useParams } from "next/navigation";
import { User } from "@supabase/supabase-js";
import { getUser } from "../../login/action";

const SelectedSurvey: React.FC = () => {
	const { id } = useParams();
	const [user, setUser] = React.useState<User | null>(null);
	const [allSurveys, setAllSurveys] = useState<any[] | { error: string } | null>(null);
	const [selectedSurvey, setSelectedSurvey] = useState<any | { error: string } | null>(null);
	const [isLoading, setIsLoading] = useState(true);

	useEffect(() => {
		const fetchSurveys = async () => {
			setIsLoading(true);
			try {
				const allSurveys = await getSurveys();
				if ('error' in allSurveys) {
					console.error('Error fetching surveys', allSurveys.error);
				} else {
					setSelectedSurvey(allSurveys.find((survey) => survey.id === id));
					setAllSurveys(allSurveys);
				}
			} catch (error) {
				console.error('Error fetching surveys:', error);
			} finally {
				setIsLoading(false);
			}
		};
		fetchSurveys();
	}, [id]);

	React.useEffect(() => {
		const fetchUser = async () => {
			const { user, error } = await getUser();
			if (error) {
				console.error('User retrieval failed', error);
			} else {
				setUser(user.user);
				setIsLoading(false);
			}
		};
		fetchUser();
	}, []);

	return (
		<Layout>
			<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Selected survey page">
				<Header />
				<div className="pl-20 max-md:pl-4 pr-10 max-md:pr-4 flex flex-col items-start w-full mb-20 max-md:max-w-full" aria-label="Selected survey main">
					<BackButton className="max-md:ml-0 max-sm:hidden" />
					{isLoading ? (
						<div className="mt-4">Loading...</div>
					) : (
						<>
							<SurveyDetails survey={selectedSurvey} userId={user?.id}/>
							<SuggestedSurveys suggestedSurveys={allSurveys}/>
						</>
					)}
				</div>
			</div>
			<Footer />
		</Layout>
	);
};

export default SelectedSurvey;