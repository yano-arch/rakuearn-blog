
import { store } from "@/redux/store";
import OnboardingWarning from "@/components/OnboardingWarning";

import { auth } from "@/auth";
import ContentDisplay from "@/components/Content-Display";
import Dashboard from "@/components/overview/Completed";
import OverviewDashboard from "@/components/overview/Completed";

const overview = async () => {

  const session = await auth();
  console.log(session)

  const onboardingStatus = store.getState().onboarding.onboardingStatus;

  return ( onboardingStatus == 'SKIPPED' ? 
    ( <OnboardingWarning/>) : <div className="w-full h-full">
      <OverviewDashboard/>
  </div>








    //  prev code if you wanted it still, just trying to visualize data n stuff hope that's ok
    // ( <div className="grid grid-cols-3 gap-4 w-[50vw] h-[55vh] bg-black" >
    //     <div className="stat_container">
    //         <div className="stat_label">
    //           Total
    //         </div>
    //       </div>
    //     <div className="col-span-2 stat_container">Yearly</div>
    //     <div className="stat_container">Today</div>
    //     <div className="stat_container">Weekly</div>
    //     <div className="stat_container">Monthly</div>
    // </div>)
  );
};

export default overview;
