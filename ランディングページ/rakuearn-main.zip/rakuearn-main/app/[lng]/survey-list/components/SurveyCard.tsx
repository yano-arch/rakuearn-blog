import React from "react";
import Link from "next/link";
import Image from "next/image";
import Survey from "@/assets/images/survey.webp"
import { useParams } from "next/navigation";
interface SurveyCardProps {
	id: string;
	title: string;
	points: number;
	dateAdded: Date;
	imageUrl: string;
}

export const SurveyCard: React.FC<SurveyCardProps> = ({
	id,
	title,
	points,
	dateAdded,
	imageUrl,
}) => {
	const lng = useParams().lng;
	return (
		<Link href={`/${lng}/selected-survey/${id}`}>
			<article className="relative p-5 cursor-pointer rounded-3xl bg-neutral-100" aria-label="Survey card">
				{new Date(dateAdded).getTime() > new Date().getTime() - 2 * 24 * 60 * 60 * 1000 && (
					<div
						className="absolute -top-2 left-[40%] px-2 py-0.5 text-xs font-bold text-white bg-red-600 rounded-md"
						aria-label="New survey"
					>
						NEW
					</div>
				)}
				<Image
					src={imageUrl}
					alt=""
					className="mb-5 rounded-3xl h-[175px] max-sm:h-auto object-cover"
					height={175}
					width={175}
				/>
				<h3 className="mb-5 max-sm:mb-3 text-sm max-sm:text-xs font-bold text-black line-clamp-2">
					{title}
				</h3>
				<p className="text-2xl font-extrabold max-sm:text-base text-violet-500">
					{points.toLocaleString()} P
				</p>
			</article>
		</Link>
	);
};
