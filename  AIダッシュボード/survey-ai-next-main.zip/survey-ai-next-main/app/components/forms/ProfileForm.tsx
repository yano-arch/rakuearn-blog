import React from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { User, Briefcase, GraduationCap, MapPin, Heart } from 'lucide-react'

const profileSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  age: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 18, {
    message: "You must be at least 18 years old.",
  }),
  occupation: z.string().min(2, { message: "Please enter your occupation." }),
  interests: z.string().min(10, { message: "Please describe your interests in more detail." }),
  education: z.string().min(2, { message: "Please enter your education level." }),
  location: z.string().min(2, { message: "Please enter your location." }),
  apiKey: z.string().min(20, { message: "Please enter a valid OpenAI API key." })
})

type ProfileFormData = z.infer<typeof profileSchema>

export function ProfileForm() {
  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: "",
      age: "",
      occupation: "",
      interests: "",
      education: "",
      location: "",
      apiKey: ""
    }
  })

  React.useEffect(() => {
    // Load saved profile data from extension storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['userProfile', 'apiKey'], (result) => {
        if (result.userProfile || result.apiKey) {
          form.reset({
            apiKey: result.apiKey || '',
            ...result.userProfile
          })
        }
      })
    }
  }, [form])

  const onSubmit = async (data: ProfileFormData) => {
    const { apiKey, ...profile } = data
    if (typeof chrome !== 'undefined' && chrome.storage) {
      await chrome.storage.local.set({
        apiKey,
        userProfile: profile
      })
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label className="text-base flex items-center gap-2">
            <User className="w-4 h-4" />
            Full Name
          </Label>
          <Input
            {...form.register('name')}
            className="h-12 bg-white dark:bg-zinc-900"
            placeholder="John Doe"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-base">Age</Label>
          <Input
            {...form.register('age')}
            className="h-12 bg-white dark:bg-zinc-900"
            placeholder="25"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label className="text-base flex items-center gap-2">
            <Briefcase className="w-4 h-4" />
            Occupation
          </Label>
          <Input
            {...form.register('occupation')}
            className="h-12 bg-white dark:bg-zinc-900"
            placeholder="Software Engineer"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-base flex items-center gap-2">
            <GraduationCap className="w-4 h-4" />
            Education Level
          </Label>
          <Input
            {...form.register('education')}
            className="h-12 bg-white dark:bg-zinc-900"
            placeholder="Bachelor's Degree"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-base flex items-center gap-2">
          <MapPin className="w-4 h-4" />
          Location
        </Label>
        <Input
          {...form.register('location')}
          className="h-12 bg-white dark:bg-zinc-900"
          placeholder="New York, USA"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-base flex items-center gap-2">
          <Heart className="w-4 h-4" />
          Interests & Hobbies
        </Label>
        <Textarea
          {...form.register('interests')}
          className="min-h-[120px] bg-white dark:bg-zinc-900"
          placeholder="Tell us about your interests, hobbies, and preferences..."
        />
      </div>

      <Card className="border border-zinc-200 dark:border-zinc-800">
        <CardContent className="pt-6">
          <div className="space-y-2">
            <Label className="text-base">OpenAI API Key</Label>
            <Input
              {...form.register('apiKey')}
              type="password"
              className="h-12 bg-white dark:bg-zinc-900"
              placeholder="sk-..."
            />
            <p className="text-sm text-zinc-500 dark:text-zinc-400">
              Your API key is required for AI-powered survey responses.
              Get one at{' '}
              <a
                href="https://platform.openai.com/api-keys"
                target="_blank"
                rel="noopener noreferrer"
                className="text-zinc-900 dark:text-zinc-100 underline"
              >
                platform.openai.com
              </a>
            </p>
          </div>
        </CardContent>
      </Card>

      <Button 
        type="submit"
        className="w-full h-12 text-base font-medium bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-900"
      >
        Save Profile
      </Button>
    </form>
  )
} 