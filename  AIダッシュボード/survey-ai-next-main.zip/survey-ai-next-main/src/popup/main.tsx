import React from 'react'
import { createRoot } from 'react-dom/client'
import { Popup } from './Popup'
import '../styles/globals.css'

const root = createRoot(document.getElementById('app')!)
root.render(
  <React.StrictMode>
    <Popup />
  </React.StrictMode>
) 