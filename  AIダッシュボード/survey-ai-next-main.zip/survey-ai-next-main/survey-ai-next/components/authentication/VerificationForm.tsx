"use client";

import { useCallback, useEffect, useState } from "react";
import { BarLoader} from "react-spinners";
import { useSearchParams } from "next/navigation";
import { newVerification } from "@/actions/verification";
import { FormError } from "@/components/FormError";
import { FormSuccess } from "@/components/FormSuccess";


const VerificationForm = () => {

  const [error, setError] = useState<string | undefined>("");
  const [success, setSuccess] = useState<string | undefined>("");
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const onSubmit = useCallback(() => {

        if (success || error) return;

        if (!token) {
          setError("Missing Token!")
          return;
        }

        newVerification(token)
          .then((data) => {
            setSuccess(data.success);
            setError(data.error);
          })
          .catch(()=> {
            setError("Something went wrong!")
          })

    }, [token, success, error])

    useEffect(() => {
        onSubmit();
    }, [onSubmit]);

  return (
    <div className="flex items-center w-full justify-center">
        {!success && !error && (<BarLoader />)}
        <FormSuccess message={success}/>
        {!success && (<FormError message={error}/>)}
    </div>
  )
}

export default VerificationForm