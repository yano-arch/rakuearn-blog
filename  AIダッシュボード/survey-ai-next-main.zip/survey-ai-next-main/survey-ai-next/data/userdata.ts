import { db } from "@/lib/db";

export const getUserDataById = async ( id: string ) => {

    try {
        const data = await db.user.findUnique({
            where: { id }, 
            select: { userData: true },
        });
        return data;

    } catch {
        return null;
    }
}

export const getUserDataByEmail = async (email: string) => {
    
    try {
        const data = await db.user.findUnique({
            where: {email},
            select: {userData: true}
        });
        return data;
        
    } catch {
        return null;
    }

}