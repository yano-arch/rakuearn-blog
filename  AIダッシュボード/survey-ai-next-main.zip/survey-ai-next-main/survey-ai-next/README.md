This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.

```
survey-ai-next
├─ .env
├─ .eslintrc.json
├─ .next
│  ├─ app-build-manifest.json
│  ├─ build-manifest.json
│  ├─ cache
│  │  ├─ swc
│  │  │  └─ plugins
│  │  │     └─ v7_linux_x86_64_0.106.15
│  │  └─ webpack
│  │     ├─ client-development
│  │     │  ├─ 0.pack.gz
│  │     │  ├─ 1.pack.gz
│  │     │  ├─ 2.pack.gz
│  │     │  ├─ 3.pack.gz
│  │     │  ├─ index.pack.gz
│  │     │  └─ index.pack.gz.old
│  │     └─ server-development
│  │        ├─ 0.pack.gz
│  │        ├─ 1.pack.gz
│  │        ├─ 2.pack.gz
│  │        ├─ index.pack.gz
│  │        └─ index.pack.gz.old
│  ├─ package.json
│  ├─ react-loadable-manifest.json
│  ├─ server
│  │  ├─ app
│  │  │  ├─ (root)
│  │  │  │  ├─ page.js
│  │  │  │  └─ page_client-reference-manifest.js
│  │  │  ├─ _not-found
│  │  │  │  ├─ page.js
│  │  │  │  └─ page_client-reference-manifest.js
│  │  │  ├─ favicon.ico
│  │  │  │  └─ route.js
│  │  │  ├─ page.js
│  │  │  └─ page_client-reference-manifest.js
│  │  ├─ app-paths-manifest.json
│  │  ├─ interception-route-rewrite-manifest.js
│  │  ├─ middleware-build-manifest.js
│  │  ├─ middleware-manifest.json
│  │  ├─ middleware-react-loadable-manifest.js
│  │  ├─ next-font-manifest.js
│  │  ├─ next-font-manifest.json
│  │  ├─ pages-manifest.json
│  │  ├─ server-reference-manifest.js
│  │  ├─ server-reference-manifest.json
│  │  ├─ vendor-chunks
│  │  │  ├─ @babel.js
│  │  │  ├─ @reduxjs.js
│  │  │  ├─ @swc.js
│  │  │  ├─ immer.js
│  │  │  ├─ next-auth.js
│  │  │  ├─ next.js
│  │  │  ├─ react-redux.js
│  │  │  ├─ redux-thunk.js
│  │  │  ├─ redux.js
│  │  │  ├─ reselect.js
│  │  │  └─ use-sync-external-store.js
│  │  └─ webpack-runtime.js
│  ├─ static
│  │  ├─ chunks
│  │  │  ├─ app
│  │  │  │  ├─ (root)
│  │  │  │  │  ├─ layout.js
│  │  │  │  │  └─ page.js
│  │  │  │  ├─ _not-found
│  │  │  │  │  └─ page.js
│  │  │  │  ├─ layout.js
│  │  │  │  └─ page.js
│  │  │  ├─ app-pages-internals.js
│  │  │  ├─ main-app.js
│  │  │  ├─ polyfills.js
│  │  │  └─ webpack.js
│  │  ├─ css
│  │  │  └─ app
│  │  │     └─ layout.css
│  │  ├─ development
│  │  │  ├─ _buildManifest.js
│  │  │  └─ _ssgManifest.js
│  │  ├─ media
│  │  │  ├─ 4473ecc91f70f139-s.p.woff
│  │  │  └─ 463dafcda517f24f-s.p.woff
│  │  └─ webpack
│  │     ├─ 0c3243e899976559.webpack.hot-update.json
│  │     ├─ 4ab1ecccbcb80da3.webpack.hot-update.json
│  │     ├─ 633457081244afec._.hot-update.json
│  │     ├─ 770b0bdc13a36f78.webpack.hot-update.json
│  │     ├─ 7b7237e042872242.webpack.hot-update.json
│  │     ├─ app
│  │     │  ├─ layout.4ab1ecccbcb80da3.hot-update.js
│  │     │  ├─ layout.770b0bdc13a36f78.hot-update.js
│  │     │  └─ layout.7b7237e042872242.hot-update.js
│  │     ├─ c29a52ad035ca456.webpack.hot-update.json
│  │     ├─ webpack.0c3243e899976559.hot-update.js
│  │     ├─ webpack.4ab1ecccbcb80da3.hot-update.js
│  │     ├─ webpack.770b0bdc13a36f78.hot-update.js
│  │     ├─ webpack.7b7237e042872242.hot-update.js
│  │     └─ webpack.c29a52ad035ca456.hot-update.js
│  ├─ trace
│  └─ types
│     ├─ app
│     │  ├─ (root)
│     │  │  ├─ layout.ts
│     │  │  └─ page.ts
│     │  ├─ layout.ts
│     │  └─ page.ts
│     └─ package.json
├─ README.md
├─ app
│  ├─ (root)
│  │  ├─ configuration
│  │  │  └─ page.tsx
│  │  ├─ layout.tsx
│  │  ├─ overview
│  │  │  └─ page.tsx
│  │  ├─ page.tsx
│  │  └─ settings
│  │     └─ page.tsx
│  ├─ favicon.ico
│  ├─ fonts
│  │  ├─ GeistMonoVF.woff
│  │  └─ GeistVF.woff
│  ├─ globals.css
│  └─ layout.tsx
├─ auth.config.ts
├─ auth.ts
├─ components
│  ├─ Onboarding.tsx
│  ├─ OnboardingWarning.tsx
│  ├─ SideBar.tsx
│  ├─ SideNavBar.tsx
│  ├─ authentication
│  │  ├─ Login.tsx
│  │  └─ SignUp.tsx
│  └─ dashboard
│     └─ Completed.tsx
├─ components.json
├─ lib
│  ├─ auth.ts
│  ├─ db.ts
│  ├─ mail.ts
│  ├─ tokens.ts
│  └─ utils.ts
├─ next.config.mjs
├─ nextauth
│  ├─ actions
│  │  ├─ admin.ts
│  │  ├─ login.ts
│  │  ├─ logout.ts
│  │  ├─ new-password.ts
│  │  ├─ new-verification.ts
│  │  ├─ register.ts
│  │  ├─ reset.ts
│  │  └─ settings.ts
│  └─ data
│     ├─ account.ts
│     ├─ password-reset-token.ts
│     ├─ two-factor-confirmation.ts
│     ├─ two-factor-token.ts
│     ├─ user.ts
│     └─ verificiation-token.ts
├─ package-lock.json
├─ package.json
├─ postcss.config.mjs
├─ prisma
│  ├─ migrations
│  │  ├─ 20250227051458_init
│  │  │  └─ migration.sql
│  │  ├─ 20250227065240_init
│  │  │  └─ migration.sql
│  │  ├─ 20250227070816_init
│  │  │  └─ migration.sql
│  │  ├─ 20250227073259_init
│  │  │  └─ migration.sql
│  │  ├─ 20250227084202_init
│  │  │  └─ migration.sql
│  │  ├─ 20250228195924_init
│  │  │  └─ migration.sql
│  │  ├─ 20250228200509_init
│  │  │  └─ migration.sql
│  │  └─ migration_lock.toml
│  ├─ schema.prisma
│  └─ seed.ts
├─ redux
│  ├─ ReduxProvider.tsx
│  ├─ onboardingSlice.ts
│  └─ store.ts
├─ routes.ts
├─ schemas
│  └─ index.ts
├─ tailwind.config.ts
└─ tsconfig.json

```