"use client";
import React, { useState, useRef, useEffect } from "react";
import { useParams } from "next/navigation";
import Header from "@/components/layout/Header";
import { BackButton } from "../components/BackButton";
import { GiftCardSelector } from "../components/GiftCardSelector";
import { ExchangeDetails } from "../components/ExchangeDetail";
import { ExchangeProcedure } from "../components/ExchangeProcedure";
import Footer from "@/components/layout/Footer";
import { Layout } from "@/components/layout/Layout";
import { getPaymentCardImg } from "@/constants/constants";
import { LoginRequiredModal } from "../components/LoginRequiredModal";
type PaymentMethodId = keyof typeof getPaymentCardImg;

const GiftCardExchange: React.FC = () => {
	const { id } = useParams();
	const { lng } = useParams();
	const [loginRequiredModal, setLoginRequiredModal] = useState(false);

	const modalRef = useRef<HTMLDivElement | null>(null); // Reference for the modal container

  // Close the modal if the user clicks outside of it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        setLoginRequiredModal(false); // Close modal if clicked outside
      }
    };

    // Add event listener for clicks
    document.addEventListener("mousedown", handleClickOutside);

    // Cleanup on unmount
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

	return (
		<Layout>
			<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Point exchange selected page" onClick={() => setLoginRequiredModal(false)}>
				<Header />
				{loginRequiredModal && <LoginRequiredModal setLoginRequiredModal={setLoginRequiredModal} modalRef={modalRef} lng={lng as string} />}
				<main className="pl-20 max-md:pl-2 pr-10 max-md:pr-2" aria-label="Point exchange selected main">
					<BackButton className="max-sm:hidden" />
					<div className="max-sm:px-2">
						<GiftCardSelector id={id as PaymentMethodId} setLoginRequiredModal={setLoginRequiredModal} />
					</div>
					<div className="py-0 max-md:px-2 max-md:py-0">
						<ExchangeDetails />
						<ExchangeProcedure />
					</div>
				</main>
			</div>
			<Footer />
		</Layout>
	);
};

export default GiftCardExchange;
