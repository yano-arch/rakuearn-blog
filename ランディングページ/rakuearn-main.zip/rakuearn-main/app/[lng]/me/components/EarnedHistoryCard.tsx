import React from "react";
import Image from "next/image";
import Survey from "@/assets/images/survey.webp";

interface EarnedHistoryCardProps {
  index: number;
  item: {
    point: number;
    earned_at: string;
    surveys: {
      title: string;
      provider: string;
      link: string;
    };
  };
}

export const EarnedHistoryCard: React.FC<EarnedHistoryCardProps> = ({
  index,
  item,
}) => {
  return (
    <article
      key={index}
      className="flex cursor-pointer items-center px-0 py-5 border-b border-solid border-b-zinc-300 border-b-opacity-90 max-sm:gap-2"
      aria-label="Earned history card"
    >
      <Image
        src={Survey}
        alt="Survey icon"
        className="mr-8 max-md:mr-1 rounded-xl h-[70px] w-[70px]"
      />
      <div className="flex-1">
        <h4
          className="mb-1.5 text-base max-md:text-sm font-medium text-black"
          aria-label="Earned history card title"
        >
          {item.surveys.title}
        </h4>
        <div className="flex justify-between items-center">
          <p
            className="text-base max-md:text-sm font-bold text-black"
            aria-label="Earned history card points"
          >
            {item.point} P
          </p>
          <time
            className="hidden max-md:block text-base max-sm:text-sm font-medium text-black"
            aria-label="Earned history card date"
          >
            {item.earned_at}
          </time>
        </div>
      </div>
      <time
        className="text-base max-md:hidden font-medium text-black"
        aria-label="Earned history card date"
      >
        {item.earned_at}
      </time>
    </article>
  );
};
