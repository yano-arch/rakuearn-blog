import * as React from "react";
import { ExchangeHistoryItem } from "@/constants/constants";
import Image from "next/image";
import AmazonLogo from "@/assets/images/amazon.webp";
import AppleLogo from "@/assets/images/apple.webp";
import GooglePlayLogo from "@/assets/images/google_play.webp";
import PayPayLogo from "@/assets/images/paypay.webp";
import BankTransferLogo from "@/assets/images/bank_transfer.webp";

interface ExchangeHistoryCardProps {
	index: number;
	item: Exchange;
	t: (key: string) => string;
}

interface Exchange {
	id: string;
	amount: number;
	payment: string;
	created_at: string;
	status: string;
}


export const ExchangeHistoryCard: React.FC<ExchangeHistoryCardProps> = ({
	index,
	item,
	t
}) => {
	const statusColors = {
		pending: "text-amber-300",
		complete: "text-green-600",
		declined: "text-red-600",
	};

	const paymentMethod = {
		bankTransfer: "Bank Transfer",
		amazon: "Amazon",
		payPay: "PayPay",
		googlePlay: "Google Play",
		apple: "Apple",
	}

	const paymentMethodLogo = {
		bankTransfer: BankTransferLogo,
		amazon: AmazonLogo,
		payPay: PayPayLogo,
		googlePlay: GooglePlayLogo,
		apple: AppleLogo,
	}

	return (
		<>
			<div className="flex gap-5 justify-between w-full text-base max-md:max-w-full" aria-label="Exchange history card">
				<div className="flex gap-5">
					<Image
						src={paymentMethodLogo[item.payment as keyof typeof paymentMethodLogo]}
						alt={paymentMethod[item.payment as keyof typeof paymentMethod]}
						className="object-contain shrink-0 aspect-square w-[70px]"
						aria-label="Exchange history card image"
					/>
					<div className="flex flex-col max-sm:text-sm my-auto text-black" aria-label="Exchange history card title">
						<div className="font-medium" aria-label="Exchange history card title">{paymentMethod[item.payment as keyof typeof paymentMethod]}</div>
						<div className="self-start mt-1.5 font-bold" aria-label="Exchange history card amount">{item.amount + " "}{t("yen")}</div>
					</div>
					<div
						className={`self-start max-sm:hidden mt-2 font-medium capitalize ${statusColors[item.status as keyof typeof statusColors]}`}
						aria-label="Exchange history card status"
					>
						{t(item.status)}
					</div>
				</div>
				<div>
					<div className="self-start max-sm:text-sm mt-3 font-medium text-right text-black" aria-label="Exchange history card date">
						{new Date(item.created_at).toLocaleDateString()}
					</div>
					<div
						className={`self-start max-sm:text-sm hidden max-sm:block mt-2 font-medium capitalize ${statusColors[item.status as keyof typeof statusColors as keyof typeof statusColors]}`}
						aria-label="Exchange history card status"
					>
						{t(item.status)}
					</div>
				</div>
			</div>
			<div className="shrink-0 h-px border border-solid border-zinc-300 border-opacity-90 max-md:max-w-full" aria-label="Exchange history card divider" />
		</>
	);
};
