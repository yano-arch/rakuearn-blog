'use client';

import React from 'react'
import { store } from '@/redux/store';
import OnboardingWarning from '@/components/OnboardingWarning';
import OverviewDashboard from '@/components/overview/Completed';


const Configuration = () => {

  const onboardingStatus = store.getState().onboarding.onboardingStatus;

  return ( onboardingStatus == 'SKIPPED' ? 
    ( <OnboardingWarning/>) :
    ( <div className="w-full h-full">
      <OverviewDashboard/>
  </div>)
  );
}

export default Configuration