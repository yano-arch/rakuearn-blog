import React from "react";
import { useT } from "@/app/i18n/client";
import { getRedemptionOptions } from "@/constants/constants";
import Image from "next/image";
const RedemptionSection: React.FC = () => {
  const { t } = useT('home');
  const RedemptionOptions = getRedemptionOptions(t);

  return (
    <section className="px-0 max-md:px-4 max-sm:px-4 py-12 text-center" aria-label="Redemption section">
      <h2 className="mb-8 text-xl max-sm:mb-5 font-bold max-sm:text-xl" aria-label="Redemption title">
        {t('redemptionSection.title')}
      </h2>
      <div className="flex gap-10 justify-center max-md:flex-wrap max-sm:gap-5" aria-label="Redemption options">
        {RedemptionOptions.map((option, index) => (
          <article
            key={index}
            className="flex flex-col gap-2.5 justify-center items-center rounded-3xl bg-neutral-100 h-[122px] w-[156px] max-md:w-[calc(33%_-_26px)] max-sm:w-full"
            aria-label="Redemption option"
          >
            <Image
              src={option.icon}
              alt={option.title}
              className="h-[71px] w-[71px]"
              aria-label="Redemption option icon"
            />
            <h3 className="text-sm max-sm:text-xs font-bold" aria-label="Redemption option title">{option.title}</h3>
          </article>
        ))}
      </div>
    </section>
  );
};

export default RedemptionSection;
