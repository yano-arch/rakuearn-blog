import React from 'react'
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { User, Briefcase, GraduationCap, MapPin, Heart, Save } from "lucide-react"

const userProfileSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  age: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 18, {
    message: "You must be at least 18 years old.",
  }),
  occupation: z.string().min(2, { message: "Please enter your occupation." }),
  interests: z.string().min(10, { message: "Please describe your interests in more detail." }),
  education: z.string().min(2, { message: "Please enter your education level." }),
  location: z.string().min(2, { message: "Please enter your location." }),
})

export function ProfileForm() {
  const form = useForm<z.infer<typeof userProfileSchema>>({
    resolver: zodResolver(userProfileSchema),
    defaultValues: {
      name: "",
      age: "",
      occupation: "",
      interests: "",
      education: "",
      location: "",
    },
  })

  React.useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['userProfile'], (result) => {
        if (result.userProfile) {
          form.reset(result.userProfile)
        }
      })
    }
  }, [form])

  function onSubmit(values: z.infer<typeof userProfileSchema>) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({ userProfile: values }, () => {
        console.log('Profile saved:', values)
      })
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Full Name
                </FormLabel>
                <FormControl>
                  <Input 
                    placeholder="John Doe" 
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
                <FormDescription>
                  This will be used to personalize survey responses.
                </FormDescription>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="age"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base">Age</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="25" 
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
                <FormDescription>
                  Used for demographic-specific surveys.
                </FormDescription>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="occupation"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  Occupation
                </FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Software Engineer" 
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="education"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base flex items-center gap-2">
                  <GraduationCap className="w-4 h-4" />
                  Education Level
                </FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Bachelor's Degree" 
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem className="space-y-2">
              <FormLabel className="text-base flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Location
              </FormLabel>
              <FormControl>
                <Input 
                  placeholder="New York, USA" 
                  {...field}
                  className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                />
              </FormControl>
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="interests"
          render={({ field }) => (
            <FormItem className="space-y-2">
              <FormLabel className="text-base flex items-center gap-2">
                <Heart className="w-4 h-4" />
                Interests & Hobbies
              </FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Tell us about your interests, hobbies, and preferences..."
                  className="min-h-[120px] px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200 resize-none"
                  {...field}
                />
              </FormControl>
              <FormDescription>
                This helps the AI provide more personalized survey responses.
              </FormDescription>
            </FormItem>
          )}
        />

        <Button 
          type="submit" 
          className="w-full h-12 text-base font-medium bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          Save Profile
        </Button>
      </form>
    </Form>
  )
} 