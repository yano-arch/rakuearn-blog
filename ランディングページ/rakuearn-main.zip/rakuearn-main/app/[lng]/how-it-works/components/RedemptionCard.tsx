import * as React from "react";
import Image, { StaticImageData } from "next/image";

export const RedemptionCard: React.FC<{ number: number, title: string, description: string, image: StaticImageData }> = ({ number, title, description, image }) => {
	return (
		<div className="flex max-md:flex-col items-center gap-8 max-md:gap-2 mt-8" aria-label="Redemption card">
			<Image src={image} alt={title} width={100} height={100} aria-label="Redemption card image" />
			<div className="max-sm:flex max-sm:flex-col max-sm:items-center">
				<div className="flex gap-2.5 max-md:items-center max-md:mt-2 max-md:flex-col" aria-label="Redemption card title">
					<div className="px-2 text-center text-white whitespace-nowrap bg-violet-500 rounded-full h-[26px] w-[26px]">
						{number}
					</div>
					<h3 className="my-auto text-center text-black max-sm:text-sm" aria-label="Redemption card title">
						{title}
					</h3>
				</div>
				<div className="max-sm:w-2/3">
					<p className="mt-4 max-md:mt-2 text-center ml-9 max-md:ml-0 text-sm max-sm:text-xs font-semibold text-black max-md:max-w-full" aria-label="Redemption card description">
						{description}
					</p>
				</div>
			</div>
		</div>
	);
};

