"use client";
import * as React from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PostInput } from "./PostInput";
import { PostButton } from "./PostButton";
import { FileUpload } from "./FileUpload";
import { useT } from "@/app/i18n/client";
import { addSurvey, uploadSurveyFile } from "../actions";
import { Loader2 } from "lucide-react";
export const SurveyForm: React.FC = () => {
  const { t } = useT("admin");
  const [file, setFile] = React.useState<File | null>(null);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [title, setTitle] = React.useState<string>("");
  const [surveyProvider, setSurveyProvider] = React.useState<string>("");
  const [estimatedTime, setEstimatedTime] = React.useState<number>(0);
  const [pointsAmount, setPointsAmount] = React.useState<number>(0);
  const [link, setLink] = React.useState<string>("");
  const [promotionId, setPromotionId] = React.useState<string>("");
  const [fileUrl, setFileUrl] = React.useState<string>("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      console.log("Form validation failed");
      return;
    }

    setIsLoading(true);

    try {
      let finalFileUrl = fileUrl;
      if (file) {
        const uploadedFileUrl = await uploadSurveyFile(file); // This will upload only when form is submitted
        if (uploadedFileUrl) {
          finalFileUrl = uploadedFileUrl;
        }
      }

      const survey = await addSurvey({
        title,
        surveyProvider,
        estimatedTime,
        pointsAmount,
        link,
        promotionId,
        fileUrl: finalFileUrl,
      });

      console.log("Survey added:", survey);
      toast.success("Survey added successfully");

      // Reset form
      setTitle("");
      setSurveyProvider("");
      setEstimatedTime(0);
      setPointsAmount(0);
      setLink("");
      setPromotionId("");
      setFile(null);
      setFileUrl("");
    } catch (error) {
      console.error("Error adding survey:", error);
      toast.error("Failed to add survey");
    } finally {
      setIsLoading(false);
    }
  };

  const validateForm = () => {
    if (!title) {
      console.log("title not valid");
      return false;
    }
    if (!surveyProvider) {
      console.log("surveyProvider not valid");
      return false;
    }
    if (!estimatedTime) {
      console.log("estimatedTime not valid");
      return false;
    }
    if (!pointsAmount) {
      console.log("pointsAmount not valid");
      return false;
    }
    if (!link) {
      console.log("link not valid");
      return false;
    }
    if (!promotionId) {
      console.log("promotionId not valid");
      return false;
    }
    return true;
  };

  return (
    <section
      className="ml-5 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] w-[72%] max-md:ml-0 max-md:w-full mt-30 max-md:mt-10"
      aria-label="Survey form section"
    >
      <ToastContainer />
      <div className="flex flex-col items-start self-stretch my-auto w-full max-md:mt-10">
        <div className="flex max-md:flex-col-reverse max-sm:gap-4 items-start self-stretch w-full max-md:px-5 max-md:mb-10">
          <form
            onSubmit={handleSubmit}
            className="flex flex-col items-start self-stretch w-full max-md:px-5 max-md:mb-10"
            aria-label="Survey form"
          >
            <div className="self-stretch">
              <div className="flex gap-5 max-md:flex-col">
                <div className="w-[80%] max-md:w-full">
                  <div className="flex flex-col gap-5">
                    <PostInput
                      label={t("title")}
                      type="text"
                      required
                      aria-required="true"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                    />
                    <PostInput
                      label={t("surveyProvider")}
                      type="text"
                      required
                      aria-required="true"
                      value={surveyProvider}
                      onChange={(e) => setSurveyProvider(e.target.value)}
                    />
                    <PostInput
                      label={t("estimatedTime")}
                      type="number"
                      required
                      aria-required="true"
                      value={estimatedTime}
                      onChange={(e) => setEstimatedTime(Number(e.target.value))}
                    />
                  </div>
                  <div
                    className="mt-14 max-md:mt-10 space-y-5 w-[393px] max-md:w-full max-w-full"
                    aria-label="Survey form input section"
                  >
                    <PostInput
                      label={t("pointsAmount")}
                      type="number"
                      required
                      aria-required="true"
                      value={pointsAmount}
                      onChange={(e) => setPointsAmount(Number(e.target.value))}
                    />
                    <PostInput
                      label={t("link")}
                      type="url"
                      required
                      aria-required="true"
                      value={link}
                      onChange={(e) => setLink(e.target.value)}
                    />
                    <PostInput
                      label={t("promotionId")}
                      type="text"
                      required
                      aria-required="true"
                      value={promotionId}
                      onChange={(e) => setPromotionId(e.target.value)}
                    />

                    <div className="mt-28 max-md:mt-10">
                      <PostButton
                        type="submit"
                        fullWidth
                        className="px-16 flex items-center justify-center"
                      >
                        {isLoading ? (
                          <Loader2 className="animate-spin" />
                        ) : (
                          t("post")
                        )}
                      </PostButton>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div
            className="ml-10 mt-10 w-[62%] max-md:ml-0 max-md:w-full"
            aria-label="Survey form file upload section"
          >
            <FileUpload file={file} setFile={setFile} />
          </div>
        </div>
      </div>
    </section>
  );
};
