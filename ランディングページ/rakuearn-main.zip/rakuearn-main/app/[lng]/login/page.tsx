"use client";

import React from "react";
import Header from "@/components/layout/Header";
import { LoginForm } from "./components/LoginForm";
import { RegistrationForm } from "./components/Registration";
import { Layout } from "@/components/layout/Layout";
import Footer from "@/components/layout/Footer";
import { useT } from "@/app/i18n/client";
import { getUser } from "./action";

const LoginPage: React.FC = () => {	
	const { t } = useT('auth');
	return (
		<>
			<link
				href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
				rel="stylesheet"
			/>
			<Layout>
				<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Login page">
					<Header />
					<section className="px-26 py-0 mb-20 max-sm:px-4 max-md:py-0" aria-label="Login section">
						<h1 className="mb-8 text-3xl max-sm:mb-4 font-bold max-sm:text-xl">
							{t("login.title")}
						</h1>
						<div className="flex gap-8 p-6 rounded-3xl bg-neutral-100 max-md:flex-col max-sm:p-4">
							<LoginForm />
							<RegistrationForm />
						</div>
					</section>
				</div>
				<Footer />
			</Layout>
		</>
	);
};

export default LoginPage;
