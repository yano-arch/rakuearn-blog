import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      spacing: {
        'nav': '18.3%',
        'data-width': '45%',
        "card-width": "55%",
        "form-height": "58%",
        "user-form-width": "65%",
        "custom-form-div-height": "552px"
      },
      colors: {
        background: "var(--background)",
        "custom-lpurple-active": "#EAE5FC", // custom light purple color for active background
        "custom-dpurple-active": "#8771ef", // custom dark color for active text
        "custom-orange-accent": "#FF8400", // custom dark orange color for AI Filled Count Text 
        "custom-orange-bg": "#FFE4BE", // custom light orange color for AI Filled Count Background 
        "custom-inactive-text": "#A7A7C7", // custom light gray/purple color for inactive text
        "custom-lilac-bg": "#F5F5FF", // custom light gray/purple color for inactive text
        "custom-darkest-purple": "#333367", //custom darkest purple color for simple text
        foreground: "var(--foreground)",
      },
    },
  },
  plugins: [],
};
export default config;
