import * as React from "react";
import Image, { StaticImageData } from "next/image";
interface StepCardProps {
  stepNumber: number;
  title: string;
  description: string;
  image?: StaticImageData;
  points?: Array<{ amount: string }>;
}

export const StepCard: React.FC<StepCardProps> = ({
  stepNumber,
  title,
  description,
  image,
  points,
}) => {
  return (
    <article className="flex flex-col max-sm:items-center grow px-6 pt-5 pb-8 w-full font-bold text-center rounded-3xl bg-neutral-100 max-md:px-5 max-md:mt-6" aria-label="Step card">
      <div className="text-2xl text-[#D4C8FF]" aria-label="Step number">
        <span className="text-2xl max-sm:text-xl">step.</span>
        <span className="text-2xl max-sm:text-xl">{stepNumber}</span>
      </div>
      <h3 className="mt-2 max-md:mt-2 text-lg max-sm:text-base text-violet-500" aria-label="Step title">{title}</h3>
      {image && (
        <Image
          src={image}
          alt={`Step ${stepNumber} illustration`}
          className="object-fill self-center mt-6 max-md:mt-0 max-w-full h-[155px] min-h-[155px]"
          aria-label="Step image"
        />
      )}
      <div className="max-sm:w-2/3">
        <p className="mt-7 max-md:mt-2 text-sm max-sm:text-xs font-semibold text-black" aria-label="Step description">{description}</p>
      </div>
    </article>
  );
};
