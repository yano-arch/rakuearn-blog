import { defineContentScript } from 'wxt/sandbox'
import { AIService } from '@/services/ai-service'

export default defineContentScript({
  matches: ['*://*/*'],
  async main() {
    console.log("is this main on?")
    const aiService = new AIService()
    // Function to detect survey forms


    function cleanHTML(html: string): string {
      const allowedAttributes = new Set(["for", "id", "aria-checked", "name", "type", "value"]);
  
      // Parse the HTML using DOMParser
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
  
      doc.querySelectorAll('input, textarea, select').forEach(el => {
        const styles = window.getComputedStyle(el);
        if (el instanceof HTMLInputElement) {
        if (
            el.type === "hidden" ||
            el.name.includes("sentinel") ||
            el.name.match(/entry\.\d+_sentinel/) ||
            el.id.match(/botCheck|spamFilter|sentinel|honeypot/i) ||
            el.className.match(/bot-trap|spam-protect|fake-field|ghost-input|antibot|ignore-this|hidden/i) ||
            styles.display === "none" ||
            styles.visibility === "hidden" ||
            styles.opacity === "0" ||
            styles.position === "absolute" && parseInt(styles.left) < -500 

        ) {
            console.log("⚠️ Honeypot detected, ignoring:", el);
            el.remove();
        }
      }
    });
      // Extract and remove the content of script elements to keep absolute paths intact..
      const scriptContents: string[] = [];
      doc.querySelectorAll("script").forEach(script => {
        script.innerHTML = '';
        // scriptContents.push(script.innerHTML); if need to keep scripts
      });
  
      // Remove unwanted tag data entirely (style, link, meta). will keep for absolute paths.
      doc.querySelectorAll("meta, style, link").forEach(el => el.innerHTML = '');
  
      // Function to clean attributes of all elements
      function cleanAttributes(element: Element) {
          Array.from(element.attributes).forEach(attr => {
              if (!allowedAttributes.has(attr.name)) {
                  element.removeAttribute(attr.name);
              }
          });
      }

      // I think I'll be able to use absolute xpaths still because it'll just be removing the inputs, not the divs.

      // Clean other elements in the document
      doc.querySelectorAll("*").forEach(el => cleanAttributes(el));
  
      // Add the extracted script content back as plain text (in a safe way)
      const cleanedHTML = `<!DOCTYPE html>\n${doc.documentElement.outerHTML.trim()}`;
  
      // Insert the preserved script content (as a <script> tag) after the cleaned HTML
      const finalHTML = cleanedHTML.replace("</body>", `${scriptContents.map(content => `<script>${content}</script>`).join("\n")}\n</body>`);


      return finalHTML;
  }

   
    let isDetecting = false;
    async function detectSurvey() {
      if (isDetecting) return;
      isDetecting = true;

      const forms = document.querySelectorAll('form');

      const surveyForms = Array.from(forms).filter(form => {
        // Check if the form has a lot of input fields (likely a survey)
        const inputs = form.querySelectorAll('input[type="radio"], input[type="checkbox"], input[type="text"], textarea, select');

        return inputs.length > 3 // Basic heuristic for survey detection
      })

// removed surveyForms.length, surveyForms is checking for a truthy value so I changed it checking for truthy.
      if (surveyForms) {

        await aiService.initialize();
        console.log("sending message to chrome...")
        // Notify background script about the detected survey forms
        chrome.runtime.sendMessage({
          type: 'SURVEY_DETECTED',
          data: {
            url: window.location.href,
            formCount: forms.length
          }
        })

        // Process each survey form
        // not going to need this vvv for a min probably.
        for (const form of forms) {
          // console.log("const form of forms... line 38")
          try {
            const rawHTML = document.documentElement.outerHTML;
            const cleanedHTML = cleanHTML(rawHTML);


            const aiAnalysisResponse = await aiService.analyzeSurvey(cleanedHTML);
            // ***NEXT STEPS***
            //  ^^^ this is going to be a parsed AI response.

            await fillSurvey(aiAnalysisResponse); 


            // await fillSurvey(form, responses)
          } catch (error) {
            console.error('Error processing survey:', error)
          }
        }
      } 
      isDetecting = false;
    }
   

// Fill survey function
// Define types for aiAnalysisResponse and question objects
interface Question {
  element: string[];  // Array of XPath expressions
  content: string;    // Content to fill, if applicable
}

type AiAnalysisResponse = Question[];

// Fill survey function
async function fillSurvey(aiAnalysisResponse: AiAnalysisResponse): Promise<void> {
  if (!Array.isArray(aiAnalysisResponse) || aiAnalysisResponse.length === 0) {
    console.error("Invalid AI analysis response");
    return;
  }

  // Create an empty object to map xpaths to DOM elements
  const iterableHTMLDoc: Record<string, HTMLElement> = {};

  // Populate iterableHTMLDoc by mapping xpaths to actual elements in the DOM
  for (const questionObj of aiAnalysisResponse) {
    const xpathArr = questionObj.element || [];
    for (const xpath of xpathArr) {

      const element = getElementByXpath(xpath);
      if (element) {
        iterableHTMLDoc[xpath] = element;
      }
    }
  }

  // Now traverse the AI response and trigger actions on elements
  for (const questionObj of aiAnalysisResponse) {
    const xpathArr = questionObj.element || [];
    const fillContent = questionObj.content || "";

    try {
      if (xpathArr.length >= 1 && !fillContent.length) {
        // If there's no content, it's a click action
        console.log("CLICK TOOL CALL DETERMINED");
        for (const xpath of xpathArr) {
          const nodeAction = iterableHTMLDoc[xpath];
          if (nodeAction) {
            await clickTool(nodeAction);
          }
        }
      } else if (xpathArr.length === 1 && fillContent.length) {
        // If there is content, it's a fill action
        console.log("FILL TOOL CALL DETERMINED");
        const nodeAction = iterableHTMLDoc[xpathArr[0]];
        if (nodeAction) {
          await fillTool(nodeAction, fillContent);
        }
      }
    } catch (e: unknown) {
      console.error(`Error filling survey: ${(e as Error).message}`);
    }
  }
}

// Function to get an element by XPath
function getElementByXpath(xpath: string): HTMLElement | null {
  console.log("Getting XPath...");
  const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
  const node = result.singleNodeValue;
  if (node instanceof HTMLElement) {
    return node;
  } else {
    console.error(`No element found for XPath: ${xpath}`);
    return null;
  }
}

// Function to simulate clicking an element
async function clickTool(element: HTMLElement): Promise<void> {
  console.log("Running clickTool...");

  if (element && typeof element.click === "function") {
    // Handle checkbox/radio button with aria-checked
    const ariaChecked = element.getAttribute("aria-checked");
    if (ariaChecked !== null) {
      // If the element has aria-checked attribute, toggle the value
      const isChecked = ariaChecked === "true";
      const newCheckedState = !isChecked;

      // Update the aria-checked attribute before clicking
      element.setAttribute("aria-checked", newCheckedState.toString());

      console.log(`Toggled aria-checked to: ${newCheckedState}`);
    }

    // Perform the click action
    element.click();

    // Dispatch change event to simulate user interaction
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }
}

// Function to fill an input element with content
async function fillTool(element: HTMLElement, content: string): Promise<void> {
  console.log("Running fillTool...");
  if (element) {
    (element as HTMLInputElement).value = content; // Cast to HTMLInputElement to access the 'value' property
    console.log(element);
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }
}


  
  


     
      
      // Add a small delay for natural feeling
      // await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500))
    // inputElement.dispatchEvent(new Event('change', { bubbles: true }))

    // Initialize survey detection
    window.addEventListener('load', () => {
      console.log("Window load event fired, calling detectSurvey()");
    
      setTimeout(() => {
        detectSurvey();
      }, 5000); // Delay to allow page content to load
    });
    
    // ** this code is making fillSurvey func loop. need to get more specific in this block vvv

    // Set up MutationObserver to detect dynamic DOM changes
    // const observer = new MutationObserver(() => {
    //   console.log('DOM change detected, checking for surveys...');
      
    //   // Add a delay to ensure the changes are settled before detecting the survey
    //   setTimeout(() => {
    //     detectSurvey();
    //   }, 5000);
    // });
    
    // Observe the document for changes in the child list and subtree (to detect dynamic content changes)
    // observer.observe(document.body, {
    //   childList: true,
    //   subtree: true
    // });

    // ** this code is making fillSurvey func loop. need to get more specific in this block ^^^
  }
});
