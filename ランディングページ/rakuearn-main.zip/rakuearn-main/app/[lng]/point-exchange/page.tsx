"use client";
import * as React from "react";
import { useState } from "react";
import Header from "@/components/layout/Header";
import { HeroSection } from "./components/HeroSection";
import { AboutPoints } from "../how-it-works/components/AboutPoints";
import Footer from "@/components/layout/Footer";
import { Layout } from "@/components/layout/Layout";
import { PaymentSection } from "./components/PaymentSection";

function PointExchange() {
	const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("bank");

	return (
		<Layout>
			<div className="px-12 max-md:px-1 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Point exchange page">
				<Header />
				<div className="max-md:px-3 max-md:py-0">
					<HeroSection />
					<PaymentSection
						selectedPaymentMethod={selectedPaymentMethod}
						onPaymentMethodChange={setSelectedPaymentMethod}
					/>
					<AboutPoints />
				</div>
			</div>
			<Footer className="mt-30" />
		</Layout>
	);
}

export default PointExchange;
