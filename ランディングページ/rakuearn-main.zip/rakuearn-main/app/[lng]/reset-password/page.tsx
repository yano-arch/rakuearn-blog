"use client";

import React, { useEffect, useState } from "react";
import { createClient } from "@/utils/supabase/client";
import Header from "@/components/layout/Header";
import { Layout } from "@/components/layout/Layout";
import Footer from "@/components/layout/Footer";
import { toast, ToastContainer } from "react-toastify";
import { updatePassword } from "../login/action";
import { useT } from "@/app/i18n/client";
import { RequiredLabel } from "../register/components/RequiredLabel";
const ResetPage: React.FC = () => {
	const { t } = useT('auth');
	const supabase = createClient();
	const [password, setPassword] = useState('');
	const [confirmPassword, setConfirmPassword] = useState('');
	const [isLoading, setIsLoading] = useState(false);

	const handleSubmit = async () => {
		setIsLoading(true);
		if (password !== confirmPassword) {
			toast.error("Passwords do not match");
			setIsLoading(false);
			return;
		}
		if (password.length < 8) {
			console.log("length", password.length);
			toast.error("Password must be at least 8 characters long");
			setIsLoading(false);
			return;
		}
		const { success, error } = await updatePassword(password);
		if (success) toast.success("Password updated successfully!")
		if (error) toast.error("There was an error updating your password.")

		setIsLoading(false);
	}
	return (
		<>
			<link
				href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
				rel="stylesheet"
			/>
			<Layout>
				<ToastContainer />
				<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Login page">
					<Header />
					<section className="px-26 py-0 mb-20 mt-20 max-sm:px-4 max-md:py-0" aria-label="Login section">
						<h1 className="mb-8 text-3xl max-sm:mb-4 font-bold max-sm:text-xl">
							{t("resetPassword.header")}
						</h1>
						<div className="flex gap-8 p-6 flex-col max-sm:p-4">
							<div className="w-full flex items-center gap-2">
								<RequiredLabel text={t("resetPassword.password")} />
								<input
									type="password"
									id="password"
									className=" border w-[400px] border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block  p-2.5"
									onChange={(e) => setPassword(e.target.value)}
									value={password}
									placeholder={t("resetPassword.password")}
									required />
							</div>
							<div className="w-full flex items-center gap-2">
								<label htmlFor="confirmPassword" className="w-[18%] min-w-[250px] max-sm:w-full block mb-2 text-sm font-medium text-gray-900">
									{t("resetPassword.confirmPassword")}
								</label>
								<input
									type="password"
									id="confirmPassword"
									className="border w-[400px] border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
									onChange={(e) => setConfirmPassword(e.target.value)}
									placeholder={t("resetPassword.confirmPassword")}
									value={confirmPassword}
									required />
							</div>
							<div className="w-full flex items-center gap-2">
								<div className="w-[18%] min-w-[250px] max-sm:w-full block mb-2 text-sm font-medium text-gray-900">
								</div>
								<button
									className="w-[400px] flex justify-center items-center text-white max-sm:ml-0 bg-[#8771EF] focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-[100px] mt-20 text-sm px-5 py-2.5 text-center mr-2 mb-2"
									onClick={handleSubmit}
								>
									{isLoading ? <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white"></div> : t("resetPassword.confirm")}
								</button>
							</div>

						</div>
					</section>
				</div>
				<Footer />
			</Layout>
		</>
	);
};

export default ResetPage;
