interface Chrome {
  storage: {
    local: {
      get: (keys: string[]) => Promise<any>;
      set: (items: object) => Promise<void>;
    };
  };
}

declare var chrome: Chrome; 