import React, { useState, useEffect } from "react";
import { SurveyCard } from "./SurveyCard";
import { ThumbsUp } from "lucide-react";
import { useT } from "@/app/i18n/client";
import { SurveyFile } from "@/constants/constants";
export const RecommendedSection: React.FC<{ recommendedSurveys: any[] | {error: string} | null }> = ({ recommendedSurveys } ) => {
	const { t } = useT('surveyList');
  const [popularSurveys, setPopularSurveys] = useState<any[] | {error: string} | null | undefined>(null)

  useEffect(() => {
    if (recommendedSurveys && 'error' in recommendedSurveys) {
      return;
    }
    const sortedSurveys = recommendedSurveys?.sort((a, b) => b.popularity - a.popularity).slice(0, 5)
    setPopularSurveys(sortedSurveys)
  }, [recommendedSurveys])

  return (
    <section aria-label="Recommended section">
      <div className="flex gap-2 items-center mb-8 max-sm:mb-4">
        <ThumbsUp color="#8771EF" />
        <h2 className="text-2xl max-sm:text-xl font-bold text-violet-500">
            {t('recommendedSection.title')}
        </h2>
      </div>
      <div className="grid gap-5 mb-10 grid-cols-[repeat(5,1fr)] max-[1200px]:grid-cols-[repeat(4,1fr)] max-[1024px]:grid-cols-[repeat(3,1fr)] max-[768px]:grid-cols-[repeat(2,1fr)]" aria-label="Recommended surveys cards">
        {popularSurveys && 'error' in popularSurveys ? (
          <div className="text-center text-red-500">
            {popularSurveys.error}
          </div>
        ) : (
          popularSurveys?.map((survey) => (
            <SurveyCard
              key={survey.id}
              id={survey.id}
              title={survey.title}
              dateAdded={survey.created_at}
              points={survey.points}
              imageUrl={SurveyFile + survey.file_path}
            />
          ))
        )}
      </div>
    </section>
  );
};
