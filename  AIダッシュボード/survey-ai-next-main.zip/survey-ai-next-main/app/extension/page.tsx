import React from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card } from '@/components/ui/card'
import { Bot } from 'lucide-react'
import { ProfileForm } from '@/components/forms/ProfileForm'
import { SitesForm } from '@/components/forms/SitesForm'
import { ScheduleForm } from '@/components/forms/ScheduleForm'

export default function ExtensionPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white dark:from-zinc-900 dark:to-zinc-800 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center space-x-4">
          <Bot className="h-12 w-12 text-zinc-900 dark:text-zinc-100" />
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100">
              Survey AI Autofill
            </h1>
            <p className="text-zinc-500 dark:text-zinc-400 text-lg">
              Configure your AI assistant preferences and settings
            </p>
          </div>
        </div>

        <Card className="p-6 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-sm border border-zinc-200 dark:border-zinc-800 shadow-xl rounded-xl">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="w-full grid grid-cols-3 h-14 items-center bg-zinc-100 dark:bg-zinc-800 rounded-lg p-1 gap-1">
              <TabsTrigger 
                value="profile"
                className="h-12 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 rounded-md transition-all"
              >
                Profile
              </TabsTrigger>
              <TabsTrigger 
                value="sites"
                className="h-12 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 rounded-md transition-all"
              >
                Survey Sites
              </TabsTrigger>
              <TabsTrigger 
                value="schedule"
                className="h-12 data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-900 rounded-md transition-all"
              >
                Schedule
              </TabsTrigger>
            </TabsList>
            <div className="mt-6 space-y-6">
              <TabsContent value="profile">
                <ProfileForm />
              </TabsContent>
              <TabsContent value="sites">
                <SitesForm />
              </TabsContent>
              <TabsContent value="schedule">
                <ScheduleForm />
              </TabsContent>
            </div>
          </Tabs>
        </Card>

        <div className="text-center text-sm text-zinc-500 dark:text-zinc-400">
          <p>
            To start using the extension, configure your settings above and click the extension icon in your browser.
          </p>
        </div>
      </div>
    </div>
  )
} 