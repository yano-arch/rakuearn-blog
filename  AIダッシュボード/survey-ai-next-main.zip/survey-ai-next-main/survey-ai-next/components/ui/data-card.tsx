import { FC } from "react";
import { Wallet, SquarePen } from "lucide-react"; // Import required icons

interface DataCardProps {
  iconType: "wallet" | "squarePen"; // Define expected icon types
  iconBgColor: string;
  iconColor: string; // Example: "text-red-500"
  title: string;
  description: string;
  descriptionColor: string;
  containerBg: string;
}

const DataCard: FC<DataCardProps> = ({
  iconType,
  iconBgColor,
  iconColor,
  title,
  description,
  descriptionColor,
  containerBg,
}) => {
  // Function to determine which icon to use
  const renderIcon = () => {
    switch (iconType) {
      case "wallet":
        return <Wallet className={`w-5 h-5 sm:w-6 sm:h-6 ${iconColor}`} />;
      case "squarePen":
        return <SquarePen className={`w-5 h-5 sm:w-6 sm:h-6 ${iconColor}`} />;
      default:
        return null; // Handle cases where the icon type is not recognized
    }
  };

  return (
    <div
      className={`flex items-center p-3 sm:p-4 border border-gray-300 rounded-2xl shadow-md max-w-full sm:max-w-md w-full place-items-center ${containerBg}`}
    >
      {/* Icon Container */}
      <div className={`flex items-center justify-center p-3 sm:p-4 rounded-md ${iconBgColor}`}>
        {renderIcon()}
      </div>

      {/* Card Content */}
      <div className="ml-3 sm:ml-4">
        <h3 className="text-base font-semibold sm:text-med text-custom-inactive-text">{title}</h3>
        <p className={`text-xl sm:text-2xl font-bold ${descriptionColor}`}>{description}</p>
      </div>
    </div>
  );
};

export default DataCard;
