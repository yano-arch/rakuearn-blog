import * as React from "react";
import { StatCard } from "./StatCard";
import { useT } from "@/app/i18n/client";
import { getTotalUsers, getTotalPoints, getPendingExchanges, getExchangeCompleted } from "../actions";
import { Loader2 } from "lucide-react";
import "react-datepicker/dist/react-datepicker.css";
import { ExchangeStatCard } from "./ExchangeStatCard";
import DatePicker from "react-datepicker";

export const DashboardContent: React.FC = () => {
	const { t } = useT('admin');
	const [totalUsers, setTotalUsers] = React.useState<number>(0);
	const [totalPoints, setTotalPoints] = React.useState<number>(0);
	const [pendingExchanges, setPendingExchanges] = React.useState<number>(0);
	const [exchangeCompleted, setExchangeCompleted] = React.useState<number>(0);
	const [isLoading, setIsLoading] = React.useState<boolean>(true);
	const [startDate, setStartDate] = React.useState<Date>(new Date());
	const [endDate, setEndDate] = React.useState<Date>(new Date());
	const [isDateLoading, setIsDateLoading] = React.useState<boolean>(false);

	React.useEffect(() => {
		const fetchData = async () => {
			const totalUsers = await getTotalUsers();
			const totalPoints = await getTotalPoints();
			const pendingExchanges = await getPendingExchanges();
			const exchangeCompleted = await getExchangeCompleted(new Date(startDate).toISOString(), new Date(endDate).toISOString());
			if ('error' in totalUsers) {
				console.error('Total users retrieval failed', totalUsers.error);
			} else {
				setTotalUsers(totalUsers.length);
				console.log("totalUsers", totalUsers);
			}
			if ('error' in totalPoints) {
				console.error('Total points retrieval failed', totalPoints.error);
			} else {
				setTotalPoints(totalPoints.map((point) => point.point).reduce((a, b) => a + b, 0));
				console.log("totalPoints", totalPoints);
			}
			if ('error' in pendingExchanges) {
				console.error('Pending exchanges retrieval failed', pendingExchanges.error);
			} else {
				setPendingExchanges(pendingExchanges.length);
			}
			if ('error' in exchangeCompleted) {
				console.error('Exchange completed retrieval failed', exchangeCompleted.error);
			} else {
				setExchangeCompleted(exchangeCompleted.length);
				console.log("exchangeCompleted", exchangeCompleted);
			}
			setIsLoading(false);
		}
		fetchData();
	}, []);

	React.useEffect(() => {
		console.log("startDate", startDate);
		setIsDateLoading(true);
		const fetchData = async () => {
			const exchangeCompleted = await getExchangeCompleted(new Date(startDate).toISOString(), new Date(endDate).toISOString());
			if ('error' in exchangeCompleted) {
				console.error('Exchange completed retrieval failed', exchangeCompleted.error);
			} else {
				setExchangeCompleted(exchangeCompleted.length);
				console.log("exchangeCompleted", exchangeCompleted);
			}
			setIsDateLoading(false);
		}
		fetchData();
	}, [startDate, endDate]);

	return (
		<main className="ml-5 w-[72%] max-md:ml-0 max-md:mb-20 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] max-md:w-full" aria-label="Dashboard content">
			<div className={`mt-28 w-full max-md:mt-10 max-md:max-w-full ${isLoading ? "flex flex-col items-center justify-center" : ""}`}>
			<div className="flex flex-col items-end gap-5">
				<div className="w-[150px] flex mx-2 gap-2 justify-between items-center">
					<label className="text-base text-black">From:</label>
					<DatePicker
						selected={startDate}
						onChange={(date) => setStartDate(date || new Date())}
						className="w-[100px] text-base outline-2 p-2 rounded-md font-medium cursor-pointer"
					/>
				</div>
				<div className="w-[150px] flex mx-2 gap-2 justify-between items-center">
					<label className="text-base text-black">To:</label>
					<DatePicker
						selected={endDate}
						onChange={(date) => setEndDate(date || new Date())}
						className="w-[100px] text-base outline-2 p-2 rounded-md font-medium cursor-pointer"
					/>
					</div>
				</div>
				{isLoading ? (
					<div className="flex justify-center items-center h-full">
						<Loader2 className="animate-spin" size={60} />
					</div>
				) : (
					<>
						<section className="max-md:max-w-full">
							<div className="flex gap-5 max-md:w-full max-sm:px-2 max-md:flex-col max-md:items-center">
								<div className="max-md:ml-0 max-md:w-full" >
									<StatCard title={t("totalUsers")} value={totalUsers} isLoading={isLoading} />
								</div>
								<div className="ml-5 max-md:ml-0 max-md:w-full">
									<StatCard title={t("totalPointsDistributed")} value={totalPoints.toLocaleString()} isLoading={isLoading} />
								</div>
							</div>
						</section>

						<section className="mt-20 max-md:mt-10 max-md:max-w-full">
							<div className="flex gap-5 max-md:w-full max-sm:px-2 max-md:flex-col max-md:items-center">
								<div className="max-md:ml-0 max-md:w-full">
									{/* <ExchangeStatCard
										title={t("exchangesToday")}
										value={exchangeCompleted}
										setStartDate={setStartDate}
										setEndDate={setEndDate}
										startDate={startDate}
										endDate={endDate}
										isLoading={isDateLoading}
									/> */}
									<StatCard
										title={t("exchangesToday")}
										value={exchangeCompleted}
										isLoading={isDateLoading}
									/>
								</div>
								<div className="ml-5 max-md:ml-0 max-md:w-full">
									<StatCard
										title={t("pendingRequests")}
										value={pendingExchanges}
										variant="highlight"
										isLoading={isLoading}
									/>
								</div>
							</div>
						</section>
					</>
				)}
			</div>
		</main>
	);
};
