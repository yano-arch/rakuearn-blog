"use client";
import React, { useEffect, useState } from "react";
import Header from "@/components/layout/Header";
import { RecommendedSection } from "./components/RecommendedSection";
import { AllSurveysSection } from "./components/AllSurveysSection";
import Footer from "@/components/layout/Footer";
import { Layout } from "@/components/layout/Layout";
import { getSurveys } from "@/app/[lng]/admin/actions";

const InputDesign: React.FC = () => {
	const [allSurveys, setAllSurveys] = useState<any[] | { error: string } | null>(null);
	const [isLoading, setIsLoading] = useState(true);
	useEffect(() => {
		const fetchSurveys = async () => {
			const allSurveys = await getSurveys();
			if ('error' in allSurveys) {
				console.error('Error fetching surveys', allSurveys.error);
			} else {
				setAllSurveys(allSurveys);
				console.log(allSurveys);
			}
			setIsLoading(false);
		};
		fetchSurveys();
	}, []);

	return (
		<Layout>
			<div className="px-12 max-md:px-0 w-full max-w-[1440px] max-md:max-w-[991px]" aria-label="Survey list page">
				<Header />
				{isLoading ? (
					<div className="flex justify-center items-center h-screen">
						<div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-violet-500"></div>
					</div>
				) : (
					<>
						<div className="px-16 py-10 max-md:px-5 max-sm:px-4 max-md:py-0" aria-label="Survey list content">
							<RecommendedSection recommendedSurveys={allSurveys} />
							<AllSurveysSection allSurveys={allSurveys} />
						</div>
					</>
				)}
			</div>
			<Footer />
		</Layout>
	);
};

export default InputDesign;
