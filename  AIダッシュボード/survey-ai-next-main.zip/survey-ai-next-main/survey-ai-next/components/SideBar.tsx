'use client'

import { useState } from 'react';
import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import Login from './authentication/Login';
import Register from './authentication/Register';
import Onboarding from './Onboarding';
import SideNavBar from './SideNavBar';
import { store } from '@/redux/store';
import Image from 'next/image';

const Sidebar = () => {
  const { data: session } = useSession();
  const [showLoginOptions, setShowLoginOptions] = useState(false);
  const [showRegisterOptions, setShowRegisterOptions] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [name, setName] = useState('');
  

  const onboardingStatus = store.getState().onboarding.onboardingStatus;

  const handleRegisterComplete = (name: string) => {
    setName(name);
    setShowRegisterOptions(false);
    setShowOnboarding(true);
  };

  return (
    <aside className="w-72 bg-[rgba(255,255,255)]/[.03]  text-white p-4 m-4 rounded-xl">
      
      <h2 className="text-4xl font-mono font-extrabold text-center m-5">Autofill AI</h2>
      <nav className="mt-4">
        {session ? (
          <>
            <p className="mb-2">Welcome, {session.user?.name}!</p>
            <ul>
              <li>
                <Link href="/dashboard">Dashboard</Link>
              </li>
              <li>
                <Link href="/profile">Profile</Link>
              </li>
              <li>
                <Link href="/onboarding">Onboarding</Link>
              </li>
              <li>
                <button onClick={() => signOut()} className="mt-2 bg-red-500 p-2 w-full">
                  Logout
                </button>
              </li>
            </ul>
          </>
        ) : showLoginOptions ? (
          <Login onBack={() => setShowLoginOptions(false)} />
        ) : showRegisterOptions ? (
          <Register onBack={() => setShowRegisterOptions(false)} onComplete={handleRegisterComplete} />
        ) : showOnboarding ? (
          <Onboarding name={name} />
        ) : onboardingStatus == 'COMPLETED' ? (
          <SideNavBar />
        ) :
        (
          <>
            <div className='p-3 my-5 font-mono justify-stretch text-xl'>
            Automate Surveys with AI—Fast, Accurate, and Hassle-Free Autofill!
            </div>
            <button onClick={() => setShowLoginOptions(true)} className="bg-gradient-to-br from-teal-400 to-teal-500 p-2 w-full rounded-md self-end">
              Login
            </button>
            <button onClick={() => setShowRegisterOptions(true)} className="mt-2 bg-gradient-to-br from-teal-400 to-teal-500 p-2 w-full rounded-md self-end">
              Sign Up
            </button>
          </>
        )}
      </nav>
    </aside>
  );
};

export default Sidebar;