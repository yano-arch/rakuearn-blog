import React from 'react'
import SignUp from '@/components/authentication/Register'

const page = () => {
  return (
    <div>
        <SignUp />
    </div>
  )
}

export default page