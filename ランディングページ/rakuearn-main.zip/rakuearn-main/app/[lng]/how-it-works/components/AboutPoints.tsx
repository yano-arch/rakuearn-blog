"use client";

import * as React from "react";
import { CategoryTitle } from "@/components/comps/CategoryTitle";
import PointRate from "@/assets/images/point_rate.svg";
import Image from "next/image";
import { useT } from "@/app/i18n/client";

export const AboutPoints: React.FC = () => {
	const { t } = useT('howItWorks');
	return (
		<section className="mt-14 mb-14 max-w-full max-md:mt-18 max-sm:px-2" aria-label="About points section">
			<CategoryTitle title={t('aboutPoints.title')} />
			<div className="flex ml-10 w-[826px] max-md:w-full max-md:ml-0 max-md:items-center gap-5 max-md:mt-2 mt-15 max-md:flex-col" aria-label="About points content">
				<div className="w-[33%] max-md:w-[50%]">
					<div className="flex grow gap-3.5 font-bold text-center text-white max-md:mt-5">
						<Image src={PointRate} alt="Point Rate" className="w-full h-full" aria-label="Point Rate" />
					</div>
				</div>
				<div className="ml-5 w-[80%] max-sm:w-[85%] max-md:ml-0" aria-label="About points content right">
					<div className="flex flex-col max-md:items-center self-stretch my-auto text-black max-md:mt-10 max-md:max-w-full">
						<h2 className="self-start max-md:self-center text-xl max-sm:text-base text-center font-bold">
							{t('aboutPoints.exchangeRate')}
						</h2>
						<p className="mt-4 text-sm max-sm:text-xs max-md:text-center font-semibold max-md:max-w-full">
							{t('aboutPoints.exchangeRateDescription')}
							<br />
							{t('aboutPoints.dashboardDescription')}
						</p>
					</div>
				</div>
			</div>
		</section>
	);
};
