"use client";
import React from "react";
import { useT } from "@/app/i18n/client";
import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useParams } from "next/navigation";
import { logout } from "@/app/[lng]/login/action";
export const OtherSettings: React.FC = () => {
  const { t } = useT('auth');
  const router = useRouter();
  const lng = useParams().lng;
  return (
    <section className="mb-10" aria-labelledby="other-settings">
      <h2 id="other-settings" className="mb-5 max-sm:mb-3 text-2xl max-sm:text-xl font-bold text-black" aria-label="Other settings title">
        {t("otherSettings.title")}
      </h2>
      <nav>
        <ul>
          <li>
            <Link
              href="/account-setting"
              className="flex justify-between items-center px-0 py-5 max-sm:py-3 text-lg max-sm:text-base font-semibold text-black border-b border-solid border-b-zinc-300 border-b-opacity-90"
            >
              <span>{t("otherSettings.accountSetting")}</span>
              <ArrowRight />
            </Link>
          </li>
          <li>
            <Link
              href="mailto:team@rakuearn.com"
              className="flex justify-between items-center px-0 py-5 max-sm:py-3 text-lg max-sm:text-base font-semibold text-black border-b border-solid border-b-zinc-300 border-b-opacity-90"
            >
              <span>{t("otherSettings.contact")}</span>
              <ArrowRight />
            </Link>
          </li>
          <li>
            <button
              onClick={() => {
                logout();
                router.push(`/${lng}/`);
                localStorage.setItem("isLoggedIn", "false");
              }}
              className="w-full cursor-pointer flex justify-between items-center px-0 py-5 max-sm:py-3 text-lg max-sm:text-base font-semibold text-black border-b border-solid border-b-zinc-300 border-b-opacity-90"
            >
              <span>{t("otherSettings.logout")}</span>
              <ArrowRight />
            </button>
          </li>
        </ul>
      </nav>
    </section>
  );
};
