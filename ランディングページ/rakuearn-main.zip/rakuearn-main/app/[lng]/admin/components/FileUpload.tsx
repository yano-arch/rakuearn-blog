import * as React from "react";
import { useT } from "@/app/i18n/client";

export const FileUpload: React.FC<{ file: File | null; setFile: (file: File | null) => void }> = ({ file, setFile }) => {
  const { t } = useT('admin');
  const [isDragging, setIsDragging] = React.useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    setFile(droppedFile);
    // Handle the file drop logic here, but no upload yet
  };

  return (
    <div
      className={`flex flex-col grow justify-center items-center px-20 py-10 text-lg text-center text-black rounded-xl border border-dashed border-neutral-400 transition-colors ${
        isDragging ? 'bg-neutral-50' : ''
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      role="button"
      tabIndex={0}
      aria-label="File upload area"
    >
      <div className="flex flex-col items-center max-w-full w-[248px]">
        <img
          src="https://cdn.builder.io/api/v1/image/assets/87b5d4114987481390e084a568fbb563/e7b22d4067a835fddb0ee6c8299304178e3838f7?placeholderIfAbsent=true"
          alt="Upload icon"
          className="object-contain aspect-square w-[50px]"
        />
        {file && <p className="self-stretch mt-3.5">{file.name}</p>}
        <p className="self-stretch mt-3.5">{t('dragAndDrop')}</p>
        <p className="mt-2.5 text-sm">{t('or')}</p>
        <button
          className="px-5 py-2.5 mt-3.5 max-w-full whitespace-nowrap rounded-md border border-black border-solid w-[106px]"
          onClick={() => document.getElementById('fileInput')?.click()}
        >
          {t('browse')}
        </button>
        <input
          type="file"
          id="fileInput"
          className="hidden"
          aria-label="File input"
          onChange={(e) => {
            const selectedFile = e.target.files?.[0];
            if (selectedFile) {
              setFile(selectedFile); // Just update the file state, don't upload yet
              console.log('file selected:', selectedFile);
            }
          }}
        />
        <p className="mt-4 text-sm">1080 x 1080 px</p>
      </div>
    </div>
  );
};
