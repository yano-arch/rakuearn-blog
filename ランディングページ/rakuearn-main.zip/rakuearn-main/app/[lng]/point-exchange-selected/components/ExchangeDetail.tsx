import React from "react";
import { Info } from "lucide-react";
import { TableRow } from "./TableRow";
import { getExchangeDetails } from "@/constants/constants";
import { useT } from "@/app/i18n/client";

export const ExchangeDetails: React.FC = () => {
	const { t } = useT('pointExchange');
	return (
		<section className="mt-16 max-sm:mt-12" aria-label="Exchange details section">
			<h2 className="flex gap-2 items-center mb-8 max-md:mb-4 text-2xl max-md:text-lg font-bold text-violet-500" aria-label="Exchange details title">
				<Info color="#8771EF" className="w-[24px] max-sm:w-[20px]" />
				{t("exchangeDetails.title")}
			</h2>
			<div className="bg-white rounded-3xl border border-solid border-zinc-300 border-opacity-90">
				<dl>
					{getExchangeDetails(t).map((detail) => (
						<TableRow key={detail.title} title={detail.title} content={detail.content} className={detail.className} rounded={detail.rounded} />
					))}
				</dl>
			</div>
		</section>
	);
};
