import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSelector, useDispatch } from "react-redux";
import { RootState } from "@/redux/store";
import { completeOnboarding, skipOnboarding} from "@/redux/onboardingSlice";

import SideNavBar from "./SideNavBar";

const Onboarding = ({ name: initialName }: { name: string }) => {
  const router = useRouter();
  const dispatch = useDispatch();

  // Get onboarding status from Redux
  const onboardingStatus = useSelector(
    (state: RootState) => state.onboarding.onboardingStatus
  );
 
  const [name, setName] = useState(initialName)
  const [age, setAge] = useState("");
  const [occupation, setOccupation] = useState("");
  const [interests, setInterests] = useState("");

  const handleOnboardingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(completeOnboarding()); // Set onboarding to completed
    router.push("/overview");

    console.log("Onboarding completed with:", { name, age, occupation, interests });
    // will need to post this to db and fetch from extension.
  };

  const handleSkip = () => {
    dispatch(skipOnboarding()); // Keep onboarding as incomplete
    router.push("/overview");
    console.log("Onboarding skipped");
  };

  return (
    <div className="p-4">
      {onboardingStatus == 'UNCOMPLETED' || onboardingStatus == 'SKIP' ? (
        <div className="flex flex-col">
            <h1 className="text-xl font-bold">Profile</h1>
          <form onSubmit={handleOnboardingSubmit} className="w-full rounded-lg">
            <input
              type="text"
              defaultValue={initialName} // Keeps name but allows user input
              onChange={(e) => setName(e.target.value)}
              placeholder="Name"
              className="p-2 mt-5 w-full text-gray-300 border-b-2 bg-transparent border-[#35866e]"
              required
            />
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder="Age"
              className="p-2 w-full mt-5 text-gray-300 border-b-2 bg-transparent border-[#35866e]"
              required
            />
            <input
              type="text"
              value={occupation}
              onChange={(e) => setOccupation(e.target.value)}
              placeholder="Occupation"
              className="p-2 w-full mt-5 text-gray-300 border-b-2 bg-transparent border-[#35866e]"
              required
            />
            <input
              type="text"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="Interests"
              className="p-2 w-full mt-5 text-gray-300 border-b-2 bg-transparent border-[#35866e]"
              required
            />
            <div className="flex justify-between mt-4">
              <button type="submit" className="bg-teal-500 text-white p-2 w-full rounded-md mr-2">
                Confirm
              </button>
              <button
                type="button"
                onClick={handleSkip}
                className="bg-gray-500 text-white p-2 w-full rounded-md ml-2"
              >
                Skip
              </button>
            </div>
          </form>
      </div>) : (
        <SideNavBar />
      )}
      
    </div>
  );
};

export default Onboarding;
