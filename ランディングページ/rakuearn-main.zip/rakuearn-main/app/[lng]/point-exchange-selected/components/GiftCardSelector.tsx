"use client";
import React, { useState } from "react";
import { addGiftCard } from "../actions";
import { getPaymentCardImg } from "@/constants/constants";
import { useT } from "@/app/i18n/client";
import Button from "@/components/layout/Button";
import { Loader2 } from "lucide-react";
import { toast, ToastContainer } from "react-toastify";
import { getUser } from "@/app/[lng]/login/action";
import { getPoints } from "@/app/[lng]/admin/actions";
const amounts = [300, 500, 1000, 3000, 10000];
type PaymentMethodId = 'bankTransfer' | 'amazon' | 'apple' | 'googlePlay' | 'payPay';


export const GiftCardSelector: React.FC<{ id: PaymentMethodId, setLoginRequiredModal: (modal: boolean) => void }> = ({ id, setLoginRequiredModal }) => {
	const { t } = useT('pointExchange');
	const [selectedAmount, setSelectedAmount] = useState<number>(0);
	// First define the type for individual payment card

	// Then use it in your component
	const PaymentCardImg = getPaymentCardImg(t);
	const [isLoading, setIsLoading] = useState(false);

	const apply = async () => {
		const { user, error } = await getUser();
		if (error) {
			console.error('User retrieval failed', error);
			setLoginRequiredModal(true);
			return;
		} else {
			console.log('User retrieved successfully', user);
		}
		if (!selectedAmount) {
			// You might want to show an error message here
			toast.error("Please select an amount");
			return;
		}


		const points = await getPoints(user.user?.email || "");
		if (points < selectedAmount) {
			toast.error("Insufficient points");
			return;
		}

		setIsLoading(true);
		try {
			await addGiftCard({
				amount: selectedAmount,
				paymentMethodId: id,
				userEmail: user.user?.email || ""
			});
			toast.success("Gift card applied successfully");
			// Handle success - maybe show a success message or redirect
		} catch (error) {
			console.error('Error applying for gift card:', error);
			// Handle error - show error message to user
		} finally {
			setIsLoading(false);
		}
	}

	return (
		<section className="self-center px-14 py-5 mt-5 max-sm:mt-0 rounded-3xl bg-neutral-100 max-w-[1300px] max-md:px-2 max-md:max-w-full" aria-label="Gift card selector section">
			<ToastContainer />
			<div className="px-10 py-5 mt-5 max-md:mt-0 rounded-3xl bg-neutral-100 max-sm:px-3 max-sm:py-8" aria-label="Gift card selector content">
				<div className="flex gap-24 max-md:gap-10 max-[1160px]:flex-col max-[1160px]:items-center" aria-label="Gift card selector content">
					<img src={PaymentCardImg[id].icon.src} className="h-[214px] w-[214px] min-w-[214px]" alt="Amazon Logo" aria-label="Gift card selector icon" />
					<div className="w-full" aria-label="Gift card selector content">
						{(id === "bankTransfer" || id === "payPay") && (
							<h1 className="mb-9 max-md:text-center text-2xl max-sm:text-xl font-bold max-md:mb-2" aria-label="Gift card selector title">{PaymentCardImg[id].title}</h1>
						)}
						{(id === "amazon" || id === "apple" || id === "googlePlay") && (
							<h1 className="mb-9 max-md:text-center text-2xl max-sm:text-xl font-bold max-md:mb-2" aria-label="Gift card selector title">{PaymentCardImg[id].title + " " + t("giftCard")}</h1>
						)}
						<div aria-label="Gift card selector content">
							<h2 className="mb-7 text-base max-sm:text-sm font-bold max-md:mb-4 max-md:text-center" aria-label="Gift card selector amount title">
								{t("giftCardSelector.amountTitle")}
							</h2>
							<div className="grid grid-cols-5 gap-5 max-sm:gap-x-3 max-sm:gap-y-3 max-[1300px]:grid-cols-3">
								{amounts.map((amount) => (
									<button
										key={amount}
										className={`px-4 max-sm:px-0 py-3.5 font-semibold text-center max-sm:text-base  rounded-xl border-2 border-solid w-[120px] bg-white 
										max-sm:w-full  ${selectedAmount === amount ? "border-solid border-[#8771EF] " : " hover:bg-neutral-50 border-zinc-300 "}`}
										onClick={() => setSelectedAmount(amount)}
									>
										{new Intl.NumberFormat('en-US').format(amount)} {t("giftCardSelector.amountYen")}
									</button>
								))}
							</div>
						</div>
						<Button
							variant="primary"
							className="self-stretch mt-14 text-2xl max-md:mt-10 w-full"
							aria-label="Gift card selector apply button"
							onClick={apply}
						>
							{isLoading ? <Loader2 className="w-8 h-8 self-center animate-spin" /> : t("giftCardSelector.applyButton")}
						</Button>
					</div>
				</div>
			</div>
		</section>
	);
};
