import { useDispatch } from 'react-redux'
import { restartOnboarding } from '@/redux/onboardingSlice'

import React from 'react'

const OnboardingWarning = () => {

    const dispatch = useDispatch();

    const handleButtonClick = () => {
        dispatch(restartOnboarding());
        console.log('RESTARTED ONBOARDING');
      };

  return (
    <div className="mt-4 p-2 bg-gray-200 rounded-lg text-red-700 text-center">
        Complete <button onClick={handleButtonClick}><span className="text-decoration-line: underline">setting up your profile</span></button> to continue with the extension.
      </div>
  )
}

export default OnboardingWarning