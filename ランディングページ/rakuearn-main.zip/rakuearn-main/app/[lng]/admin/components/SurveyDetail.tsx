"use client";
import * as React from "react";
import { FormInput } from "./SurveyFormInput";
import { toast, ToastContainer } from "react-toastify";
import { ActionButtons } from "./ActionButtons";
import Image from "next/image";
import { SurveyFile } from "@/constants/constants";
import { useT } from "@/app/i18n/client";
import { updateSurvey, deleteSurvey } from "../actions";
interface Survey {
  title: string;
  points: number;
  provider: string;
  estimated_time: number;
  link: string;
  acs_promotion_id: string;
  file_path: string;
  created_at: string;
  id: string;
}

export const SurveyDetail: React.FC<{ survey: Survey, setIsSurveyDetailOpen: (isOpen: boolean) => void }> = ({ survey, setIsSurveyDetailOpen }) => {
  const { t } = useT('admin');
  const [formData, setFormData] = React.useState<Survey>({
    title: survey.title,
    provider: survey.provider,
    estimated_time: survey.estimated_time,
    points: survey.points,
    link: survey.link,
    acs_promotion_id: survey.acs_promotion_id,
    file_path: survey.file_path,
    created_at: survey.created_at,
    id: survey.id,
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return (
    <div className="flex overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] flex-row w-[72%] max-md:w-full max-[1200px]:flex-col-reverse max-[1200px]:items-center gap-10 mt-30 max-md:mt-10" aria-label="Survey detail section">
      <ToastContainer />
      <div className="flex-1 max-[1200px]:flex max-[1200px]:flex-col max-[1200px]:items-center ml-5 max-md:px-5 max-[1200px]:w-full w-[38%]" aria-label="Survey detail form">
        <FormInput
          id="survey-title"
          label={t("title")}
          value={formData.title}
          onChange={(value) => handleInputChange("title", value)}
        />
        <FormInput
          id="survey-provider"
          label={t("surveyProvider")}
          value={formData.provider}
          onChange={(value) => handleInputChange("provider", value)}
        />
        <FormInput
          id="estimated-time"
          label={t("estimatedTime")}
          value={formData.estimated_time.toString()}
          onChange={(value) => handleInputChange("estimated_time", value)}
          className="mb-20"
        />
        <FormInput
          id="points-amount"
          label={t("pointsAmount")}
          value={formData.points.toString()}
          onChange={(value) => handleInputChange("points", value)}
        />
        <FormInput
          id="survey-link"
          label={t("link")}
          value={formData.link}
          onChange={(value) => handleInputChange("link", value)}
        />
        <FormInput
          id="survey-promotion-id"
          label={t("promotionId")}
          value={formData.acs_promotion_id}
          onChange={(value) => handleInputChange("acs_promotion_id", value)}
        />
        <ActionButtons
          onEdit={() => {
            if (confirm('Are you sure you want to update the survey?')) {
              updateSurvey(survey.id, formData).then((res) => {
                if (res.success) {
                  toast.success("Survey updated successfully");
                } else {
                  toast.error(res.error);
                }
              })
            }
          }}
          onDelete={() => {
            if (confirm('Are you sure you want to delete the survey?')) {
              deleteSurvey(survey.id).then((res) => {
                if (res.success) {
                  toast.success("Survey deleted successfully");
                  setIsSurveyDetailOpen(false);
                } else {
                  toast.error(res.error);
                }
              })
            }
          }}
          onGoBack={() => setIsSurveyDetailOpen(false)}
        />
      </div>
      <div className="w-[62%] ml-10 flex items-start justify-center" aria-label="Survey detail image section">
        <Image
          src={SurveyFile + survey.file_path}
          className="rounded-3xl w-[294px]"
          width={294}
          height={294}
          alt="Survey illustration"
        />
      </div>
    </div>
  );
};
