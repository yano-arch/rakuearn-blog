"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

interface GradientToggleProps {
  defaultChecked?: boolean
  onChange?: (checked: boolean) => void
  label?: string
  id?: string
  className?: string
}

export default function GradientToggle({
  defaultChecked = false,
  onChange,
  label,
  id = "gradient-toggle",
  className,
}: GradientToggleProps) {
  const [checked, setChecked] = useState(defaultChecked)

  const handleToggle = () => {
    const newChecked = !checked
    setChecked(newChecked)
    onChange?.(newChecked)
  }

  return (
    <div className={cn("w-full flex flex-row justify-between bg-custom-lpurple-active p-5 rounded-lg items-center ", className)}>
      {label && (
        <label htmlFor={id} className="text-mcursor-pointer text-custom-dpurple-active font-bold tracking-wide">
          {label}
        </label>
      )}
      <button
        type="button"
        role="switch"
        id={id}
        aria-checked={checked}
        className={cn(
          "relative inline-flex h-8 w-16 shrink-0 cursor-pointer rounded-full p-1 transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          checked ? "bg-gradient-to-r from-[#C093FF] via-[#FFA9EC] to-[#FFC65B]" : "bg-gray-200 dark:bg-gray-700",
        )}
        style={checked ? { background: "linear-gradient(85deg, #C093FF 2.72%, #FFA9EC 51.33%, #FFC65B 85%)" } : {}}
        onClick={handleToggle}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault()
            handleToggle()
          }
        }}
        tabIndex={0}
      >
        <span
          className={cn(
            "pointer-events-none block h-6 w-6 rounded-full bg-white shadow-lg ring-0 transition-transform duration-200",
            checked ? "translate-x-8" : "translate-x-0",
          )}
          aria-hidden="true"
        />
      </button>
    </div>
  )
}