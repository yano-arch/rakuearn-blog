'use client';

import GradientToggle from "./ui/gradient-toggle";

const UserForm = () => {
const placeholder = {
    additionalInfo: "Example: You can enter your favorite brands, hobbies, frequently visited places, etc.",
}
//  will clean this up i know it's a lot i just wanna get it out onto vscode & functional
    return (
        <div className="flex flex-col w-full">
            <form type="submit" className="flex flex-col items-center justify-center place-items-center w-100">
                {/* card -> div w main label & toggle -> label:input */}
                {/* component buildout for text inputs v */}

                {/* first/last name */}
                <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Full Name"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <label htmlFor="lname" className="text-black">Last Name</label>
                        <input type="text" id="lname" name="lname" className="p-2 rounded-lg"/>
                        <label htmlFor="fname" className="text-black" >First Name</label>
                        <input type="text" id="fname" name="fname" className="p-2 rounded-lg"/>
                    </div>
                </div>
                {/* furigana */}
                <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Furigana"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <label htmlFor="lname-furigana" className="text-black">Last Name</label>
                        <input type="text" id="lname-furigana" name="lname" className="p-3 rounded-lg"/>
                        <label htmlFor="fname-furigana" className="text-black" >First Name</label>
                        <input type="text" id="fname-furigana" name="fname" className="p-3 rounded-lg"/>
                    </div>
                </div>
                {/* birthday */}
                <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Date of birth"}/>
                        </div>
                    <div className="p-4 flex flex-row gap-2">
                        {/* need date requirements on here */}
                        <input type="text" id="birthday-year" name="birthday-year" className="p-3 rounded-lg w-2/12 text-black" placeholder="1997"/>
                        <input type="text" id="birthday-month" name="birthday-month" className="p-3 rounded-lg w-1/12 text-black" placeholder="11"/>
                        <input type="text" id="birthday-day" name="birthday-day" className="p-3 rounded-lg w-1/12 text-black" placeholder="12"/>
                    </div>
                </div>
                {/* email */}
                <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Email"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <input type="email" id="email" name="email" className="p-3 rounded-lg text-black"/>
                    </div>
                </div>
                {/* phone number */}
                <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Phone number"}/>
                        </div>
                <div className="p-4 flex flex-row gap-2 items-center">
                        <input type="text" id="phone-areacode" name="phone-areacode" className="p-3 rounded-lg w-2/12 text-black" placeholder="123"/>
                        <span className="text-black">-</span>
                        <input type="text" id="phone-prefix" name="phone-prefix" className="p-3 rounded-lg w-1/12 text-black" placeholder="456"/>
                        <span className="text-black">-</span>
                        <input type="text" id="phone-line" name="phone-line" className="p-3 rounded-lg w-1/12 text-black" placeholder="7890"/>
                    </div>
                </div>
                {/* zip-code */}
                <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Zip code"}/>
                        </div>
                <div className="p-4 flex flex-row gap-2 items-center">
                        <input type="text" id="zipcode-prefix" name="zipcode-prefix" className="p-3 rounded-lg w-2/12 text-black" placeholder="123"/>
                        <span className="text-black">-</span>
                        <input type="text" id="zipcode-suffix" name="zipcode-suffix" className="p-3 rounded-lg w-1/12 text-black" placeholder="456"/>
                    </div>
                </div>
                 {/* prefecture */}
                 <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Prefecture"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <input type="text" id="prefecture" name="prefecture" className="p-3 rounded-lg"/>
                    </div>
                </div>
                 {/* city */}
                 <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"City"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <input type="text" id="city" name="city" className="p-3 rounded-lg"/>
                    </div>
                </div>
                 {/* Street Address */}
                 <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Street Address"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <input type="text" id="street" name="street" className="p-3 rounded-lg"/>
                    </div>
                </div>
                 {/* Building Name & Room Number */}
                 <div className="flex flex-col w-user-form-width">
                        <div>
                        <GradientToggle label={"Building Name & Room Number"}/>
                        </div>
                    <div className="p-4 flex flex-col gap-2">
                        <input type="text" id="buildingroom" name="buildingroom" className="p-3 rounded-lg"/>
                    </div>
                </div>

                    {/* radios */}
                    {/* gender */}
                <div className="flex flex-col  w-user-form-width">
                        <div>
                        <GradientToggle label={"Gender"}/>
                        </div>
                        <div className="p-4 flex flex-col">
                        <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3 rounded-lg">
                                <input type="radio" value={"Male"} className="p-2 bg-white" />
                                <label className="text-black">Male</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value={"Female"} className="p-2 bg-white"/>
                                <label className="text-black">Female</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3 rounded-lg">
                                <input type="radio" value={"Other"} className="p-2 bg-white"/>
                                <label className="text-black">Other</label>

                            </div>
                        </div>
                </div>
                {/* household */}
                <div className="flex flex-col  w-user-form-width">
                        <div>
                        <GradientToggle label={"Household Composition"}/>
                        </div>
                        <div className="p-4 flex flex-col">
                        <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3 rounded-lg">
                                <input type="radio" value="single" name="single" className="p-2 bg-white" />
                                <label className="text-black" htmlFor="single">Single</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="married" name="married" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="married">{`Married (With Spouse Only)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="married-kids" name="married-kids" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="married-kids">{`Married (With Spouse and Children)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3 rounded-lg">
                                <input type="radio" value="household-other" name="household-other" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="household-other">Other</label>
                            </div>
                        </div>
                </div>
                {/* Occupation */}
                <div className="flex flex-col  w-user-form-width">
                        <div>
                        <GradientToggle label={"Occupation"}/>
                        </div>
                        <div className="p-4 flex flex-col">
                        <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3 rounded-lg">
                                <input type="radio" value="public-employee" name="public-employee" className="p-2 bg-white" />
                                <label className="text-black" htmlFor="public-employee">{`Company Employee (Publicly Listed Company)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="private-employee" name="private-employee" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="public-employee">{`Company Employee (Privately Held Company)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="government" name="government" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="government">Government Employee</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="teacher" name="teacher" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="teacher">Teacher / Faculty Member</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="professional" name="professional" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="professional">{`Professional (Lawyer, Accountant, etc)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="doctor" name="doctor" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="doctor">Doctor / Physician</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="executive-public" name="executive-public" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="executive-public">{`Executive (Publicly Listed Company)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="executive-private" name="executive-private" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="executive-private">{`Executive (Privately Held Company)`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="business" name="business" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="business">{`Business Owner / Entrepreneur`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="freelancer" name="freelancer" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="freelancer">{`Freelancer / Sole Propietor`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="part-time" name="part-time" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="part-time">{`Part-Time / Temporary Worker`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="unemployed" name="unemployed" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="part-time">{`Unemployed`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="housewife" name="housewife" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="housewife">{`Housewife`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3">
                                <input type="radio" value="student" name="student" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="student">{`Student`}</label>
                            </div>
                            <div className="w-full bg-white border-custom-inactive-text p-3 flex gap-3 rounded-lg">
                                <input type="radio" value="occupation-other" name="occupation-other" className="p-2 bg-white"/>
                                <label className="text-black" htmlFor="occupation-other">{`Other`}</label>
                            </div>
                          
                        </div>
                </div>
               

                {/* textareas */}
                <div className="flex flex-col  w-user-form-width">
                    <div>
                        <GradientToggle label={"Additional Information"}/>
                    </div>
                    <div className="p-4 flex flex-col gap-2 h-52">
                        <label htmlFor="address" className="text-black" hidden></label>
                        <textarea id="address" name="address" className="p-2 rounded-lg bg-white resize-none h-52 text-black" placeholder={placeholder.additionalInfo}></textarea>
                    </div>  


                </div>

        </form>
    </div>
    )

};

export default UserForm