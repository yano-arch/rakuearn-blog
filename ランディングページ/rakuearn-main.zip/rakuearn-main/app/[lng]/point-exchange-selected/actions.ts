'use server'

import { createClient } from '@/utils/supabase/server'

interface GiftCardFormData {
	userEmail: string,
	paymentMethodId: string,
	amount: number,
}

export async function addGiftCard(formData: GiftCardFormData) {
	const supabase = await createClient()

	// type-casting here for convenience
	// in practice, you should validate your inputs
	const data = {
		payment: formData.paymentMethodId,
		status: "pending",
		user_email: formData.userEmail,
		amount: formData.amount,
		
	}

	const { error, data: exchange } = await supabase.from("exchanges").insert(data)

	if (error) {
		console.error('Exchange Request insertion failed', error);
		return { error: error.message }
	}
	return { success: "Exchange Request submitted successfully", exchange: exchange }
}