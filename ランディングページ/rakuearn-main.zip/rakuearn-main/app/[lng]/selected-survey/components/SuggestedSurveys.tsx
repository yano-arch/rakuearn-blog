"use client";
import React from "react";
import { SurveyCard } from "@/app/[lng]/survey-list/components/SurveyCard";
import { Zap } from "lucide-react";
import { useT } from "@/app/i18n/client";
import { SurveyFile } from "@/constants/constants";
import { useParams } from "next/navigation";

export const SuggestedSurveys: React.FC<{ suggestedSurveys: any[] | {error: string} | null }> = ({ suggestedSurveys }) => {
	const surveyId = useParams().id;
	const { t } = useT('surveyList');
	return (
		<section className="self-center mt-14 mb-8 w-full max-md:mt-10" aria-label="Suggested surveys section">
			<div className="flex flex-col gap-5 items-start" aria-label="Suggested surveys content">
				<div className="flex gap-2 items-center text-2xl font-bold text-violet-500 max-md:ml-2.5" aria-label="Suggested surveys title">
					<Zap color="#8771EF" />
					<h2 className="basis-auto max-sm:text-xl" aria-label="Suggested surveys title">{t("suggestedSurveys.title")}</h2>
				</div>
				<div className="grid grid-cols-5 max-[1200px]:grid-cols-4 max-[1000px]:grid-cols-3 max-[800px]:grid-cols-2 gap-5 self-center w-full max-w-[1300px] max-md:max-w-full" aria-label="Suggested surveys cards">
					{suggestedSurveys && 'error' in suggestedSurveys ? (
						<div className="text-center text-red-500">
							{suggestedSurveys.error}
						</div>
					) : (
						suggestedSurveys?.filter((survey) => survey.id !== surveyId).map((survey) => (
							<SurveyCard
								key={survey.id}
								id={survey.id}
								title={survey.title}
								points={survey.points}
								dateAdded={survey.created_at}
								imageUrl={SurveyFile + survey.file_path}
							/>
						))
					)}
				</div>
			</div>
		</section>
	);
};
