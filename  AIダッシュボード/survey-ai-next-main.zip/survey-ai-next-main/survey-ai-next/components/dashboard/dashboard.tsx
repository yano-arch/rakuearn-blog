import DataCard from "../ui/data-card";
import { Wallet } from "lucide-react";
import { SquarePen } from "lucide-react"
import { BarChartGraph } from "../ui/Bar-Chart";
import FormTable from "../Form-Table";

const DashboardDisplay = () => {
// going to need to get data from database. not sure how that schema will be

    return (
        <div className="w-full h-screen bg-custom-lilac-bg flex flex-row mt-8 relative">

            <h1 className="text-3xl text-custom-darkest-purple font-semibold ml-10">Home</h1>
            <h1 className="text-red-500 absolute right-20">dropdown sort soon. missed that</h1>
            {/* content container */}

            {/* left side - stats */}
            <div className="flex flex-col w-data-width gap-8 mt-20 h-100 -ml-20">

            {/* earned pts & ai filled cards */}
            <div className="flex flex-row gap-8 h-1/5 w-full justify-between">
             <DataCard
                iconType={"wallet"}
                iconBgColor="bg-custom-lpurple-active"
                iconColor="text-custom-dpurple-active" 
                title="Earned Points"
                // data from user vvv
                description="100,000"
                descriptionColor="text-custom-dpurple-active"
                containerBg="bg-white"
                />
                <DataCard   
                iconType={"squarePen"}
                iconBgColor="bg-custom-orange-bg"
                iconColor="text-custom-orange-accent"
                title="AI Filled Count"
                // data from user vvv
                description="99"
                descriptionColor="text-custom-orange-accent"
                containerBg="bg-white"
                />
            </div>
                {/* bar chart */}
                <BarChartGraph/>
                {/* forms quick overview table */}
            <div className="">

            </div>

            </div>
                {/* right side - completed form info and list */}
                <div className="w-1/3 gap-8 mt-20 ml-32 h-custom-form-div-height">
                
                    <FormTable/>
                </div>
                </div>


    )
};

export default DashboardDisplay;