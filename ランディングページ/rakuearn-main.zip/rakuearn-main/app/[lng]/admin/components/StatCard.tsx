import * as React from "react";
import { Loader2 } from "lucide-react";
interface StatCardProps {
  title: string;
  value: string | number;
  variant?: "default" | "highlight";
  isLoading: boolean;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  variant = "default",
  isLoading,
}) => {
  const bgColor = variant === "highlight" ? "bg-amber-300" : "bg-white";

  return (
    <article
      className={`flex flex-col grow w-[300px] max-md:w-full items-start py-6 pr-14 pl-5 text-lg font-semibold text-black ${bgColor} rounded-xl max-md:pr-5 max-md:mt-8`}
      role="region"
      aria-label={title}
    >
      <h3>{title}</h3>
      {isLoading ?
        (
          <div className="flex justify-center mt-5 items-center">
            <Loader2 className="animate-spin" />
          </div>
        ) : (
          <p className="mt-5">{value}</p>
        )}
    </article>
  );
};
