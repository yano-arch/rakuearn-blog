"use client";
import { useState, useEffect } from "react";
import { RadioButton } from "./RadioButton";
import { DateSelector } from "./DateSelector";
import { ChevronDown } from "lucide-react";
import { getUser, removeUser } from "../../login/action";
import { getPrefectures } from "@/constants/constants";
import { useT } from "@/app/i18n/client";
import { User } from "@supabase/supabase-js";
import { useRouter } from "next/navigation";
import { logout } from "@/app/[lng]/login/action";
import { updateUser, updatePassword } from "../../login/action";
import { toast, ToastContainer } from "react-toastify";
export interface UserProfile {
  id: string,
  nickname: string,
  email: string,
  pwd: string,
  confirmPwd: string,
  dob: Date,
  gender: string,
  prefectures: string,
  role: string,
}

export const AccountForm = () => {
  const { t } = useT('auth');
  const router = useRouter();
  const [uerProfile, setUserProfile] = useState<UserProfile>({
    id: '',
    nickname: '',
    email: '',
    pwd: '',
    confirmPwd: '',
    dob: new Date(),
    gender: '',
    prefectures: '',
    role: '',
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      const { user, error } = await getUser();
      if (error) {
        console.error('User retrieval failed', error);
      } else {
        setUserProfile({
          id: user.user?.id || '',
          nickname: user.user?.user_metadata?.nickname || '',
          email: user.user?.email || '',
          pwd: '',
          confirmPwd: '',
          dob: user.user?.user_metadata?.dob || '',
          gender: user.user?.user_metadata?.gender || '',
          prefectures: user.user?.user_metadata?.prefectures || '',
          role: user.user?.user_metadata?.role || '',
        });
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  return (
    <section className="flex flex-col items-start w-full" aria-label="Account setting section">
      <ToastContainer />
      {isLoading ? (
        <div className="flex justify-center w-full items-center h-100">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-violet-500"></div>
        </div>
      ) : (
        <>
          <h1 className="mt-10 text-2xl max-sm:text-lg font-bold text-black max-md:mt-0 max-md:ml-2.5" aria-label="Account setting title">
            {t("accountSetting.title")}
          </h1>

          <div className="flex flex-col w-full" aria-label="Account setting form">
            <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Nickname input">
              <label htmlFor="nickname" className="my-auto w-[18%] max-sm:w-full">{t("accountSetting.nickname")}</label>
              <input
                id="nickname"
                type="text"
                value={uerProfile?.nickname}
                className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
                onChange={(e) => setUserProfile({ ...uerProfile, nickname: e.target.value })}
              />
            </div>

            <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Email input">
              <label htmlFor="email" className="my-auto w-[18%] max-sm:w-full">{t("accountSetting.email")}</label>
              <input
                id="email"
                type="email"
                value={uerProfile?.email}
                className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
                disabled
              />
            </div>

            <div className="flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Password input">
              <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 w-full">
                <label htmlFor="password" className="my-auto w-[18%] max-sm:w-full">{t("accountSetting.password")}</label>
                <div className="flex gap-5">
                  <input
                    id="password"
                    type="password"
                    value={uerProfile?.pwd}
                    className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
                    onChange={(e) => setUserProfile({ ...uerProfile, pwd: e.target.value })}
                  />

                </div>
              </div>
              <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mt-5 w-full">
                <label htmlFor="confirmPassword" className="my-auto w-[18%] max-sm:w-full">{t("accountSetting.confirmPassword")}</label>
                <div className="flex gap-5">
                  <input
                    id="confirmPassword"
                    type="password"
                    value={uerProfile?.confirmPwd}
                    className="px-4 py-0 h-10 rounded-md border border-solid border-zinc-300 border-opacity-90 w-[393px] max-sm:w-full"
                    onChange={(e) => setUserProfile({ ...uerProfile, confirmPwd: e.target.value })}
                  />
                  <button
                    className="my-auto cursor-pointer hover:text-gray-700"
                    onClick={() => {
                      if (uerProfile.pwd !== uerProfile.confirmPwd) {
                        toast.error("Password and confirm password do not match");
                        return;
                      }
                      setIsLoading(true);
                      updatePassword(uerProfile.pwd).then((res) => {
                        if (res.success) {
                          toast.success("Password updated successfully");
                        }
                        if (res.error) {
                          toast.error("Password updated failed");
                        }
                        setIsLoading(false)
                      }).catch((error) => {
                        console.error('Password update failed', error);
                        setIsLoading(false);
                      })
                    }}
                  >
                    {t("accountSetting.changePassword")}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Date of birth input">
              <label htmlFor="dob" className="my-auto w-[18%] max-sm:w-full text-base font-medium text-black">
                {t("accountSetting.dateOfBirth")}
              </label>
              <div className="flex gap-2.5">
                <DateSelector
                  value={uerProfile.dob}
                  onChange={(date) => setUserProfile({ ...uerProfile, dob: date })}
                />
              </div>
            </div>

            <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Gender input">
              <label htmlFor="gender" className="my-auto w-[18%] max-sm:w-full text-base font-medium text-black">{t("accountSetting.gender")}</label>
              <div className="flex gap-8">
                <RadioButton
                  label={t("accountSetting.male")}
                  checked={uerProfile.gender === "male"}
                  name="gender"
                  onChange={() => setUserProfile({ ...uerProfile, gender: "male" })}
                />
                <RadioButton
                  label={t("accountSetting.female")}
                  checked={uerProfile.gender === "female"}
                  name="gender"
                  onChange={() => setUserProfile({ ...uerProfile, gender: "female" })}
                />
                <RadioButton
                  label={t("accountSetting.others")}
                  checked={uerProfile.gender === "others"}
                  name="gender"
                  onChange={() => setUserProfile({ ...uerProfile, gender: "others" })}
                />
              </div>
            </div>

            <div className="flex max-sm:flex-col max-sm:gap-2 max-sm:items-start items-center gap-30 mb-2 border-b border-solid p-8 max-sm:p-5 border-zinc-300 border-opacity-90" aria-label="Prefectures input">
              <label htmlFor="prefectures" className="my-auto w-[18%] max-sm:w-full">{t("accountSetting.prefectures")}</label>
              <div className="relative">
                <select
                  id="prefectures"
                  value={uerProfile.prefectures}
                  onChange={(e) => setUserProfile({ ...uerProfile, prefectures: e.target.value })}
                  className="px-4 py-2 relative rounded-lg border border-zinc-300 appearance-none bg-white cursor-pointer w-[150px]"
                >
                  {getPrefectures(t).map((prefecture) => (
                    <option key={prefecture} value={prefecture}>{prefecture}</option>
                  ))}
                </select>
                <ChevronDown className="absolute pointer-events-none right-2 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <button
              className="cursor-pointer max-md:ml-2.5 px-8 py-4 text-base font-medium text-[#8771EF] text-left"
              aria-label="Delete account"
              onClick={() => {
                if (confirm('Are you sure you want to update your account?')) {
                  setIsLoading(true);
                  updateUser(uerProfile)
                    .then(() => {
                      toast.success("Account updated successfully");
                      setIsLoading(false);
                    })
                    .catch((error) => {
                      console.error('User deletion failed', error);
                      setIsLoading(false);
                    })
                }
              }}
            >
              {t("accountSetting.updateAccount")}
            </button>

            <button
              className="cursor-pointer max-md:ml-2.5 px-8 py-4 text-base font-medium text-red-600 hover:text-red-700 text-left"
              aria-label="Delete account"
              onClick={() => {
                if (confirm('Are you sure you want to delete your account?')) {
                  logout()
                    .then(() => {
                      removeUser(uerProfile.id)
                        .then(() => {
                          router.push('/login');
                        })
                        .catch((error) => {
                          console.error('User deletion failed', error);
                        })
                    })
                }
              }}
            >
              {t("accountSetting.deleteAccount")}
            </button>
          </div>
        </>
      )}
    </section>
  );
};
