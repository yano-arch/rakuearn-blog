import React from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'

const profileSchema = z.object({
  apiKey: z.string().min(1, 'API key is required'),
  name: z.string().min(1, 'Name is required'),
  age: z.string().regex(/^\d+$/, 'Age must be a number'),
  occupation: z.string().min(1, 'Occupation is required'),
  interests: z.string()
})

type ProfileFormData = z.infer<typeof profileSchema>

export function ProfileForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema)
  })

  const [ isSuccessfullySubmitted, setIsSuccessfullySubmitted,] = React.useState(false);
  React.useEffect(() => {
    // Load saved profile data
    chrome.storage.local.get(['apiKey', 'userProfile'], (result) => {
      if (result.apiKey || result.userProfile) {
        reset({
          apiKey: result.apiKey || '',
          ...result.userProfile
        })
      }
    })
  }, [reset])

  const onSubmit = async (data: ProfileFormData) => {
    try {
      const { apiKey, ...profile } = data
      await chrome.storage.local.set({
        apiKey,
        userProfile: profile
      })
      setIsSuccessfullySubmitted(true)
    } catch (e) {
      // console.error("storage error: ", e);
      setIsSuccessfullySubmitted(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiKey">API Key</Label>
              <Input
                id="apiKey"
                type="password"
                {...register('apiKey')}
                className={errors.apiKey ? 'border-destructive' : ''}
              />
              {errors.apiKey && (
                <p className="text-sm text-destructive">{errors.apiKey.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                {...register('name')}
                className={errors.name ? 'border-destructive' : ''}
              />
              {errors.name && (
                <p className="text-sm text-destructive">{errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                {...register('age')}
                className={errors.age ? 'border-destructive' : ''}
              />
              {errors.age && (
                <p className="text-sm text-destructive">{errors.age.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="occupation">Occupation</Label>
              <Input
                id="occupation"
                {...register('occupation')}
                className={errors.occupation ? 'border-destructive' : ''}
              />
              {errors.occupation && (
                <p className="text-sm text-destructive">{errors.occupation.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="interests">Interests (comma separated)</Label>
              <Input
                id="interests"
                {...register('interests')}
                placeholder="e.g. technology, travel, cooking"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Button type="submit" className="w-full">
        Save Profile
      </Button>
      {isSuccessfullySubmitted &&
        <div className="success">Form submitted successfully</div>
      }
    </form>
  )
} 