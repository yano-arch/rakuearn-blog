'use server'
import { UserProfile } from '@/app/[lng]/account-setting/components/AccountForm'

import { createClient } from '@/utils/supabase/server'

interface LoginFormData {
  email: string;
  password: string;
}

export async function login(formData: LoginFormData, lng: string) {
  const supabase = await createClient()

  // type-casting here for convenience
  // in practice, you should validate your inputs
  const data = {
    email: formData.email,
    password: formData.password,
  }

  const { error, data: user } = await supabase.auth.signInWithPassword(data)

  if (error) {
    console.log(error);
    return { error: error.message }
  }
  return { success: "User logged in successfully", user: user }
}

export async function signup(userProfile: UserProfile, lng: string) {
  const supabase = await createClient()

  // type-casting here for convenience
  // in practice, you should validate your inputs
  const data = {
    email: userProfile.email,
    password: userProfile.pwd,
    options: {
      data: {
        nickname: userProfile.nickname,
        dob: userProfile.dob,
        gender: userProfile.gender,
        prefectures: userProfile.prefectures,
        role: "user",
      },
    },
  }

  const { error } = await supabase.auth.signUp(data)

  if (error) {
    return { error: error.message }
  }
  
  return { success: "User created successfully" }
}

export async function getUser() {
  const supabase = await createClient()
  const { data: user, error } = await supabase.auth.getUser()
  return { user, error }
}

export async function logout() {
  const supabase = await createClient()
  const { error } = await supabase.auth.signOut()
  if (error) {
    return { error: error.message }
  }
  return { success: "User logged out successfully" }
}

export async function removeUser(userId: string) {
  const supabase = await createClient()
  const { error } = await supabase.auth.admin.deleteUser(userId)
  await supabase.from('profiles').delete().eq('id', userId)
  return { error: error?.message }
}

export async function updateUser(userProfile: UserProfile) {
  const supabase = await createClient()
  const { error } = await supabase.auth.updateUser({
    // password: userProfile.pwd,
    data: {
      nickname: userProfile.nickname,
      dob: userProfile.dob,
      gender: userProfile.gender,
      prefectures: userProfile.prefectures,
    },
  })
  const { error: updateError } = await supabase.from('profiles').update({
    nickname: userProfile.nickname,
  }).eq('id', userProfile.id)
  if (updateError) {
    return { error: updateError?.message }
  }
  return { success: "User updated successfully" }
}

export async function updatePassword(newPassword: string) {
  const supabase = await createClient()
  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  })
  if (error) {
    console.log("error", error);
    return { error: error?.message }
  }
  return { success: "Password updated successfully" }
}

export async function requestResetPassword(email: string) {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: 'https://rakuearn.vercel.app/reset-password',
  })
  return { data, error }
}
