const FormTable = () => {
  // Placeholder data
  const placeholderData = [
    { dateCompleted: "2/24/2025", title: "Form Title long long long", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 4000 },
    { dateCompleted: "2/24/2025", title: "Form Title longgggggggggggggg title", pointsEarned: 5020 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 143100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 13420 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 41100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 5400 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
    { dateCompleted: "2/24/2025", title: "Form Title", pointsEarned: 100 },
  ];
  const tableHeaders = ["Date", "Title", "Points"];

  return (
    <div className="w-full h-100 overflow-hidden border shadow-md rounded-xl flex flex-col">
      {/* Scrollable Table */}
      <div className="overflow-y-auto max-h-custom-form-div-height">
        <table className="w-full border-collapse h-100">
          {/* Table Head */}
          <thead className="bg-white text-x sticky top-0">
            <tr className="h-10">
              {tableHeaders.map((header, index) => (
                <th key={index} className="p-1 bg-custom-lpurple-active text-custom-dpurple-active text-lg border-b">
                  {header}
                </th>
              ))}
            </tr>
          </thead>

          {/* Table Body */}
          <tbody>
            {placeholderData.map((data, index) => (
              <tr key={index} className="bg-white h-10">
                <td className="p-2 m-1 text-s leading-tight w-32 border-b text-custom-darkest-purple font-semibold">{data.dateCompleted}</td>
                <td className="p-2 m-1 text-s leading-tight w-100 border-b text-custom-darkest-purple font-semibold">{data.title}</td>
                <td className="p-2  m-1 text-s leading-tight w-28 border-b text-custom-darkest-purple font-semibold">{data.pointsEarned}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default FormTable;
