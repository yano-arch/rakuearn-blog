import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Bot, Settings2, Play, Pause, AlertCircle } from 'lucide-react'

export function Popup() {
  const [isEnabled, setIsEnabled] = React.useState(false)
  const [status, setStatus] = React.useState<'ready' | 'error' | 'running'>('ready')
  const [dailyStats, setDailyStats] = React.useState({ completed: 0, remaining: 0 })

  React.useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      // Load extension state
      chrome.storage.local.get(['isEnabled', 'dailySurveyCount', 'schedule'], (result) => {
        setIsEnabled(result.isEnabled || false)
        const completed = result.dailySurveyCount || 0
        const maxDaily = result.schedule?.maxSurveysPerDay || 10
        setDailyStats({ completed, remaining: maxDaily - completed })
      })

      // Check API key status
      chrome.storage.local.get(['apiKey'], (result) => {
        if (!result.apiKey) {
          setStatus('error')
        }
      })
    }
  }, [])

  const toggleEnabled = () => {
    const newState = !isEnabled
    setIsEnabled(newState)
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({ isEnabled: newState })
    }
  }

  const openSettings = () => {
    if (typeof chrome !== 'undefined') {
      // Open the settings page in a new tab
      chrome.tabs.create({ url: 'http://localhost:3000/extension' })
    }
  }

  return (
    <Card className="w-[350px] border-none">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {status === 'error' ? (
                <AlertCircle className="h-8 w-8 text-destructive" />
              ) : (
                <Bot className={`h-8 w-8 ${isEnabled ? 'text-zinc-900 dark:text-zinc-100 animate-pulse' : 'text-muted-foreground'}`} />
              )}
              <div>
                <p className="text-sm font-medium">AI Assistant Status</p>
                {status === 'error' ? (
                  <p className="text-xs text-destructive">API key not configured</p>
                ) : isEnabled ? (
                  <p className="text-xs text-zinc-900 dark:text-zinc-100">Actively monitoring for surveys</p>
                ) : (
                  <p className="text-xs text-muted-foreground">Ready to help with surveys</p>
                )}
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={openSettings}
              className="hover:bg-zinc-100 dark:hover:bg-zinc-800"
            >
              <Settings2 className="h-5 w-5" />
            </Button>
          </div>

          {status !== 'error' && (
            <>
              <div className="flex items-center justify-between text-sm">
                <span>Today's Progress</span>
                <span className="font-medium">{dailyStats.completed} / {dailyStats.completed + dailyStats.remaining} surveys</span>
              </div>

              <div className="relative h-2 w-full bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className="absolute h-full bg-zinc-900 dark:bg-zinc-100 transition-all duration-300"
                  style={{ 
                    width: `${(dailyStats.completed / (dailyStats.completed + dailyStats.remaining)) * 100}%`
                  }}
                />
              </div>

              <Button 
                className="w-full bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-900"
                variant={isEnabled ? "outline" : "default"}
                onClick={toggleEnabled}
              >
                {isEnabled ? (
                  <>
                    <Pause className="mr-2 h-4 w-4" />
                    Pause Assistant
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Start Assistant
                  </>
                )}
              </Button>
            </>
          )}

          {status === 'error' && (
            <Button 
              className="w-full bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-900"
              onClick={openSettings}
            >
              Configure Extension
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
} 