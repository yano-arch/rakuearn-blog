import React from "react";
import { CategoryTitle } from "@/components/comps/CategoryTitle";
import PaymentMethodCard from "./PaymentMethodCard";
import { getPaymentCardImg } from "@/constants/constants";
import { useRouter, useParams } from "next/navigation";
import { useT } from "@/app/i18n/client";
interface PaymentSectionProps {
	selectedPaymentMethod: string;
	onPaymentMethodChange: (method: string) => void;
}


export const PaymentSection: React.FC<PaymentSectionProps> = ({
	selectedPaymentMethod,
	onPaymentMethodChange,
}) => {
	const router = useRouter();
	const { t } = useT('pointExchange');
	const lng = useParams().lng;
	return (
		<div className="flex flex-col mb-40 max-md:mb-20 gap-4 mt-20 max-md:mt-10" aria-label="Payment section">
			<CategoryTitle title={t('paymentSection.title')} aria-label="Payment section title" />
			<div className="flex gap-10 justify-around max-sm:gap-5 px-10 max-md:px-0" aria-label="Payment section content">
				<div className="grid grid-cols-5 max-md:grid-cols-3 max-sm:grid-cols-1 gap-5 self-center mt-8 max-md:mt-4 w-full text-base font-bold text-center text-black max-md:max-w-full">
					{Object.values(getPaymentCardImg(t)).map((paymentMethod) => (
						<PaymentMethodCard
							key={paymentMethod.title}
							iconUrl={paymentMethod.icon.src}
							title={t(`${paymentMethod.title}`)}
							onClick={() => {
								router.push(`/${lng}/point-exchange-selected/${paymentMethod.id}`);
							}}
						/>
					))}
				</div>
			</div>
		</div>
	);
};

