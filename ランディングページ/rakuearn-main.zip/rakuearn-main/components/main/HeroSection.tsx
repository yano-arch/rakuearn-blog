import React from "react";
import Image from "next/image";
import Button from "../layout/Button";
import UserAvatarStack from "../comps/UserAvatarStack";
import LandHero from "@/assets/images/land_hero.svg"
import { useT } from "@/app/i18n/client";
import { useParams } from "next/navigation";
import { useRouter } from "next/navigation";

const HeroSection: React.FC = () => {
	const { t } = useT('home');
	const lng = useParams().lng;
	const router = useRouter();

	return (
		<section className="flex flex-row items-center justify-around max-[1100px]:p-8 max-[1100px]:gap-8 max-[1100px]:flex-col max-md:p-5 mt-[30px] max-sm:mt-[15px]" aria-label="Hero section">
			<div className="ml-[7%] max-sm:ml-0 max-sm:relative max-sm:flex max-sm:flex-col max-sm:items-center" aria-label="Hero content">
				{/* <Image src={PennyL} alt="Penny L" width={140} height={140} className="hidden max-sm:block absolute top-[70px] left-[-75]" aria-label="Penny L" />
				<Image src={PennyR} alt="Penny R" width={120} height={120} className="hidden max-sm:block absolute top-[-75px] right-[-45]" aria-label="Penny R" /> */}
				<h1 className="mb-8 max-sm:mb-4 text-5xl font-bold max-sm:text-center max-sm:text-3xl" aria-label="Hero title">
					<span>{t('title')}</span>
					<br />
					<span className="bg-gradient-to-r max-md:text-center max-md:text-3xl from-[#c093ff] via-[#ffa9ec] to-[#FDB073] bg-clip-text text-transparent">
						&{t('title2')}
					</span>
				</h1>
				<p className="mb-5 text-lg max-md:text-sm max-sm:w-[200px] font-semibold max-sm:text-center" aria-label="Hero description">
					{t('heroDetail')}
					{lng === 'ja' && (
						<>
							<br />
							{t('heroDetail2')}
						</>
					)}
				</p>
				<div className="flex gap-4 items-center mb-16 max-sm:mb-8 max-sm:justify-center" aria-label="Hero users">
					<UserAvatarStack />
					<div className={`flex max-sm:flex-col max-sm:gap-0 text-lg max-sm:text-sm font-semibold text-[#A7A7C7] ${lng === 'ja' ? '' : 'gap-2'}`}>
						<p>1000{lng === 'ja' ? '' : '+'}</p>
						<p className="" aria-label="Hero users description">
							{t('activeUsers')}
						</p>
					</div>
				</div>
				<div className="flex gap-4 mt-8 max-sm:mt-0 max-sm:flex-col" aria-label="Hero buttons">
					<Button variant="primary" ariaLabel="Start Earning" className="max-sm:text-base max-sm:min-w-[200px]" onClick={() => router.push(`/${lng}/survey-list`)}>{t('startEarning')}</Button>
					<Button variant="secondary" ariaLabel="Get AI" className="max-sm:text-base max-sm:min-w-[200px]" onClick={() => window.open('https://app.rakuearn.com/', '_blank')}>{t('getAI')}</Button>
				</div>
			</div>
			<div className="relative max-sm:hidden mt-[-50px] flex max-sm:mt-4" aria-label="Hero image">
				<Image src={LandHero} alt="Land Hero" width={737} height={538} aria-label="Hero image" />
			</div>
		</section>
	);
};

export default HeroSection;
