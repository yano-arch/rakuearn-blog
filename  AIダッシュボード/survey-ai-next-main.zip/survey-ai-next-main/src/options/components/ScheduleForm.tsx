import React from 'react'
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Clock, Save } from "lucide-react"

const scheduleSchema = z.object({
  enabled: z.boolean().default(true),
  startTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: "Please enter a valid time in 24-hour format (HH:MM).",
  }),
  endTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: "Please enter a valid time in 24-hour format (HH:MM).",
  }),
  maxSurveysPerDay: z.string().transform((val) => parseInt(val, 10)).pipe(
    z.number().min(1, { message: "Must complete at least 1 survey per day." }).max(50, { message: "Cannot exceed 50 surveys per day." })
  ),
  minDelayBetweenSurveys: z.string().transform((val) => parseInt(val, 10)).pipe(
    z.number().min(1, { message: "Minimum delay must be at least 1 minute." }).max(60, { message: "Maximum delay cannot exceed 60 minutes." })
  ),
})

export function ScheduleForm() {
  const form = useForm<z.infer<typeof scheduleSchema>>({
    resolver: zodResolver(scheduleSchema),
    defaultValues: {
      enabled: true,
      startTime: "09:00",
      endTime: "17:00",
      maxSurveysPerDay: "10",
      minDelayBetweenSurveys: "5",
    },
  })

  React.useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['schedule'], (result) => {
        if (result.schedule) {
          form.reset(result.schedule)
        }
      })
    }
  }, [form])

  function onSubmit(values: z.infer<typeof scheduleSchema>) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({ schedule: values }, () => {
        console.log('Schedule saved:', values)
      })
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="enabled"
          render={({ field }) => (
            <FormItem className="flex items-center justify-between space-x-2">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Enable Scheduling</FormLabel>
                <FormDescription>
                  Automatically complete surveys during specified hours
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="startTime"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Start Time
                </FormLabel>
                <FormControl>
                  <Input 
                    type="time"
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="endTime"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  End Time
                </FormLabel>
                <FormControl>
                  <Input 
                    type="time"
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="maxSurveysPerDay"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base">Maximum Surveys Per Day</FormLabel>
                <FormControl>
                  <Input 
                    type="number"
                    min="1"
                    max="50"
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
                <FormDescription>
                  Limit the number of surveys completed each day
                </FormDescription>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="minDelayBetweenSurveys"
            render={({ field }) => (
              <FormItem className="space-y-2">
                <FormLabel className="text-base">Minimum Delay (minutes)</FormLabel>
                <FormControl>
                  <Input 
                    type="number"
                    min="1"
                    max="60"
                    {...field}
                    className="h-12 px-4 rounded-lg border-2 border-gray-200 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all duration-200"
                  />
                </FormControl>
                <FormDescription>
                  Minimum wait time between surveys
                </FormDescription>
              </FormItem>
            )}
          />
        </div>

        <Button 
          type="submit" 
          className="w-full h-12 text-base font-medium bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          Save Schedule
        </Button>
      </form>
    </Form>
  )
} 