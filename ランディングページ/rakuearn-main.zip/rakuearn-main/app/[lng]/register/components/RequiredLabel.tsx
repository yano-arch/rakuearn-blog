import * as React from "react";
import { useParams } from "next/navigation";
import { useT } from "@/app/i18n/client";

interface RequiredLabelProps {
	text: string;
}

export function RequiredLabel({ text }: RequiredLabelProps) {
	const { t } = useT('auth');
	return (
		<div className="flex gap-5 items-center w-[18%] min-w-[250px] max-sm:w-full" aria-label="Required label">
			<label className="text-base font-medium text-black">{text}</label>
			<div className="px-2.5 py-0.5 text-xs font-bold text-white bg-red-600 rounded-md">
				{t("register.requiredLabel")}
			</div>
		</div>
	);
}
