import { Button } from "@/components/ui/button";
import Image from "next/image";
import Link from "next/link";
import { ReactNode } from "react";
import { SlArrowLeft } from "react-icons/sl";

interface LayoutProps {
    children: ReactNode;
  }


const layout = ({children} : LayoutProps) => {
  return (
        <div className="flex w-full h-full justify-center align-middle">
            <div className="border-2 self-center p-5 rounded-2xl shadow-xl shadow-gray-500">
                <div className="flex flex-row mt-3 w-full">
                    <Link href={'/'} className="shadow-none">
                        <SlArrowLeft color="black"/>
                    </Link>
                    <Image width={150} height={150} alt="logo" src='/logo1.png' className="flex-1"/>
                </div>
                <div className="p-5">
                    {children}
                </div>
                
            </div>
            
        </div>
    
  )
}

export default layout